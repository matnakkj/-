"""
محافظ ضد اسپم: اگه یک کاربر خیلی سریع پیام/دکمه بزنه (بیش از حد مجاز
توی یه بازه‌ی زمانی کوتاه)، پیام‌های اضافیش رو نادیده می‌گیریم تا کل
ربات کند نشه. حد مجاز عمداً سخت‌گیرانه نیست (۱۰ تا در ۱۰ ثانیه) که
کاربر عادی اذیت نشه.
"""
import logging
import time
from collections import defaultdict, deque

from aiogram import BaseMiddleware

logger = logging.getLogger(__name__)

WINDOW_SECONDS = 10
MAX_EVENTS_PER_WINDOW = 10
WARNING_COOLDOWN_SECONDS = 5  # حداقل فاصله بین دوتا پیام هشدار برای همون کاربر
CLEANUP_EVERY_N_CALLS = 500   # هر ۵۰۰ رویداد یه‌بار حافظه‌ی کاربرهای غیرفعال رو پاک می‌کنیم


class AntiFloodMiddleware(BaseMiddleware):
    """
    یک نمونه از این کلاس رو هم برای message هم برای callback_query استفاده می‌کنیم
    (با یک instance مشترک) تا بودجه‌ی هردو با هم حساب بشه.

    نکته: چون این دیکشنری‌ها به‌ازای هر کاربری که تابه‌حال دیده شده رشد
    می‌کنن، برای جلوگیری از نشتی حافظه‌ی طولانی‌مدت، هر چند صد رویداد یک‌بار
    رکورد کاربرهایی که مدتیه فعالیتی نداشتن رو پاک می‌کنیم.
    """

    def __init__(self) -> None:
        self._history: dict[int, deque] = defaultdict(deque)
        self._last_warning: dict[int, float] = {}
        self._call_counter = 0

    async def __call__(self, handler, event, data):
        user = getattr(event, "from_user", None)
        if user is None:
            return await handler(event, data)

        user_id = user.id
        now = time.monotonic()
        dq = self._history[user_id]
        dq.append(now)
        while dq and now - dq[0] > WINDOW_SECONDS:
            dq.popleft()

        blocked = len(dq) > MAX_EVENTS_PER_WINDOW
        if blocked:
            last_warn = self._last_warning.get(user_id, 0)
            if now - last_warn > WARNING_COOLDOWN_SECONDS:
                self._last_warning[user_id] = now
                try:
                    if hasattr(event, "answer"):
                        await event.answer("⏳ کمی صبر کنید، سرعت پیام‌ها/دکمه‌هاتون خیلی زیاده.")
                except Exception as e:
                    logger.debug(f"خطا در ارسال هشدار ضد اسپم: {e}")

        self._call_counter += 1
        if self._call_counter >= CLEANUP_EVERY_N_CALLS:
            self._call_counter = 0
            self._cleanup_inactive_users(now)

        if blocked:
            return  # هندلر اصلی اجرا نمیشه، این ایونت نادیده گرفته میشه

        return await handler(event, data)

    def _cleanup_inactive_users(self, now: float) -> None:
        """رکورد کاربرهایی که توی این بازه هیچ فعالیتی نداشتن رو کامل پاک می‌کنه."""
        stale_user_ids = [
            uid for uid, dq in self._history.items()
            if not dq or now - dq[-1] > WINDOW_SECONDS
        ]
        for uid in stale_user_ids:
            self._history.pop(uid, None)
            self._last_warning.pop(uid, None)
