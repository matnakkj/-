"""
ابزارهای تاریخ شمسی (جلالی).

قانون کلی توی کل پروژه:
    - همه‌ی تاریخ‌ها توی دیتابیس به‌صورت میلادی (Gregorian date) ذخیره میشن
      (چون استاندارده و برای محاسبات/مرتب‌سازی راحت‌تره)
    - هر جا به کاربر تاریخ نشون داده میشه، با gregorian_to_jalali_str
      به شمسی تبدیل و نمایش داده میشه
    - هر جا از کاربر تاریخ گرفته میشه، با parse_jalali_date اعتبارسنجی
      و به میلادی تبدیل میشه
"""
from datetime import date, datetime
import re

import jdatetime

# ترتیب دقیقاً باید با خروجی datetime.weekday() پایتون یکی باشه:
# دوشنبه=0, سه‌شنبه=1, چهارشنبه=2, پنجشنبه=3, جمعه=4, شنبه=5, یکشنبه=6
WEEKDAY_NAMES_FA = [
    "دوشنبه", "سه‌شنبه", "چهارشنبه", "پنجشنبه", "جمعه", "شنبه", "یکشنبه",
]

_DATE_PATTERN = re.compile(r"^(\d{4})[/\-](\d{1,2})[/\-](\d{1,2})$")


def parse_jalali_date(text: str) -> date | None:
    """
    ورودی مثل '1403/07/01' یا '1403-7-1' رو می‌گیره و به date میلادی تبدیل می‌کنه.
    اگه فرمت یا مقدار نامعتبر بود None برمی‌گردونه.
    """
    if not text:
        return None
    match = _DATE_PATTERN.match(text.strip())
    if not match:
        return None

    year, month, day = (int(x) for x in match.groups())
    try:
        jd = jdatetime.date(year, month, day)
    except ValueError:
        return None

    return jd.togregorian()


def gregorian_to_jalali_str(g_date: date | datetime | None) -> str:
    """تاریخ میلادی رو به رشته‌ی شمسی خوانا تبدیل می‌کنه، مثلاً 1403/07/01"""
    if g_date is None:
        return "-"
    if isinstance(g_date, datetime):
        g_date = g_date.date()
    jd = jdatetime.date.fromgregorian(date=g_date)
    return jd.strftime("%Y/%m/%d")


def gregorian_datetime_to_jalali_str(g_dt: datetime | None) -> str:
    """تاریخ+ساعت میلادی رو به رشته‌ی شمسی با ساعت تبدیل می‌کنه"""
    if g_dt is None:
        return "-"
    jd = jdatetime.datetime.fromgregorian(datetime=g_dt)
    return jd.strftime("%Y/%m/%d - %H:%M")


def today_jalali_str() -> str:
    return jdatetime.date.today().strftime("%Y/%m/%d")


def today_weekday_name_fa() -> str:
    """اسم روز هفته‌ی امروز به فارسی (برای تشخیص جمعه و ...)"""
    return WEEKDAY_NAMES_FA[datetime.today().weekday()]


def is_friday() -> bool:
    # جمعه در پایتون weekday() == 4
    return datetime.today().weekday() == 4
