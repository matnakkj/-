"""
ابزارهای زمان محلی.
چون سرور معمولاً روی UTC تنظیمه ولی همه‌ی ساعت‌ها (مثل ساعت یادآوری مشاور)
بر اساس ساعت ایران باید حساب بشن، این توابع تبدیل رو انجام میدن.
"""
from datetime import datetime, timedelta, time as dtime
from zoneinfo import ZoneInfo

from config import config

LOCAL_TZ = ZoneInfo(config.TIMEZONE)
UTC_TZ = ZoneInfo("UTC")


def local_now() -> datetime:
    """زمان فعلی با منطقه زمانی محلی (ایران)"""
    return datetime.now(LOCAL_TZ)


def utc_now_naive() -> datetime:
    """معادل چیزی که با datetime.utcnow() توی مدل‌ها ذخیره میشه"""
    return datetime.now(UTC_TZ).replace(tzinfo=None)


def today_range_utc_naive() -> tuple[datetime, datetime]:
    """
    بازه‌ی شروع و پایان «امروز» (بر اساس ساعت محلی ایران) رو به UTC ساده
    (naive، بدون tzinfo، دقیقاً همون فرمتی که توی دیتابیس ذخیره میشه) برمی‌گردونه.
    """
    now_local = local_now()
    start_local = now_local.replace(hour=0, minute=0, second=0, microsecond=0)
    end_local = start_local + timedelta(days=1)

    start_utc = start_local.astimezone(UTC_TZ).replace(tzinfo=None)
    end_utc = end_local.astimezone(UTC_TZ).replace(tzinfo=None)
    return start_utc, end_utc


def report_day_range_utc_naive() -> tuple[datetime, datetime]:
    """
    بازه‌ی «روز گزارش‌کاری» رو برمی‌گردونه که برخلاف today_range_utc_naive
    از نیمه‌شب شروع نمیشه، بلکه از ساعت config.REPORT_DAY_RESET_HOUR
    (پیش‌فرض ۱۴:۰۰).

    مثال با REPORT_DAY_RESET_HOUR=14:
        - الان ساعت ۱۲ ظهره -> هنوز به ریست امروز نرسیدیم
          -> بازه از ۱۴:۰۰ دیروز تا ۱۴:۰۰ امروز
        - الان ساعت ۱۶ (۴ بعدازظهر) -> از ریست امروز گذشتیم
          -> بازه از ۱۴:۰۰ امروز تا ۱۴:۰۰ فردا
    """
    now_local = local_now()
    reset_today_local = now_local.replace(
        hour=config.REPORT_DAY_RESET_HOUR, minute=0, second=0, microsecond=0
    )

    if now_local >= reset_today_local:
        start_local = reset_today_local
    else:
        start_local = reset_today_local - timedelta(days=1)

    end_local = start_local + timedelta(days=1)

    start_utc = start_local.astimezone(UTC_TZ).replace(tzinfo=None)
    end_utc = end_local.astimezone(UTC_TZ).replace(tzinfo=None)
    return start_utc, end_utc


def is_current_local_time(target: dtime, tolerance_minutes: int = 1) -> bool:
    """
    چک می‌کنه ساعت فعلی محلی دقیقاً (با کمی تلورانس) برابر با target هست یا نه.
    برای استفاده توی جاب‌های زمان‌بندی‌شده‌ای که هر دقیقه اجرا میشن.
    """
    now_local = local_now()
    now_minutes = now_local.hour * 60 + now_local.minute
    target_minutes = target.hour * 60 + target.minute
    return abs(now_minutes - target_minutes) < tolerance_minutes


def hours_since_utc_naive(dt: datetime) -> float:
    """چند ساعت از یک datetime ذخیره‌شده (UTC ساده) تا الان گذشته"""
    delta = utc_now_naive() - dt
    return delta.total_seconds() / 3600
