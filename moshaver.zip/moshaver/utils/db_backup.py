"""
پشتیبان‌گیری و بازگردانی کامل دیتابیس با ابزارهای خط‌فرمان PostgreSQL
(pg_dump / psql). این دو ابزار به‌طور پیش‌فرض همراه نصب پستگرس روی سرور
می‌آیند، پس نیازی به نصب جدا نیست.
"""
import asyncio
import os
from urllib.parse import urlparse, unquote

from config import config


def _get_pg_conn_params() -> dict:
    # DATABASE_URL به شکل: postgresql+asyncpg://user:pass@host:port/dbname
    # توجه: username/password ممکنه توی URL درصد-انکود شده باشن (مثلاً @ بشه %40)
    # پس باید unquote بشن، وگرنه pg_dump/psql پسورد اشتباه می‌بینه.
    url = config.DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")
    parsed = urlparse(url)
    return {
        "host": parsed.hostname or "localhost",
        "port": str(parsed.port or 5432),
        "user": unquote(parsed.username or ""),
        "password": unquote(parsed.password or ""),
        "dbname": parsed.path.lstrip("/"),
    }


async def create_backup(output_path: str) -> None:
    """یک فایل SQL کامل از کل دیتابیس فعلی می‌سازه (ساختار + داده‌ها)."""
    params = _get_pg_conn_params()
    env = os.environ.copy()
    env["PGPASSWORD"] = params["password"]

    cmd = [
        "pg_dump",
        "-h", params["host"], "-p", params["port"],
        "-U", params["user"], "-d", params["dbname"],
        "--clean", "--if-exists", "-F", "p",
        "-f", output_path,
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"pg_dump failed: {stderr.decode(errors='ignore')}")


async def restore_backup(input_path: str) -> None:
    """دیتابیس فعلی رو با محتوای فایل پشتیبان جایگزین می‌کنه (کاملاً بازنویسی می‌شه)."""
    params = _get_pg_conn_params()
    env = os.environ.copy()
    env["PGPASSWORD"] = params["password"]

    cmd = [
        "psql",
        "-h", params["host"], "-p", params["port"],
        "-U", params["user"], "-d", params["dbname"],
        "-f", input_path,
    ]
    proc = await asyncio.create_subprocess_exec(
        *cmd, env=env, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    _, stderr = await proc.communicate()
    if proc.returncode != 0:
        raise RuntimeError(f"psql restore failed: {stderr.decode(errors='ignore')}")
