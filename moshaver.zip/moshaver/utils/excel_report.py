"""
ساخت فایل اکسل گزارش ۳۰ روز گذشته (برای پنل مدیر).
"""
from datetime import date as date_type

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

from database.models import ReportStatus
from utils.jalali import gregorian_to_jalali_str

CHECKED_FILL = PatternFill("solid", start_color="C6EFCE")
PENDING_FILL = PatternFill("solid", start_color="FFEB9C")


def build_monthly_report_excel(days: list[date_type], advisors_data: list[dict], output_path: str) -> str:
    wb = Workbook()

    # ---------------- شیت جزئیات روزانه ----------------
    ws1 = wb.active
    ws1.title = "جزئیات روزانه"
    ws1.sheet_view.rightToLeft = True

    header = ["مشاور", "دانش‌آموز"] + [gregorian_to_jalali_str(d) for d in days]
    ws1.append(header)
    for cell in ws1[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    for adv in advisors_data:
        for student in adv["students"]:
            row = [adv["advisor_name"], student["name"]]
            for status in student["day_statuses"]:
                if status is None:
                    row.append("")
                elif status == ReportStatus.CHECKED:
                    row.append("✓")
                else:
                    row.append("!")
            ws1.append(row)

            row_idx = ws1.max_row
            for col_idx, status in enumerate(student["day_statuses"], start=3):
                cell = ws1.cell(row=row_idx, column=col_idx)
                cell.alignment = Alignment(horizontal="center")
                if status == ReportStatus.CHECKED:
                    cell.fill = CHECKED_FILL
                elif status is not None:
                    cell.fill = PENDING_FILL

    ws1.column_dimensions["A"].width = 22
    ws1.column_dimensions["B"].width = 22
    for i in range(3, 3 + len(days)):
        ws1.column_dimensions[get_column_letter(i)].width = 11

    # ---------------- شیت امتیازهای نظرسنجی ----------------
    ws3 = wb.create_sheet("امتیازهای نظرسنجی")
    ws3.sheet_view.rightToLeft = True

    header3 = ["مشاور", "دانش‌آموز"] + [gregorian_to_jalali_str(d) for d in days]
    ws3.append(header3)
    for cell in ws3[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    for adv in advisors_data:
        for student in adv["students"]:
            row = [adv["advisor_name"], student["name"]]
            for score in student.get("day_scores", []):
                row.append(score if score is not None else "")
            ws3.append(row)
            row_idx = ws3.max_row
            for col_idx in range(3, 3 + len(days)):
                ws3.cell(row=row_idx, column=col_idx).alignment = Alignment(horizontal="center")

    ws3.column_dimensions["A"].width = 22
    ws3.column_dimensions["B"].width = 22
    for i in range(3, 3 + len(days)):
        ws3.column_dimensions[get_column_letter(i)].width = 11

    # ---------------- شیت خلاصه مشاوران ----------------
    ws2 = wb.create_sheet("خلاصه مشاوران")
    ws2.sheet_view.rightToLeft = True
    ws2.append([
        "مشاور", "تعداد دانش‌آموز", "گزارش ارسالی (۳۰روز)",
        "بررسی‌شده", "درصد بررسی", "میانگین امتیاز ۳۰ روز گذشته (از ۱۰)",
    ])
    for cell in ws2[1]:
        cell.font = Font(bold=True)
        cell.alignment = Alignment(horizontal="center")

    for adv in advisors_data:
        percentage = (
            round(adv["total_checked"] / adv["total_sent"] * 100, 1)
            if adv["total_sent"] else 0
        )
        ws2.append([
            adv["advisor_name"],
            len(adv["students"]),
            adv["total_sent"],
            adv["total_checked"],
            f"{percentage}%",
            adv["avg_rating"] if adv["avg_rating"] is not None else "-",
        ])

    for col in "ABCDEF":
        ws2.column_dimensions[col].width = 22

    wb.save(output_path)
    return output_path
