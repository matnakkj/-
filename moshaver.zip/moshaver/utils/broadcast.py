"""
ابزار مشترک برای ارسال هم‌زمان پیام به تعداد بالایی از چت‌ها، بدون اینکه
از سقف نرخ ارسال تلگرام (Rate Limit) رد بشیم و ربات بلاک/محدود بشه.

استفاده در: scheduler.py (یادآوری‌ها، نظرسنجی) و پیام همگانی مدیر.
"""
import asyncio
import logging
from dataclasses import dataclass

from aiogram import Bot

logger = logging.getLogger(__name__)

# حداکثر تعداد درخواست هم‌زمان به تلگرام
_SEND_SEMAPHORE = asyncio.Semaphore(20)


@dataclass
class BroadcastResult:
    success: int = 0
    failed: int = 0


async def _throttled_call(coro_factory) -> bool:
    """coro_factory یه تابع بدون آرگومانه که وقتی صدا زده میشه یه کوروتین می‌سازه"""
    async with _SEND_SEMAPHORE:
        try:
            await coro_factory()
            return True
        except Exception as e:
            logger.error(f"خطا در ارسال پیام همگانی: {e}")
            return False
        finally:
            await asyncio.sleep(0.05)  # ~۲۰ پیام در ثانیه، زیر سقف امن تلگرام


async def broadcast_send_message(bot: Bot, chat_ids: list[int], **send_kwargs) -> BroadcastResult:
    """برای همه‌ی chat_id ها یه send_message با همون kwargs ها می‌فرسته"""
    result = BroadcastResult()
    tasks = [
        _throttled_call(lambda cid=cid: bot.send_message(chat_id=cid, **send_kwargs))
        for cid in chat_ids
    ]
    outcomes = await asyncio.gather(*tasks)
    result.success = sum(1 for ok in outcomes if ok)
    result.failed = sum(1 for ok in outcomes if not ok)
    return result


async def broadcast_copy_message(
    bot: Bot, chat_ids: list[int], from_chat_id: int, message_id: int
) -> BroadcastResult:
    """
    برای همه‌ی chat_id ها پیام مشخص‌شده (با هر نوع محتوایی: متن/عکس/فایل/ویدیو)
    رو کپی می‌کنه. از copy_message استفاده می‌کنیم که برخلاف forward، منبع
    پیام (اسم فرستنده اصلی) رو نشون نمیده.
    """
    result = BroadcastResult()
    tasks = [
        _throttled_call(
            lambda cid=cid: bot.copy_message(
                chat_id=cid, from_chat_id=from_chat_id, message_id=message_id
            )
        )
        for cid in chat_ids
    ]
    outcomes = await asyncio.gather(*tasks)
    result.success = sum(1 for ok in outcomes if ok)
    result.failed = sum(1 for ok in outcomes if not ok)
    return result
