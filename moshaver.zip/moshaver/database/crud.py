"""
توابع پرکاربرد برای خواندن/نوشتن در دیتابیس.
هر تابع خودش session جدا نمی‌گیره؛ session از بیرون (توسط handler) پاس داده میشه
تا بتونیم چند عملیات رو توی یک تراکنش انجام بدیم.
"""
from datetime import datetime

from sqlalchemy import select, and_, delete, update, func
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from datetime import date as date_type

from config import config
from database.models import (
    User, Advisor, StudentProfile, Group, Report, ReportStatus, WeeklyRating, RatingSchedule,
    ContentNode, ContentFile, CallLog, ScheduledCall, ScheduledCallStatus,
)


async def get_user_by_telegram_id(session: AsyncSession, telegram_id: int) -> User | None:
    """
    این تابع خیلی جای پروژه استفاده میشه، برای همین همیشه زنجیره‌ی روابط
    پرکاربرد رو کامل eager-load می‌کنیم تا هیچ‌جا با لود نشدن یه رابطه‌ی
    تودرتو (که باعث خطای MissingGreenlet میشه) کرش نکنیم.
    """
    result = await session.execute(
        select(User)
        .options(
            selectinload(User.advisor_profile).selectinload(Advisor.students),
            selectinload(User.student_profile)
            .selectinload(StudentProfile.advisor)
            .selectinload(Advisor.user),
            selectinload(User.student_profile).selectinload(StudentProfile.group),
        )
        .where(User.telegram_id == telegram_id)
    )
    return result.scalar_one_or_none()


async def get_or_create_user(
    session: AsyncSession,
    telegram_id: int,
    username: str | None = None,
    full_name: str | None = None,
) -> User:
    user = await get_user_by_telegram_id(session, telegram_id)
    if user:
        return user

    user = User(
        telegram_id=telegram_id,
        username=username,
        full_name=full_name,
        is_super_admin=(telegram_id == config.SUPER_ADMIN_ID),
        is_admin=(telegram_id == config.SUPER_ADMIN_ID),
    )
    session.add(user)
    await session.flush()

    # دوباره با selectinload لودش می‌کنیم تا advisor_profile/student_profile
    # درست eager-load بشن و بعداً باعث خطای MissingGreenlet نشن.
    user = await get_user_by_telegram_id(session, telegram_id)
    return user


def resolve_panel(user: User) -> str:
    """
    تشخیص می‌ده الان کدوم پنل باید به کاربر نشون داده بشه.
    اولویت پیش‌فرض: مدیر > مشاور > دانش‌آموز
    ولی اگه کاربر با دکمه‌ی سوییچ، پنل دیگه‌ای رو انتخاب کرده باشه (active_panel)
    همون رو نشون میدیم (به‌شرطی که هنوز به اون پنل دسترسی داشته باشه).
    """
    if user.active_panel == "admin" and user.is_admin:
        return "admin"
    if user.active_panel == "advisor" and user.advisor_profile:
        return "advisor"
    if user.active_panel == "student":
        return "student"

    # پیش‌فرض بدون انتخاب دستی
    if user.is_admin:
        return "admin"
    if user.advisor_profile:
        return "advisor"
    return "student"


def has_multiple_panels(user: User) -> bool:
    """آیا این کاربر بیش از یک پنل داره؟ (برای نمایش دکمه‌ی سوییچ)"""
    panel_count = 1  # همه حداقل پنل دانش‌آموز رو دارن
    if user.is_admin:
        panel_count += 1
    if user.advisor_profile:
        panel_count += 1
    return panel_count > 1


# ---------------------------------------------------------------------------
# مدیران
# ---------------------------------------------------------------------------
async def add_admin(session: AsyncSession, telegram_id: int) -> User:
    user = await get_or_create_user(session, telegram_id)
    user.is_admin = True
    await session.flush()
    return user


async def remove_admin(session: AsyncSession, telegram_id: int) -> bool:
    user = await get_user_by_telegram_id(session, telegram_id)
    if not user or not user.is_admin:
        return False
    if user.is_super_admin:
        return False  # مدیر اصلی قابل حذف نیست
    user.is_admin = False
    await session.flush()
    return True


async def list_admins(session: AsyncSession) -> list[User]:
    result = await session.execute(select(User).where(User.is_admin == True))  # noqa: E712
    return list(result.scalars().all())


# ---------------------------------------------------------------------------
# مشاوران
# ---------------------------------------------------------------------------
async def add_advisor(session: AsyncSession, telegram_id: int, display_name: str | None = None) -> tuple[User | None, str]:
    """
    برمی‌گردونه (user, message) - اگه user موجود نبود یعنی هنوز ربات رو استارت نزده.
    """
    user = await get_user_by_telegram_id(session, telegram_id)
    if not user:
        return None, "این کاربر هنوز ربات را استارت نزده است. ابتدا باید /start را بزند."

    if user.advisor_profile:
        return user, "این کاربر از قبل مشاور است."

    if user.student_profile:
        return None, "این کاربر به‌عنوان دانش‌آموز ثبت شده و نمی‌تواند مشاور شود."

    advisor = Advisor(user_id=user.id, display_name=display_name)
    session.add(advisor)
    await session.flush()
    return user, "مشاور با موفقیت اضافه شد."


def get_advisor_display_name(advisor: Advisor) -> str:
    """
    همیشه از این تابع برای نشون دادن اسم مشاور استفاده کن (توی گزارش‌ها،
    کانال‌ها، اکسل و ...) نه مستقیم از advisor.user.full_name/username.
    اگه مدیر یه اسم دلخواه براش گذاشته باشه همون رو برمی‌گردونه.
    """
    if advisor.display_name:
        return advisor.display_name
    return advisor.user.full_name or advisor.user.username or str(advisor.user.telegram_id)


async def set_advisor_display_name(session: AsyncSession, telegram_id: int, display_name: str) -> bool:
    advisor = await get_advisor_by_telegram_id(session, telegram_id)
    if not advisor:
        return False
    advisor.display_name = display_name.strip()
    await session.flush()
    return True


async def remove_advisor(session: AsyncSession, telegram_id: int) -> str:
    user = await get_user_by_telegram_id(session, telegram_id)
    if not user or not user.advisor_profile:
        return "این کاربر مشاور نیست."

    advisor = user.advisor_profile

    # دانش‌آموزهای این مشاور بدون مشاور می‌مونن تا دستی تخصیص داده بشن
    result = await session.execute(
        select(StudentProfile).where(StudentProfile.advisor_id == advisor.id)
    )
    students = result.scalars().all()
    for student in students:
        student.advisor_id = None

    # گروه‌هایی که این مشاور توشون معرفی شده بود، بدون مشاور می‌مونن
    await session.execute(
        update(Group)
        .where(Group.advisor_id == advisor.id)
        .values(advisor_id=None, advisor_button_clicked=False, is_setup_complete=False)
    )

    # نظرسنجی‌ها، تماس‌ها و تماس‌های زمان‌بندی‌شده‌ی قبلی این مشاور رو پاک می‌کنیم
    # (وگرنه حذفش با خطای Foreign Key مواجه میشه چون این جدول‌ها به advisor_id اشاره می‌کنن)
    await session.execute(delete(WeeklyRating).where(WeeklyRating.advisor_id == advisor.id))
    await session.execute(delete(CallLog).where(CallLog.advisor_id == advisor.id))
    await session.execute(delete(ScheduledCall).where(ScheduledCall.advisor_id == advisor.id))

    await session.delete(advisor)
    await session.flush()
    return f"مشاور حذف شد. {len(students)} دانش‌آموز بدون مشاور باقی ماندند."


async def list_advisors(session: AsyncSession) -> list[Advisor]:
    result = await session.execute(
        select(Advisor)
        .options(
            selectinload(Advisor.user),
            selectinload(Advisor.students).selectinload(StudentProfile.group),
            selectinload(Advisor.students).selectinload(StudentProfile.user),
        )
    )
    return list(result.scalars().all())


async def get_advisor_by_telegram_id(session: AsyncSession, telegram_id: int) -> Advisor | None:
    result = await session.execute(
        select(Advisor)
        .join(User, Advisor.user_id == User.id)
        .options(
            selectinload(Advisor.user).selectinload(User.student_profile),
            selectinload(Advisor.students).selectinload(StudentProfile.group),
            selectinload(Advisor.students).selectinload(StudentProfile.user),
        )
        .where(User.telegram_id == telegram_id)
    )
    return result.scalar_one_or_none()


async def set_advisor_reminder_time(session: AsyncSession, telegram_id: int, reminder_time) -> bool:
    advisor = await get_advisor_by_telegram_id(session, telegram_id)
    if not advisor:
        return False
    advisor.reminder_time = reminder_time
    await session.flush()
    return True


# ---------------------------------------------------------------------------
# گروه‌های مشاوره
# ---------------------------------------------------------------------------
async def get_or_create_group(
    session: AsyncSession,
    telegram_chat_id: int,
    title: str | None = None,
    creator_telegram_id: int | None = None,
) -> Group:
    result = await session.execute(
        select(Group)
        .options(
            selectinload(Group.advisor).selectinload(Advisor.user),
            selectinload(Group.student).selectinload(StudentProfile.user),
        )
        .where(Group.telegram_chat_id == telegram_chat_id)
    )
    group = result.scalar_one_or_none()
    if group:
        if title and group.title != title:
            group.title = title
        if creator_telegram_id and not group.creator_telegram_id:
            group.creator_telegram_id = creator_telegram_id
        await session.flush()
        return group

    group = Group(
        telegram_chat_id=telegram_chat_id,
        title=title,
        creator_telegram_id=creator_telegram_id,
    )
    session.add(group)
    await session.flush()

    result = await session.execute(
        select(Group)
        .options(
            selectinload(Group.advisor).selectinload(Advisor.user),
            selectinload(Group.student).selectinload(StudentProfile.user),
        )
        .where(Group.id == group.id)
    )
    return result.scalar_one()


async def get_group_by_chat_id(session: AsyncSession, telegram_chat_id: int) -> Group | None:
    result = await session.execute(
        select(Group)
        .options(
            selectinload(Group.advisor).selectinload(Advisor.user),
            selectinload(Group.student).selectinload(StudentProfile.user),
        )
        .where(Group.telegram_chat_id == telegram_chat_id)
    )
    return result.scalar_one_or_none()


async def assign_advisor_to_group(session: AsyncSession, group: Group, telegram_id: int) -> str:
    """
    وقتی کسی روی دکمه‌ی «معرفی مشاور» می‌زنه.
    یک نفر نمی‌تونه هم‌زمان هم مشاور باشه هم دانش‌آموز.
    """
    advisor = await get_advisor_by_telegram_id(session, telegram_id)
    if not advisor:
        return "شما به‌عنوان مشاور در سیستم ثبت نشده‌اید. ابتدا باید مدیر شما را به‌عنوان مشاور اضافه کرده باشد."

    user = advisor.user
    if user.student_profile:
        return "این حساب قبلاً به‌عنوان دانش‌آموز ثبت شده و نمی‌تواند هم‌زمان مشاور باشد."

    group.advisor_id = advisor.id
    group.advisor_button_clicked = True

    # اگه دانش‌آموز این گروه از قبل مشخص شده، مشاورش رو هم‌زمان آپدیت کن
    if group.student:
        group.student.advisor_id = advisor.id

    await _finalize_group_setup_if_ready(session, group)
    await session.flush()
    return "ok"


async def assign_student_to_group(session: AsyncSession, session_user: User, group: Group) -> str:
    """
    وقتی کسی روی دکمه‌ی «معرفی دانش‌آموز» می‌زنه.
    یک نفر نمی‌تونه هم‌زمان هم مشاور باشه هم دانش‌آموز.
    اگه از قبل توی گروه دیگه‌ای دانش‌آموز مشاور دیگه‌ای بوده، مشاورش عوض میشه
    (طبق تصمیم گرفته‌شده: مشاور قبلی پاک و مشاور جدید جایگزین میشه).
    """
    if session_user.advisor_profile:
        return "این حساب قبلاً به‌عنوان مشاور ثبت شده و نمی‌تواند هم‌زمان دانش‌آموز باشد."

    # به‌جای اتکا به session_user.student_profile (که ممکنه در برخی حالت‌ها
    # هنوز توی حافظه رفرش نشده باشه)، مستقیم از دیتابیس چک می‌کنیم.
    result = await session.execute(
        select(StudentProfile).where(StudentProfile.user_id == session_user.id)
    )
    student = result.scalar_one_or_none()
    if not student:
        student = StudentProfile(user_id=session_user.id)
        session.add(student)
        await session.flush()

    # اطلاعاتی که سازنده گروه قبلاً وارد کرده بود رو کپی کن
    student.full_name = group.pending_full_name
    student.phone = group.pending_phone
    student.grade = group.pending_grade
    student.start_date = group.pending_start_date

    student.group = group  # به‌جای ست کردن group_id خام، از relationship استفاده می‌کنیم
    # تا سمت دیگه‌ی رابطه (group.student) هم بلافاصله توی حافظه sync بشه
    student.advisor_id = group.advisor_id  # اگه مشاور گروه از قبل مشخص بود

    group.student_button_clicked = True

    await _finalize_group_setup_if_ready(session, group)
    await session.flush()
    return "ok"


async def _finalize_group_setup_if_ready(session: AsyncSession, group: Group) -> None:
    if group.advisor_button_clicked and group.student_button_clicked:
        group.is_setup_complete = True


# ---------------------------------------------------------------------------
# گزارش‌کار روزانه
# ---------------------------------------------------------------------------
async def create_report(session: AsyncSession, student_id: int, group_id: int, message_id: int) -> Report:
    report = Report(student_id=student_id, group_id=group_id, message_id=message_id)
    session.add(report)
    await session.flush()
    return report


async def has_report_today(session: AsyncSession, student_id: int) -> bool:
    from utils.timeutils import report_day_range_utc_naive

    start, end = report_day_range_utc_naive()
    result = await session.execute(
        select(Report.id)
        .where(
            and_(
                Report.student_id == student_id,
                Report.sent_at >= start,
                Report.sent_at < end,
            )
        )
        .limit(1)
    )
    return result.scalar_one_or_none() is not None


async def get_report_by_group_and_message(
    session: AsyncSession, telegram_chat_id: int, message_id: int
) -> Report | None:
    """
    وقتی مشاور روی یک پیام ریپلای می‌زنه، با message_id همون پیام گزارش رو پیدا می‌کنیم.
    """
    result = await session.execute(
        select(Report)
        .join(Group, Report.group_id == Group.id)
        .options(selectinload(Report.student))
        .where(
            and_(
                Group.telegram_chat_id == telegram_chat_id,
                Report.message_id == message_id,
            )
        )
        .limit(1)
    )
    return result.scalar_one_or_none()


async def mark_report_checked(session: AsyncSession, report: Report) -> None:
    report.status = ReportStatus.CHECKED
    report.checked_at = datetime.utcnow()
    await session.flush()


async def get_students_without_report_today_for_advisor(
    session: AsyncSession, advisor_id: int
) -> list[StudentProfile]:
    """
    نسخه‌ی بهینه: به‌جای یک کوئری جدا برای هر دانش‌آموز (که با تعداد بالای
    دانش‌آموز کند میشه)، فقط ۲ کوئری کلی می‌زنیم.

    نکته: فقط گزارش‌هایی که مال گروه *فعلی* دانش‌آموز هستن حساب میشن،
    وگرنه اگه دانش‌آموزی امروز به گروه/مشاور جدید منتقل شده باشه، گزارش
    قدیمیِ گروه قبلی اشتباهاً «امروز گزارش داده» حساب میشه.
    """
    from utils.timeutils import report_day_range_utc_naive

    result = await session.execute(
        select(StudentProfile)
        .options(selectinload(StudentProfile.group))
        .where(StudentProfile.advisor_id == advisor_id)
    )
    students = list(result.scalars().all())
    if not students:
        return []

    student_ids = [s.id for s in students]
    current_group_map = {s.id: s.group_id for s in students}
    start, end = report_day_range_utc_naive()

    result2 = await session.execute(
        select(Report.student_id, Report.group_id)
        .where(
            and_(
                Report.student_id.in_(student_ids),
                Report.sent_at >= start,
                Report.sent_at < end,
            )
        )
        .distinct()
    )
    reported_ids = {
        row[0] for row in result2.all() if row[1] == current_group_map.get(row[0])
    }

    return [s for s in students if s.id not in reported_ids]


async def get_advisors_with_reminder_time(session: AsyncSession) -> list[Advisor]:
    result = await session.execute(
        select(Advisor)
        .options(selectinload(Advisor.user))
        .where(Advisor.reminder_time.isnot(None))
    )
    return list(result.scalars().all())


async def get_pending_reports_older_than(session: AsyncSession, hours: float) -> list[Report]:
    """
    گزارش‌های چک‌نشده‌ی قدیمی‌تر از `hours` ساعت رو برمی‌گردونه.

    نکته‌ی مهم: فقط گزارش‌هایی رو در نظر می‌گیریم که هنوز مال گروه *فعلی*
    دانش‌آموز باشن (Report.group_id == StudentProfile.group_id). اگه
    دانش‌آموزی به گروه/مشاور جدیدی منتقل بشه، گزارش‌های چک‌نشده‌ی قدیمیِ
    گروه قبلی دیگه معتبر نیستن و نباید برای مشاور جدید (یا حتی مشاور قبلی
    که دیگه ربطی به این دانش‌آموز نداره) یادآوری بفرستن.
    """
    from utils.timeutils import utc_now_naive
    from datetime import timedelta

    cutoff = utc_now_naive() - timedelta(hours=hours)
    result = await session.execute(
        select(Report)
        .join(StudentProfile, Report.student_id == StudentProfile.id)
        .options(
            selectinload(Report.student).selectinload(StudentProfile.advisor).selectinload(Advisor.user),
            selectinload(Report.student).selectinload(StudentProfile.group),
        )
        .where(
            and_(
                Report.status == ReportStatus.PENDING,
                Report.reminder_8h_sent.is_(False),
                Report.sent_at <= cutoff,
                Report.group_id == StudentProfile.group_id,
            )
        )
    )
    return list(result.scalars().all())


async def mark_report_reminder_sent(session: AsyncSession, report: Report) -> None:
    report.reminder_8h_sent = True
    await session.flush()


# ---------------------------------------------------------------------------
# نظرسنجی هفتگی
# ---------------------------------------------------------------------------
async def get_students_with_advisor(session: AsyncSession) -> list[StudentProfile]:
    result = await session.execute(
        select(StudentProfile)
        .options(
            selectinload(StudentProfile.user),
            selectinload(StudentProfile.advisor).selectinload(Advisor.user),
            selectinload(StudentProfile.group),
        )
        .where(StudentProfile.advisor_id.isnot(None))
    )
    return list(result.scalars().all())


async def create_weekly_rating(session: AsyncSession, student_id: int, advisor_id: int, week_date: date_type) -> WeeklyRating:
    rating = WeeklyRating(student_id=student_id, advisor_id=advisor_id, week_date=week_date)
    session.add(rating)
    await session.flush()
    return rating


async def get_rating_by_id(session: AsyncSession, rating_id: int) -> WeeklyRating | None:
    result = await session.execute(
        select(WeeklyRating)
        .options(
            selectinload(WeeklyRating.student).selectinload(StudentProfile.user),
            selectinload(WeeklyRating.student).selectinload(StudentProfile.advisor).selectinload(Advisor.user),
            selectinload(WeeklyRating.student).selectinload(StudentProfile.group),
        )
        .where(WeeklyRating.id == rating_id)
    )
    return result.scalar_one_or_none()


async def set_rating_score(session: AsyncSession, rating: WeeklyRating, score: int) -> None:
    rating.score = score
    await session.flush()


async def set_rating_comment(session: AsyncSession, rating: WeeklyRating, comment: str) -> None:
    rating.comment = comment
    await session.flush()


# ---------------------------------------------------------------------------
# پیام همگانی
# ---------------------------------------------------------------------------
async def get_all_group_chat_ids(session: AsyncSession) -> list[int]:
    result = await session.execute(select(Group.telegram_chat_id))
    return [row[0] for row in result.all()]


async def get_all_user_telegram_ids(session: AsyncSession) -> list[int]:
    result = await session.execute(select(User.telegram_id))
    return [row[0] for row in result.all()]


# ---------------------------------------------------------------------------
# پاکسازی وقتی ربات از گروه حذف میشه یا کاربر بلاکش می‌کنه
# ---------------------------------------------------------------------------
async def delete_group_and_cleanup(session: AsyncSession, telegram_chat_id: int) -> bool:
    """
    وقتی ربات از یک گروه حذف/بن میشه، کل اطلاعات اون گروه (گزارش‌کارها، تماس‌ها،
    تماس‌های زمان‌بندی‌شده) پاک میشه.
    دانش‌آموزِ اون گروه (اگه بود) بدون گروه/مشاور می‌مونه (نه پاک میشه، چون
    ممکنه توی گروه دیگه‌ای دوباره معرفی بشه).
    اگه بعداً ربات دوباره به همین گروه اضافه بشه، کاملاً از نو (مثل گروه جدید) درنظر گرفته میشه.
    """
    group = await get_group_by_chat_id(session, telegram_chat_id)
    if not group:
        return False

    await session.execute(delete(Report).where(Report.group_id == group.id))
    await session.execute(delete(CallLog).where(CallLog.group_id == group.id))
    await session.execute(delete(ScheduledCall).where(ScheduledCall.group_id == group.id))

    if group.student:
        group.student.group_id = None
        group.student.advisor_id = None

    await session.delete(group)
    await session.flush()
    return True


async def delete_user_and_cleanup(session: AsyncSession, telegram_id: int) -> bool:
    """
    وقتی کاربری ربات رو بلاک می‌کنه (یا از پیوی حذفش می‌کنه)، کل اطلاعاتش پاک میشه:
        - اگه مشاور بود: دانش‌آموزها و گروه‌هاش بدون مشاور می‌مونن (نه پاک میشن)،
          ولی نظرسنجی‌ها/تماس‌ها/تماس‌های زمان‌بندی‌شده‌ش پاک میشن
        - اگه دانش‌آموز بود: گزارش‌کارها، نظرسنجی‌ها، تماس‌ها و تماس‌های
          زمان‌بندی‌شده‌ش پاک میشن
        - در نهایت خودِ رکورد User پاک میشه
    اگه بعداً دوباره /start بزنه، کاملاً کاربر جدید درنظر گرفته میشه.
    """
    user = await get_user_by_telegram_id(session, telegram_id)
    if not user:
        return False

    if user.advisor_profile:
        advisor = user.advisor_profile
        await session.execute(
            update(StudentProfile)
            .where(StudentProfile.advisor_id == advisor.id)
            .values(advisor_id=None)
        )
        await session.execute(
            update(Group)
            .where(Group.advisor_id == advisor.id)
            .values(advisor_id=None, advisor_button_clicked=False, is_setup_complete=False)
        )
        await session.execute(delete(WeeklyRating).where(WeeklyRating.advisor_id == advisor.id))
        await session.execute(delete(CallLog).where(CallLog.advisor_id == advisor.id))
        await session.execute(delete(ScheduledCall).where(ScheduledCall.advisor_id == advisor.id))

    if user.student_profile:
        student = user.student_profile
        await session.execute(delete(Report).where(Report.student_id == student.id))
        await session.execute(delete(WeeklyRating).where(WeeklyRating.student_id == student.id))
        await session.execute(delete(CallLog).where(CallLog.student_id == student.id))
        await session.execute(delete(ScheduledCall).where(ScheduledCall.student_id == student.id))

    await session.delete(user)  # cascade به advisor_profile/student_profile
    await session.flush()
    return True


# ---------------------------------------------------------------------------
# آمار و گزارش‌گیری پنل مدیر
# ---------------------------------------------------------------------------
async def get_today_report_stats(session: AsyncSession) -> tuple[int, int]:
    """
    برمی‌گردونه: (تعداد گروه‌های فعالی که برای بازه‌ی گزارش‌کاری امروز گزارش دادن، تعداد کل گروه‌های فعال)
    «گروه فعال» یعنی گروهی که تنظیماتش کامل شده (is_setup_complete).
    """
    from utils.timeutils import report_day_range_utc_naive

    result = await session.execute(
        select(StudentProfile.id)
        .join(Group, StudentProfile.group_id == Group.id)
        .where(Group.is_setup_complete == True)  # noqa: E712
    )
    student_ids = [row[0] for row in result.all()]
    total = len(student_ids)
    if total == 0:
        return 0, 0

    start, end = report_day_range_utc_naive()
    result2 = await session.execute(
        select(Report.student_id)
        .where(
            and_(
                Report.student_id.in_(student_ids),
                Report.sent_at >= start,
                Report.sent_at < end,
            )
        )
        .distinct()
    )
    reported_count = len({row[0] for row in result2.all()})
    return reported_count, total


async def get_advisor_average_rating(session: AsyncSession, advisor_id: int) -> float | None:
    """میانگین امتیازهای این مشاور از ۱۰ (فقط نظرسنجی‌هایی که واقعاً امتیاز داده شدن)"""
    result = await session.execute(
        select(func.avg(WeeklyRating.score)).where(
            and_(WeeklyRating.advisor_id == advisor_id, WeeklyRating.score.isnot(None))
        )
    )
    avg = result.scalar_one_or_none()
    return round(float(avg), 1) if avg is not None else None


async def get_advisor_average_rating_since(session: AsyncSession, advisor_id: int, since_date: date_type) -> float | None:
    """میانگین امتیاز این مشاور فقط از تاریخ since_date به بعد (مثلاً ۳۰ روز گذشته)"""
    result = await session.execute(
        select(func.avg(WeeklyRating.score)).where(
            and_(
                WeeklyRating.advisor_id == advisor_id,
                WeeklyRating.score.isnot(None),
                WeeklyRating.week_date >= since_date,
            )
        )
    )
    avg = result.scalar_one_or_none()
    return round(float(avg), 1) if avg is not None else None


async def get_all_advisors_rating_summary(session: AsyncSession) -> list[dict]:
    """
    برای مدیر: فقط اسم هر مشاور + میانگین کلی (بدون جزئیات دانش‌آموزها).
    """
    advisors = await list_advisors(session)
    summary = []
    for adv in advisors:
        avg = await get_advisor_average_rating(session, adv.id)
        summary.append({
            "advisor_name": get_advisor_display_name(adv),
            "average": avg,
        })
    return summary


async def get_monthly_report_export_data(session: AsyncSession, days_count: int = 30):
    """
    داده‌ی خام برای ساخت اکسل ۳۰ روز گذشته:
        - هر مشاور، دانش‌آموزهاش، و وضعیت روزانه‌ی گزارش‌کارشون (ارسال‌شده/چک‌شده/هیچی)
        - امتیازی که هر دانش‌آموز در هر روز (اگه اون روز نظرسنجی داده باشه) داده
        - میانگین امتیاز مشاور، فقط برای همین ۳۰ روز (نه کل تاریخچه)
    """
    from datetime import timedelta, datetime, time as dtime
    from utils.timeutils import local_now

    today_local = local_now().date()
    days = [today_local - timedelta(days=i) for i in range(days_count - 1, -1, -1)]

    start_dt = datetime.combine(days[0], dtime.min)
    result = await session.execute(select(Report).where(Report.sent_at >= start_dt))
    all_reports = result.scalars().all()

    reports_by_student_day: dict[int, dict] = {}
    for r in all_reports:
        day = r.sent_at.date()
        reports_by_student_day.setdefault(r.student_id, {})[day] = r.status

    result_ratings = await session.execute(
        select(WeeklyRating).where(
            and_(WeeklyRating.week_date >= days[0], WeeklyRating.score.isnot(None))
        )
    )
    all_ratings = result_ratings.scalars().all()
    ratings_by_student_day: dict[int, dict] = {}
    for r in all_ratings:
        ratings_by_student_day.setdefault(r.student_id, {})[r.week_date] = r.score

    advisors = await list_advisors(session)
    data = []
    for adv in advisors:
        avg_rating = await get_advisor_average_rating_since(session, adv.id, days[0])
        students_data = []
        total_sent = 0
        total_checked = 0
        for student in adv.students:
            student_reports = reports_by_student_day.get(student.id, {})
            student_ratings = ratings_by_student_day.get(student.id, {})
            day_statuses = []
            day_scores = []
            for day in days:
                status = student_reports.get(day)
                day_statuses.append(status)
                day_scores.append(student_ratings.get(day))
                if status is not None:
                    total_sent += 1
                    if status == ReportStatus.CHECKED:
                        total_checked += 1
            students_data.append({
                "name": student.full_name or "بدون نام",
                "day_statuses": day_statuses,
                "day_scores": day_scores,
            })
        data.append({
            "advisor_name": get_advisor_display_name(adv),
            "avg_rating": avg_rating,
            "total_sent": total_sent,
            "total_checked": total_checked,
            "students": students_data,
        })
    return days, data


# ---------------------------------------------------------------------------
# تنظیمات زمان‌بندی نظرسنجی هفتگی
# ---------------------------------------------------------------------------
async def get_or_create_rating_schedule(session: AsyncSession) -> RatingSchedule:
    """همیشه فقط یک ردیف (id=1) داریم؛ اگه نبود با مقادیر پیش‌فرض می‌سازیم."""
    result = await session.execute(select(RatingSchedule).where(RatingSchedule.id == 1))
    schedule = result.scalar_one_or_none()
    if schedule:
        return schedule

    schedule = RatingSchedule(id=1, weekday=config.WEEKLY_RATING_WEEKDAY, hour=config.WEEKLY_RATING_HOUR, minute=0)
    session.add(schedule)
    await session.flush()
    return schedule


async def set_rating_schedule(session: AsyncSession, weekday: int, hour: int, minute: int) -> RatingSchedule:
    schedule = await get_or_create_rating_schedule(session)
    schedule.weekday = weekday
    schedule.hour = hour
    schedule.minute = minute
    schedule.updated_at = datetime.utcnow()
    await session.flush()
    return schedule


async def get_rating_response_rate(session: AsyncSession) -> tuple[int, int]:
    """(تعداد کل نظرسنجی‌هایی که جواب داده شدن، تعداد کل نظرسنجی‌های ارسال‌شده)"""
    result = await session.execute(select(func.count(WeeklyRating.id)))
    total = result.scalar_one()

    result2 = await session.execute(
        select(func.count(WeeklyRating.id)).where(WeeklyRating.score.isnot(None))
    )
    responded = result2.scalar_one()
    return responded, total


async def reset_all_ratings(session: AsyncSession) -> int:
    """همه‌ی نظرسنجی‌های هفتگی رو پاک می‌کنه (برای شروع دوباره از صفر). تعداد پاک‌شده رو برمی‌گردونه."""
    result = await session.execute(select(func.count(WeeklyRating.id)))
    count = result.scalar_one()
    await session.execute(delete(WeeklyRating))
    await session.flush()
    return count


# ---------------------------------------------------------------------------
# پاک‌سازی خودکار گزارش‌کارهای قدیمی (برای سبک نگه‌داشتن دیتابیس)
# ---------------------------------------------------------------------------
async def delete_old_reports(session: AsyncSession, days: int = 30) -> int:
    """
    گزارش‌کارهای قدیمی‌تر از `days` روز رو پاک می‌کنه (چیزی که برای عملکرد
    ربات دیگه لازم نیست نگه داشته بشه). تعداد پاک‌شده رو برمی‌گردونه.
    """
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    cutoff = utc_now_naive() - timedelta(days=days)
    result = await session.execute(select(func.count(Report.id)).where(Report.sent_at < cutoff))
    count = result.scalar_one()

    await session.execute(delete(Report).where(Report.sent_at < cutoff))
    await session.flush()
    return count


# ---------------------------------------------------------------------------
# منوی محتوای تودرتو
# ---------------------------------------------------------------------------
async def get_content_children(session: AsyncSession, parent_id: int | None) -> list[ContentNode]:
    result = await session.execute(
        select(ContentNode)
        .where(ContentNode.parent_id == parent_id)
        .order_by(ContentNode.sort_order, ContentNode.id)
    )
    return list(result.scalars().all())


async def get_content_node(session: AsyncSession, node_id: int) -> ContentNode | None:
    result = await session.execute(
        select(ContentNode)
        .options(selectinload(ContentNode.files))
        .where(ContentNode.id == node_id)
    )
    return result.scalar_one_or_none()


async def create_content_node(session: AsyncSession, parent_id: int | None, title: str) -> ContentNode:
    node = ContentNode(parent_id=parent_id, title=title.strip())
    session.add(node)
    await session.flush()
    return node


async def set_content_node_text(session: AsyncSession, node_id: int, text: str) -> None:
    node = await get_content_node(session, node_id)
    if node:
        node.text_content = text.strip()
        await session.flush()


async def add_content_file(
    session: AsyncSession, node_id: int, file_id: str, file_type: str, caption: str | None = None
) -> ContentFile:
    cf = ContentFile(node_id=node_id, file_id=file_id, file_type=file_type, caption=caption)
    session.add(cf)
    await session.flush()
    return cf


async def delete_content_node_recursive(session: AsyncSession, node_id: int) -> int:
    """
    این نود و همه‌ی زیرشاخه‌هاش (به‌صورت بازگشتی) و فایل‌هاشون رو پاک می‌کنه.
    تعداد نودهای پاک‌شده رو برمی‌گردونه.
    """
    to_visit = [node_id]
    all_ids = []
    while to_visit:
        current = to_visit.pop()
        all_ids.append(current)
        result = await session.execute(
            select(ContentNode.id).where(ContentNode.parent_id == current)
        )
        to_visit.extend(row[0] for row in result.all())

    await session.execute(delete(ContentFile).where(ContentFile.node_id.in_(all_ids)))
    await session.execute(delete(ContentNode).where(ContentNode.id.in_(all_ids)))
    await session.flush()
    return len(all_ids)


async def rename_content_node(session: AsyncSession, node_id: int, new_title: str) -> bool:
    node = await get_content_node(session, node_id)
    if not node:
        return False
    node.title = new_title.strip()
    await session.flush()
    return True


# ---------------------------------------------------------------------------
# ثبت و آمار تماس مشاور با دانش‌آموز
# ---------------------------------------------------------------------------
async def has_call_today(session: AsyncSession, student_id: int) -> bool:
    """
    آیا امروز (شبانه‌روز معمولی، نیمه‌شب تا نیمه‌شب - نه بازه‌ی گزارش‌کاری)
    قبلاً برای این دانش‌آموز تماسی ثبت شده؟
    """
    from utils.timeutils import today_range_utc_naive

    start, end = today_range_utc_naive()
    result = await session.execute(
        select(CallLog.id)
        .where(
            and_(
                CallLog.student_id == student_id,
                CallLog.sent_at >= start,
                CallLog.sent_at < end,
            )
        )
        .limit(1)
    )
    return result.scalar_one_or_none() is not None


async def create_call_log(session: AsyncSession, advisor_id: int, student_id: int, group_id: int, message_id: int) -> CallLog:
    log = CallLog(advisor_id=advisor_id, student_id=student_id, group_id=group_id, message_id=message_id)
    session.add(log)
    await session.flush()
    return log


async def get_call_stats_last_30_days(session: AsyncSession) -> list[dict]:
    """برای مدیر: هر مشاور و به‌ازای هر دانش‌آموزش، تعداد تماس در ۳۰ روز گذشته."""
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    cutoff = utc_now_naive() - timedelta(days=30)
    advisors = await list_advisors(session)

    summary = []
    for adv in advisors:
        student_counts = []
        for student in adv.students:
            result = await session.execute(
                select(func.count(CallLog.id)).where(
                    and_(
                        CallLog.advisor_id == adv.id,
                        CallLog.student_id == student.id,
                        CallLog.sent_at >= cutoff,
                    )
                )
            )
            count = result.scalar_one()
            student_counts.append((student.full_name or "بدون نام", count))
        summary.append({
            "advisor_name": get_advisor_display_name(adv),
            "students": student_counts,
        })
    return summary


async def delete_old_call_logs(session: AsyncSession, days: int = 31) -> int:
    """تماس‌های قدیمی‌تر از `days` روز رو پاک می‌کنه (چون آمار فقط برای ۳۰ روز گذشته لازمه)."""
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    cutoff = utc_now_naive() - timedelta(days=days)
    result = await session.execute(select(func.count(CallLog.id)).where(CallLog.sent_at < cutoff))
    count = result.scalar_one()
    await session.execute(delete(CallLog).where(CallLog.sent_at < cutoff))
    await session.flush()
    return count


async def delete_old_scheduled_calls(session: AsyncSession, days: int = 31) -> int:
    """
    تماس‌های زمان‌بندی‌شده‌ی قدیمی‌تر از `days` روز رو پاک می‌کنه، چه جواب داده
    شده باشن چه بی‌پاسخ مونده باشن (چون بعد از این‌همه وقت دیگه معتبر نیستن).
    """
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    cutoff = utc_now_naive() - timedelta(days=days)
    result = await session.execute(
        select(func.count(ScheduledCall.id)).where(ScheduledCall.scheduled_at < cutoff)
    )
    count = result.scalar_one()
    await session.execute(delete(ScheduledCall).where(ScheduledCall.scheduled_at < cutoff))
    await session.flush()
    return count


# ---------------------------------------------------------------------------
# وضعیت گزارش‌کار امروز، برای خودِ مشاور
# ---------------------------------------------------------------------------
async def get_advisor_today_report_status(session: AsyncSession, advisor_id: int) -> list[dict]:
    from utils.timeutils import report_day_range_utc_naive

    result = await session.execute(
        select(StudentProfile).where(StudentProfile.advisor_id == advisor_id)
    )
    students = result.scalars().all()
    if not students:
        return []

    student_ids = [s.id for s in students]
    current_group_map = {s.id: s.group_id for s in students}
    start, end = report_day_range_utc_naive()

    result2 = await session.execute(
        select(Report.student_id, Report.status, Report.group_id).where(
            and_(
                Report.student_id.in_(student_ids),
                Report.sent_at >= start,
                Report.sent_at < end,
            )
        )
    )
    status_map: dict[int, ReportStatus] = {}
    for student_id, status, group_id in result2.all():
        if group_id != current_group_map.get(student_id):
            continue  # این گزارش مال گروه قبلیشه، حساب نمیشه
        if status_map.get(student_id) != ReportStatus.CHECKED:
            status_map[student_id] = status

    output = []
    for s in students:
        st = status_map.get(s.id)
        output.append({
            "name": s.full_name or "بدون نام",
            "sent": st is not None,
            "checked": st == ReportStatus.CHECKED,
        })
    return output


# ---------------------------------------------------------------------------
# تماس زمان‌بندی‌شده
# ---------------------------------------------------------------------------
async def create_scheduled_call(
    session: AsyncSession, advisor_id: int, student_id: int, group_id: int, scheduled_at: datetime
) -> ScheduledCall:
    call = ScheduledCall(
        advisor_id=advisor_id,
        student_id=student_id,
        group_id=group_id,
        scheduled_at=scheduled_at,
    )
    session.add(call)
    await session.flush()
    return call


async def get_scheduled_call(session: AsyncSession, call_id: int) -> ScheduledCall | None:
    result = await session.execute(
        select(ScheduledCall)
        .options(
            selectinload(ScheduledCall.advisor).selectinload(Advisor.user),
            selectinload(ScheduledCall.student).selectinload(StudentProfile.user),
            selectinload(ScheduledCall.group),
        )
        .where(ScheduledCall.id == call_id)
    )
    return result.scalar_one_or_none()


async def set_scheduled_call_confirm_message(session: AsyncSession, call_id: int, message_id: int) -> None:
    call = await get_scheduled_call(session, call_id)
    if call:
        call.confirm_message_id = message_id
        await session.flush()


async def confirm_scheduled_call(session: AsyncSession, call_id: int) -> ScheduledCall | None:
    call = await get_scheduled_call(session, call_id)
    if not call or call.status != ScheduledCallStatus.PENDING:
        return None
    call.status = ScheduledCallStatus.CONFIRMED
    await session.flush()
    return call


async def reject_scheduled_call(session: AsyncSession, call_id: int) -> ScheduledCall | None:
    call = await get_scheduled_call(session, call_id)
    if not call or call.status != ScheduledCallStatus.PENDING:
        return None
    call.status = ScheduledCallStatus.REJECTED
    await session.flush()
    return call


async def answer_scheduled_call_followup(session: AsyncSession, call_id: int, happened: bool) -> ScheduledCall | None:
    call = await get_scheduled_call(session, call_id)
    if not call:
        return None
    call.status = ScheduledCallStatus.DONE_YES if happened else ScheduledCallStatus.DONE_NO
    await session.flush()
    return call


async def get_calls_needing_3h_reminder(session: AsyncSession) -> list[ScheduledCall]:
    """
    فقط تماسی که هم ۳ ساعت (یا کمتر) تا زمانش مونده هم موقع تنظیم شدنش
    واقعاً حداقل ۳ ساعت فاصله داشته (وگرنه این یادآوری اصلاً معنی نداره).
    محاسبه‌ی دقیق فاصله رو توی پایتون انجام می‌دیم چون تفریق دو ستون تاریخ
    مستقیم توی SQL بین SQLite/PostgreSQL رفتار متفاوتی داره.
    """
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    now = utc_now_naive()
    result = await session.execute(
        select(ScheduledCall)
        .options(selectinload(ScheduledCall.group))
        .where(
            and_(
                ScheduledCall.status == ScheduledCallStatus.CONFIRMED,
                ScheduledCall.reminder_3h_sent.is_(False),
                ScheduledCall.scheduled_at > now,
                ScheduledCall.scheduled_at <= now + timedelta(hours=3),
            )
        )
    )
    calls = list(result.scalars().all())
    return [c for c in calls if (c.scheduled_at - c.created_at) >= timedelta(hours=3)]


async def get_calls_needing_30m_reminder(session: AsyncSession) -> list[ScheduledCall]:
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    now = utc_now_naive()
    result = await session.execute(
        select(ScheduledCall)
        .options(selectinload(ScheduledCall.group))
        .where(
            and_(
                ScheduledCall.status == ScheduledCallStatus.CONFIRMED,
                ScheduledCall.reminder_30m_sent.is_(False),
                ScheduledCall.scheduled_at > now,
                ScheduledCall.scheduled_at <= now + timedelta(minutes=30),
            )
        )
    )
    calls = list(result.scalars().all())
    return [c for c in calls if (c.scheduled_at - c.created_at) >= timedelta(minutes=30)]


async def get_calls_needing_followup(session: AsyncSession) -> list[ScheduledCall]:
    from datetime import timedelta
    from utils.timeutils import utc_now_naive

    now = utc_now_naive()
    result = await session.execute(
        select(ScheduledCall)
        .options(selectinload(ScheduledCall.group))
        .where(
            and_(
                ScheduledCall.status == ScheduledCallStatus.CONFIRMED,
                ScheduledCall.followup_asked.is_(False),
                ScheduledCall.scheduled_at + timedelta(minutes=30) <= now,
            )
        )
    )
    return list(result.scalars().all())


async def mark_call_reminder_sent(session: AsyncSession, call_id: int, which: str) -> None:
    call = await get_scheduled_call(session, call_id)
    if not call:
        return
    if which == "3h":
        call.reminder_3h_sent = True
    elif which == "30m":
        call.reminder_30m_sent = True
    elif which == "followup":
        call.followup_asked = True
    await session.flush()
