"""
مدل‌های دیتابیس.

نکته‌ی مهم درباره‌ی نقش‌ها:
    - is_admin روی خود User مشخص میشه (یک فلگ ساده)
    - "مشاور بودن" و "دانش‌آموز بودن" با وجود رکورد Advisor / StudentProfile
      مشخص میشه، نه یک فیلد role ثابت. این باعث میشه یک نفر بتونه هم‌زمان
      مثلاً هم admin باشه هم advisor (طبق تصمیمی که گرفتیم).
    - active_panel آخرین پنلی که کاربر با دکمه‌ی سوییچ انتخاب کرده رو نگه
      می‌داره (فقط برای مدیرهایی که پنل دیگه‌ای هم دارن کاربرد داره).
"""
import enum
from datetime import datetime, date, time

from sqlalchemy import (
    BigInteger, String, Integer, Boolean, DateTime, Date, Time,
    ForeignKey, Text, Enum as SAEnum,
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship


class Base(DeclarativeBase):
    pass


# ---------------------------------------------------------------------------
# کاربران
# ---------------------------------------------------------------------------
class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    username: Mapped[str | None] = mapped_column(String(64), nullable=True)
    full_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)

    is_admin: Mapped[bool] = mapped_column(Boolean, default=False)
    is_super_admin: Mapped[bool] = mapped_column(Boolean, default=False)

    # 'admin' | 'advisor' | 'student' | None (یعنی پیش‌فرض بر اساس اولویت نمایش داده بشه)
    active_panel: Mapped[str | None] = mapped_column(String(16), nullable=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    advisor_profile: Mapped["Advisor"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )
    student_profile: Mapped["StudentProfile"] = relationship(
        back_populates="user", uselist=False, cascade="all, delete-orphan"
    )


# ---------------------------------------------------------------------------
# مشاوران
# ---------------------------------------------------------------------------
class Advisor(Base):
    __tablename__ = "advisors"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)

    # نامی که مدیر برای این مشاور تعیین می‌کنه (نه اسم اکانت تلگرامش).
    # همه‌جای گزارش‌ها/کانال‌ها از این اسم استفاده میشه، نه از یوزرنیم/فول‌نیم تلگرام.
    display_name: Mapped[str | None] = mapped_column(String(128), nullable=True)

    # ساعتی که با /set تنظیم میشه؛ اگه دانش‌آموز تا این ساعت گزارش نفرسته یادآوری میره
    reminder_time: Mapped[time | None] = mapped_column(Time, nullable=True)

    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship(back_populates="advisor_profile")
    students: Mapped[list["StudentProfile"]] = relationship(back_populates="advisor")
    groups: Mapped[list["Group"]] = relationship(back_populates="advisor")


# ---------------------------------------------------------------------------
# دانش‌آموزان
# ---------------------------------------------------------------------------
class StudentProfile(Base):
    __tablename__ = "student_profiles"

    id: Mapped[int] = mapped_column(primary_key=True)
    user_id: Mapped[int] = mapped_column(ForeignKey("users.id"), unique=True)

    full_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    grade: Mapped[str | None] = mapped_column(String(32), nullable=True)   # پایه تحصیلی
    field: Mapped[str | None] = mapped_column(String(64), nullable=True)   # رشته
    start_date: Mapped[date | None] = mapped_column(Date, nullable=True)   # تاریخ شروع (میلادی، نمایش شمسی)

    advisor_id: Mapped[int | None] = mapped_column(ForeignKey("advisors.id"), nullable=True, index=True)
    group_id: Mapped[int | None] = mapped_column(ForeignKey("groups.id"), nullable=True, index=True)

    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    user: Mapped["User"] = relationship(back_populates="student_profile")
    advisor: Mapped["Advisor"] = relationship(back_populates="students")
    group: Mapped["Group"] = relationship(
        back_populates="student", foreign_keys=[group_id]
    )
    reports: Mapped[list["Report"]] = relationship(back_populates="student")
    ratings: Mapped[list["WeeklyRating"]] = relationship(back_populates="student")


# ---------------------------------------------------------------------------
# گروه‌های مشاوره
# ---------------------------------------------------------------------------
class Group(Base):
    __tablename__ = "groups"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_chat_id: Mapped[int] = mapped_column(BigInteger, unique=True, index=True)
    title: Mapped[str | None] = mapped_column(String(128), nullable=True)
    creator_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)

    photo_set: Mapped[bool] = mapped_column(Boolean, default=False)

    # اطلاعاتی که سازنده گروه قبل از معرفی مشاور/دانش‌آموز وارد می‌کنه
    pending_full_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    pending_phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    pending_grade: Mapped[str | None] = mapped_column(String(32), nullable=True)
    pending_start_date: Mapped[date | None] = mapped_column(Date, nullable=True)

    intro_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    advisor_button_clicked: Mapped[bool] = mapped_column(Boolean, default=False)
    student_button_clicked: Mapped[bool] = mapped_column(Boolean, default=False)

    advisor_id: Mapped[int | None] = mapped_column(ForeignKey("advisors.id"), nullable=True, index=True)

    is_setup_complete: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    advisor: Mapped["Advisor"] = relationship(back_populates="groups")
    student: Mapped["StudentProfile"] = relationship(
        back_populates="group", foreign_keys=[StudentProfile.group_id]
    )


# ---------------------------------------------------------------------------
# گزارش‌کار روزانه
# ---------------------------------------------------------------------------
class ReportStatus(str, enum.Enum):
    PENDING = "pending"
    CHECKED = "checked"


class Report(Base):
    __tablename__ = "reports"

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id"), index=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"), index=True)
    message_id: Mapped[int] = mapped_column(BigInteger)

    status: Mapped[ReportStatus] = mapped_column(
        SAEnum(ReportStatus), default=ReportStatus.PENDING
    )
    sent_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)
    checked_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)

    # جلوگیری از ارسال چندباره‌ی یادآوری ۸ ساعته به مشاور
    reminder_8h_sent: Mapped[bool] = mapped_column(Boolean, default=False)

    student: Mapped["StudentProfile"] = relationship(back_populates="reports")


# ---------------------------------------------------------------------------
# پکیج‌ها و پرداخت‌ها
# ---------------------------------------------------------------------------
class Package(Base):
    __tablename__ = "packages"

    id: Mapped[int] = mapped_column(primary_key=True)
    name: Mapped[str] = mapped_column(String(128))
    price: Mapped[int] = mapped_column(Integer)  # تومان
    description: Mapped[str | None] = mapped_column(Text, nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


class PaymentStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"


class Payment(Base):
    __tablename__ = "payments"

    id: Mapped[int] = mapped_column(primary_key=True)
    telegram_id: Mapped[int] = mapped_column(BigInteger)
    package_id: Mapped[int] = mapped_column(ForeignKey("packages.id"))

    full_name: Mapped[str | None] = mapped_column(String(128), nullable=True)
    phone: Mapped[str | None] = mapped_column(String(20), nullable=True)
    grade: Mapped[str | None] = mapped_column(String(32), nullable=True)
    field: Mapped[str | None] = mapped_column(String(64), nullable=True)
    expectation: Mapped[str | None] = mapped_column(Text, nullable=True)  # انتظار از مشاوره

    receipt_file_id: Mapped[str | None] = mapped_column(String(256), nullable=True)
    status: Mapped[PaymentStatus] = mapped_column(
        SAEnum(PaymentStatus), default=PaymentStatus.PENDING
    )
    channel_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    reviewed_by_telegram_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)


# ---------------------------------------------------------------------------
# نظرسنجی هفتگی
# ---------------------------------------------------------------------------
class WeeklyRating(Base):
    __tablename__ = "weekly_ratings"

    id: Mapped[int] = mapped_column(primary_key=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id"), index=True)
    advisor_id: Mapped[int] = mapped_column(ForeignKey("advisors.id"), index=True)

    score: Mapped[int | None] = mapped_column(Integer, nullable=True)
    comment: Mapped[str | None] = mapped_column(Text, nullable=True)
    week_date: Mapped[date] = mapped_column(Date, index=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    student: Mapped["StudentProfile"] = relationship(back_populates="ratings")


# ---------------------------------------------------------------------------
# منوی محتوای تودرتو (مثل «کتب درسی» -> «ریاضی» -> فایل‌ها)
# مدیر می‌تونه دکمه اضافه/حذف کنه و توی هرکدوم فایل یا متن بذاره.
# ---------------------------------------------------------------------------
class ContentNode(Base):
    __tablename__ = "content_nodes"

    id: Mapped[int] = mapped_column(primary_key=True)
    parent_id: Mapped[int | None] = mapped_column(ForeignKey("content_nodes.id"), nullable=True, index=True)
    title: Mapped[str] = mapped_column(String(128))
    text_content: Mapped[str | None] = mapped_column(Text, nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    children: Mapped[list["ContentNode"]] = relationship(
        back_populates="parent", cascade="all, delete-orphan"
    )
    parent: Mapped["ContentNode"] = relationship(back_populates="children", remote_side=[id])
    files: Mapped[list["ContentFile"]] = relationship(
        back_populates="node", cascade="all, delete-orphan"
    )


class ContentFile(Base):
    __tablename__ = "content_files"

    id: Mapped[int] = mapped_column(primary_key=True)
    node_id: Mapped[int] = mapped_column(ForeignKey("content_nodes.id"), index=True)
    file_id: Mapped[str] = mapped_column(String(256))  # آیدی فایل تلگرام
    file_type: Mapped[str] = mapped_column(String(32))  # document/photo/video/audio/voice
    caption: Mapped[str | None] = mapped_column(String(512), nullable=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    node: Mapped["ContentNode"] = relationship(back_populates="files")


# ---------------------------------------------------------------------------
# ثبت تماس مشاور با دانش‌آموز (با هشتگ #تماس، فقط ثبت، بدون یادآوری)
# ---------------------------------------------------------------------------
class CallLog(Base):
    __tablename__ = "call_logs"

    id: Mapped[int] = mapped_column(primary_key=True)
    advisor_id: Mapped[int] = mapped_column(ForeignKey("advisors.id"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id"), index=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"), index=True)
    message_id: Mapped[int] = mapped_column(BigInteger)
    sent_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow, index=True)


# ---------------------------------------------------------------------------
# تماس زمان‌بندی‌شده (مشاور از پنلش برای دانش‌آموز، در هفته‌ی پیش‌رو، تنظیم می‌کنه)
# ---------------------------------------------------------------------------
class ScheduledCallStatus(str, enum.Enum):
    PENDING = "pending"          # منتظر تأیید/رد دانش‌آموز
    CONFIRMED = "confirmed"      # تأیید شده، منتظر زمانش
    REJECTED = "rejected"        # دانش‌آموز رد کرد
    DONE_YES = "done_yes"        # بعد از زمان، دانش‌آموز گفت تماس برقرار شد
    DONE_NO = "done_no"          # بعد از زمان، دانش‌آموز گفت برقرار نشد


class ScheduledCall(Base):
    __tablename__ = "scheduled_calls"

    id: Mapped[int] = mapped_column(primary_key=True)
    advisor_id: Mapped[int] = mapped_column(ForeignKey("advisors.id"), index=True)
    student_id: Mapped[int] = mapped_column(ForeignKey("student_profiles.id"), index=True)
    group_id: Mapped[int] = mapped_column(ForeignKey("groups.id"), index=True)

    scheduled_at: Mapped[datetime] = mapped_column(DateTime, index=True)  # UTC ساده
    status: Mapped[ScheduledCallStatus] = mapped_column(
        SAEnum(ScheduledCallStatus), default=ScheduledCallStatus.PENDING, index=True
    )

    reminder_3h_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    reminder_30m_sent: Mapped[bool] = mapped_column(Boolean, default=False)
    followup_asked: Mapped[bool] = mapped_column(Boolean, default=False)

    confirm_message_id: Mapped[int | None] = mapped_column(BigInteger, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)

    advisor: Mapped["Advisor"] = relationship()
    student: Mapped["StudentProfile"] = relationship()
    group: Mapped["Group"] = relationship()


# ---------------------------------------------------------------------------
# تنظیمات زمان‌بندی نظرسنجی هفتگی (قابل‌تغییر توسط مدیر، فقط یک ردیف)
# ---------------------------------------------------------------------------
class RatingSchedule(Base):
    __tablename__ = "rating_schedule"

    id: Mapped[int] = mapped_column(primary_key=True)
    weekday: Mapped[int] = mapped_column(Integer, default=4)  # ۰=دوشنبه ... ۴=جمعه ... ۶=یکشنبه
    hour: Mapped[int] = mapped_column(Integer, default=12)
    minute: Mapped[int] = mapped_column(Integer, default=0)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=datetime.utcnow)
