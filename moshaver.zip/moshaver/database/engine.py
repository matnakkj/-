"""
اتصال به دیتابیس (PostgreSQL) با SQLAlchemy async.
"""
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker, create_async_engine
from contextlib import asynccontextmanager

from config import config
from database.models import Base

# pool_size/max_overflow رو بالا نگه می‌داریم که زیر بار همزمان زیاد
# (مثلاً صدها درخواست هم‌زمان) درخواست‌ها صف نشن و fail نکنن.
# این تنظیمات فقط برای PostgreSQL معتبرن (SQLite ازشون پشتیبانی نمی‌کنه،
# که فقط برای تست‌های محلی سریع استفاده میشه).
_engine_kwargs = dict(echo=False, future=True)
if config.DATABASE_URL.startswith("postgresql"):
    _engine_kwargs.update(
        pool_size=20,
        max_overflow=30,
        pool_pre_ping=True,  # چک می‌کنه کانکشن‌های راکد/قطع‌شده رو قبل از استفاده
        pool_recycle=1800,
    )

engine = create_async_engine(config.DATABASE_URL, **_engine_kwargs)

async_session_maker = async_sessionmaker(
    engine, expire_on_commit=False, class_=AsyncSession
)


async def init_db() -> None:
    """
    ساخت جداول در صورت عدم وجود.
    توجه: برای پروژه‌ی واقعی و تغییرات آینده‌ی جداول، بهتره از Alembic
    برای migration استفاده بشه. فعلاً برای شروع سریع همین کافیه.
    """
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)


@asynccontextmanager
async def get_session():
    async with async_session_maker() as session:
        yield session
