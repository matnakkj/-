"""
جاب‌های زمان‌بندی‌شده با APScheduler:
    ۱. هر دقیقه: چک می‌کنه آیا الان ساعت یادآوری یکی از مشاوراست، اگه بله
       برای دانش‌آموزانی که امروز گزارش نفرستادن، توی گروه یادآوری می‌فرسته.
    ۲. هر ۱۵ دقیقه: گزارش‌های چک‌نشده‌ای که بیش از ۸ ساعت گذشته رو پیدا
       می‌کنه و به پیوی مشاور یادآوری می‌فرسته.
    ۳. طبق زمان تنظیم‌شده (پیش‌فرض جمعه ۱۲): برای همه‌ی دانش‌آموزهای دارای
       مشاور، نظرسنجی می‌فرسته.
    ۴. هر روز ساعت ۴ صبح: گزارش‌کارها و تماس‌های قدیمی‌تر از ۱ ماه رو پاک
       می‌کنه تا دیتابیس سبک و بهینه بمونه.
    ۵. هر ۵ دقیقه: تماس‌های زمان‌بندی‌شده رو چک می‌کنه (یادآوری ۳ساعته،
       ۳۰دقیقه‌ای، و پیگیری «تماس برقرار شد؟» بعد از زمانشون).

نکته‌ی مقیاس‌پذیری:
    وقتی تعداد گروه‌ها/دانش‌آموزها زیاد باشه (صدها گروه)، اگه پیام‌ها رو
    یکی‌یکی و پشت‌سرهم (sequential await) بفرستیم، کل جاب طولانی میشه.
    برای همین همه‌ی ارسال‌ها هم‌زمان (concurrent) با asyncio.gather انجام
    میشن، ولی با یک Semaphore محدود به ۲۰ درخواست هم‌زمان + کمی تأخیر بین
    هرکدوم، تا از سقف نرخ ارسال تلگرام (Rate Limit) عبور نکنیم و بلاک نشیم.
"""
import asyncio
import logging
from datetime import date

from aiogram import Bot
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from config import config
from database.engine import get_session
from database.crud import (
    get_advisors_with_reminder_time,
    get_students_without_report_today_for_advisor,
    get_pending_reports_older_than,
    mark_report_reminder_sent,
    get_students_with_advisor,
    create_weekly_rating,
    delete_old_reports,
    delete_old_call_logs,
    delete_old_scheduled_calls,
    get_calls_needing_3h_reminder,
    get_calls_needing_30m_reminder,
    get_calls_needing_followup,
    mark_call_reminder_sent,
)
from keyboards.rating import rating_score_keyboard
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton
from utils.timeutils import is_current_local_time, LOCAL_TZ

logger = logging.getLogger(__name__)

# حداکثر تعداد ارسال هم‌زمان به تلگرام (برای رعایت Rate Limit تلگرام)
_SEND_SEMAPHORE = asyncio.Semaphore(20)


async def _throttled_send(bot: Bot, chat_id: int, **kwargs) -> None:
    async with _SEND_SEMAPHORE:
        try:
            await bot.send_message(chat_id=chat_id, **kwargs)
        except Exception as e:
            logger.error(f"خطا در ارسال پیام به {chat_id}: {e}")
        finally:
            # کمی تأخیر تا سرعت کلی ارسال زیر سقف امن تلگرام (~۳۰ پیام/ثانیه) بمونه
            await asyncio.sleep(0.05)


async def job_check_student_reminders(bot: Bot) -> None:
    async with get_session() as session:
        advisors = await get_advisors_with_reminder_time(session)

        tasks = []
        for advisor in advisors:
            if not is_current_local_time(advisor.reminder_time):
                continue
            students = await get_students_without_report_today_for_advisor(session, advisor.id)
            for student in students:
                if not student.group:
                    continue
                tasks.append(
                    _throttled_send(
                        bot,
                        student.group.telegram_chat_id,
                        text="⏰ دانش‌آموز عزیز، هنوز گزارش‌کار امروز خود را ارسال نکرده‌اید.",
                    )
                )

        if tasks:
            logger.info(f"ارسال یادآوری گزارش‌کار به {len(tasks)} گروه...")
            await asyncio.gather(*tasks)


async def job_check_advisor_8h_reminders(bot: Bot) -> None:
    async with get_session() as session:
        reports = await get_pending_reports_older_than(
            session, config.ADVISOR_REPORT_CHECK_DEADLINE_HOURS
        )

        tasks = []
        valid_reports = []
        for report in reports:
            student = report.student
            if not student.advisor:
                continue
            group_title = student.group.title if student.group else "گروه نامشخص"
            tasks.append(
                _throttled_send(
                    bot,
                    student.advisor.user.telegram_id,
                    text=(
                        f"⏰ یادآوری: گزارش‌کار دانش‌آموز در گروه «{group_title}» "
                        f"بیش از {config.ADVISOR_REPORT_CHECK_DEADLINE_HOURS} ساعت است چک نشده."
                    ),
                )
            )
            valid_reports.append(report)

        if tasks:
            logger.info(f"ارسال یادآوری ۸ ساعته به {len(tasks)} مشاور...")
            await asyncio.gather(*tasks)

        for report in valid_reports:
            await mark_report_reminder_sent(session, report)
        if valid_reports:
            await session.commit()


async def job_send_weekly_ratings(bot: Bot) -> None:
    async with get_session() as session:
        students = await get_students_with_advisor(session)
        today = date.today()

        tasks = []
        for student in students:
            rating = await create_weekly_rating(session, student.id, student.advisor_id, today)
            tasks.append(
                _throttled_send(
                    bot,
                    student.user.telegram_id,
                    text="⭐️ لطفاً به مشاور خودتون از ۱ تا ۱۰ امتیاز بدید:",
                    reply_markup=rating_score_keyboard(rating.id),
                )
            )

        await session.commit()  # همه‌ی رکوردهای rating قبل از شروع ارسال ثبت میشن

        if tasks:
            logger.info(f"ارسال نظرسنجی هفتگی به {len(tasks)} دانش‌آموز...")
            await asyncio.gather(*tasks)


async def job_cleanup_old_reports(bot: Bot) -> None:
    """
    گزارش‌کارهای قدیمی‌تر از ۱ ماه رو پاک می‌کنه تا دیتابیس سبک بمونه.
    (یک روز اضافه به‌عنوان حاشیه‌ی امنیت نگه می‌داریم که به بازه‌ی ۳۰ روزه‌ی
    اکسل لطمه نزنه؛ یعنی چیزی که دقیقاً ۳۰ روزشه هنوز موجود می‌مونه)
    """
    async with get_session() as session:
        count = await delete_old_reports(session, days=31)
        count_calls = await delete_old_call_logs(session, days=31)
        count_scheduled = await delete_old_scheduled_calls(session, days=31)
        await session.commit()
    if count:
        logger.info(f"پاک‌سازی خودکار: {count} گزارش‌کار قدیمی‌تر از ۱ ماه حذف شد.")
    if count_calls:
        logger.info(f"پاک‌سازی خودکار: {count_calls} تماس قدیمی‌تر از ۱ ماه حذف شد.")
    if count_scheduled:
        logger.info(f"پاک‌سازی خودکار: {count_scheduled} تماس زمان‌بندی‌شده‌ی قدیمی حذف شد.")


async def job_check_scheduled_calls(bot: Bot) -> None:
    """
    هر ۵ دقیقه چک می‌کنه:
        - تماس‌هایی که ۳ ساعت مونده (و واقعاً از قبل این‌قدر فاصله داشتن)
        - تماس‌هایی که نیم ساعت مونده (همون‌طور)
        - تماس‌هایی که نیم ساعت از زمانشون گذشته -> پیگیری «تماس برقرار شد؟»
    """
    async with get_session() as session:
        need_3h = await get_calls_needing_3h_reminder(session)
        for call in need_3h:
            try:
                await bot.send_message(
                    call.group.telegram_chat_id,
                    "⏰ یادآوری: تا ۳ ساعت دیگر تماس زمان‌بندی‌شده دارید.",
                )
            except Exception as e:
                logger.error(f"خطا در ارسال یادآوری ۳ساعته تماس: {e}")
            await mark_call_reminder_sent(session, call.id, "3h")
        if need_3h:
            await session.commit()

        need_30m = await get_calls_needing_30m_reminder(session)
        for call in need_30m:
            try:
                await bot.send_message(
                    call.group.telegram_chat_id,
                    "⏰ یادآوری: تا نیم ساعت دیگر تماس زمان‌بندی‌شده دارید، آماده باشید.",
                )
            except Exception as e:
                logger.error(f"خطا در ارسال یادآوری ۳۰دقیقه‌ای تماس: {e}")
            await mark_call_reminder_sent(session, call.id, "30m")
        if need_30m:
            await session.commit()

        need_followup = await get_calls_needing_followup(session)
        for call in need_followup:
            kb = InlineKeyboardMarkup(inline_keyboard=[[
                InlineKeyboardButton(text="✅ بله", callback_data=f"schedcall:followup:{call.id}:yes"),
                InlineKeyboardButton(text="❌ خیر", callback_data=f"schedcall:followup:{call.id}:no"),
            ]])
            try:
                await bot.send_message(
                    call.group.telegram_chat_id,
                    "آیا تماس زمان‌بندی‌شده برقرار شد؟ (فقط دانش‌آموز پاسخ دهد)",
                    reply_markup=kb,
                )
            except Exception as e:
                logger.error(f"خطا در ارسال پیگیری تماس: {e}")
            await mark_call_reminder_sent(session, call.id, "followup")
        if need_followup:
            await session.commit()


def setup_scheduler(
    bot: Bot,
    rating_weekday: int = None,
    rating_hour: int = None,
    rating_minute: int = 0,
) -> AsyncIOScheduler:
    """
    rating_weekday/hour/minute: زمان نظرسنجی هفتگی. اگه داده نشه از config پیش‌فرض
    استفاده میشه. مقدار واقعی (اگه مدیر تغییرش داده باشه) از دیتابیس در bot.py
    خونده و پاس داده میشه.
    """
    if rating_weekday is None:
        rating_weekday = config.WEEKLY_RATING_WEEKDAY
    if rating_hour is None:
        rating_hour = config.WEEKLY_RATING_HOUR

    scheduler = AsyncIOScheduler(timezone=LOCAL_TZ)

    scheduler.add_job(
        job_check_student_reminders, CronTrigger(minute="*", timezone=LOCAL_TZ),
        args=[bot], id="check_student_reminders", replace_existing=True,
        max_instances=1,  # جلوگیری از اجرای هم‌پوشان اگه اجرای قبلی هنوز تموم نشده
    )
    scheduler.add_job(
        job_check_advisor_8h_reminders, CronTrigger(minute="*/15", timezone=LOCAL_TZ),
        args=[bot], id="check_advisor_8h_reminders", replace_existing=True,
        max_instances=1,
    )
    scheduler.add_job(
        job_send_weekly_ratings,
        CronTrigger(
            day_of_week=rating_weekday,
            hour=rating_hour,
            minute=rating_minute,
            timezone=LOCAL_TZ,
        ),
        args=[bot], id="send_weekly_ratings", replace_existing=True,
        max_instances=1,
    )
    scheduler.add_job(
        job_cleanup_old_reports, CronTrigger(hour=4, minute=0, timezone=LOCAL_TZ),
        args=[bot], id="cleanup_old_reports", replace_existing=True,
        max_instances=1,
    )
    scheduler.add_job(
        job_check_scheduled_calls, CronTrigger(minute="*/5", timezone=LOCAL_TZ),
        args=[bot], id="check_scheduled_calls", replace_existing=True,
        max_instances=1,
    )

    return scheduler
