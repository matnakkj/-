"""
تنظیمات کلی ربات.
همه‌ی مقادیر حساس از فایل .env خونده میشن، هیچ‌وقت مستقیم توی کد ننویس.
"""
from dataclasses import dataclass, field
from dotenv import load_dotenv
import os

load_dotenv()


def _get_int_list(env_name: str) -> list[int]:
    raw = os.getenv(env_name, "")
    if not raw.strip():
        return []
    return [int(x.strip()) for x in raw.split(",") if x.strip()]


@dataclass
class Config:
    # --- ربات ---
    BOT_TOKEN: str = os.getenv("BOT_TOKEN", "")

    # --- مدیر اصلی (Super Admin) ---
    # فقط این آیدی حق افزودن/حذف مدیرهای دیگه رو داره
    SUPER_ADMIN_ID: int = int(os.getenv("SUPER_ADMIN_ID", "0"))

    # --- دیتابیس ---
    DATABASE_URL: str = os.getenv(
        "DATABASE_URL",
        "postgresql+asyncpg://moshaver_user:changeme@localhost:5432/moshaver_db",
    )

    # --- کانال‌های اختصاصی ---
    ANONYMOUS_CHANNEL_ID: int = int(os.getenv("ANONYMOUS_CHANNEL_ID", "0"))       # پیام‌های ناشناس
    RATING_CHANNEL_ID: int = int(os.getenv("RATING_CHANNEL_ID", "0"))             # نظرسنجی هفتگی مشاوران
    REGISTRATION_CHANNEL_ID: int = int(os.getenv("REGISTRATION_CHANNEL_ID", "0")) # رسیدهای ثبت‌نام / خرید پکیج
    COMPLAINTS_CHANNEL_ID: int = int(os.getenv("COMPLAINTS_CHANNEL_ID", "0"))     # انتقاد دانش‌آموز از مشاور

    # --- عکس ثابت گروه ---
    GROUP_PHOTO_PATH: str = os.getenv("GROUP_PHOTO_PATH", "assets/group_photo.jpg")

    # --- زمان‌بندی ---
    TIMEZONE: str = os.getenv("TIMEZONE", "Asia/Tehran")
    WEEKLY_RATING_WEEKDAY: int = 4   # جمعه (Monday=0 ... Sunday=6 -> Friday=4)
    WEEKLY_RATING_HOUR: int = 12

    ADVISOR_REPORT_CHECK_DEADLINE_HOURS: int = 8  # یادآوری به مشاور بعد این‌قدر ساعت

    # «روز گزارش‌کاری» از نیمه‌شب حساب نمیشه، بلکه از این ساعت شروع میشه.
    # یعنی گزارش ساعت ۱۲ ظهر هنوز مال بازه‌ی قبلیه، ولی گزارش ساعت ۱۶ مال بازه‌ی جدید.
    REPORT_DAY_RESET_HOUR: int = 14


config = Config()
