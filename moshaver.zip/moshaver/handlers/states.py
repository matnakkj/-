from aiogram.fsm.state import State, StatesGroup


class AddAdminStates(StatesGroup):
    waiting_for_id = State()


class RemoveAdminStates(StatesGroup):
    waiting_for_id = State()


class AddAdvisorStates(StatesGroup):
    waiting_for_id = State()
    waiting_for_display_name = State()


class RemoveAdvisorStates(StatesGroup):
    waiting_for_id = State()


class AddStudentManualStates(StatesGroup):
    waiting_for_id = State()
    waiting_for_full_name = State()
    waiting_for_grade = State()
    waiting_for_field = State()
    waiting_for_start_date = State()
    waiting_for_advisor_id = State()


class SetReminderStates(StatesGroup):
    waiting_for_time = State()


class AnonymousMessageStates(StatesGroup):
    waiting_for_text = State()


class ComplaintStates(StatesGroup):
    waiting_for_text = State()


class GroupSetupStates(StatesGroup):
    waiting_for_full_name = State()
    waiting_for_phone = State()
    waiting_for_grade = State()
    waiting_for_start_date = State()


class WeeklyRatingStates(StatesGroup):
    waiting_for_comment = State()


class BroadcastStates(StatesGroup):
    waiting_for_content = State()
    waiting_for_confirmation = State()


class RatingScheduleStates(StatesGroup):
    waiting_for_time = State()


class BackupRestoreStates(StatesGroup):
    waiting_for_file = State()


class ContentManageStates(StatesGroup):
    waiting_for_new_title = State()
    waiting_for_rename = State()
    waiting_for_text = State()
    waiting_for_file = State()


class ScheduleCallStates(StatesGroup):
    waiting_for_time = State()
