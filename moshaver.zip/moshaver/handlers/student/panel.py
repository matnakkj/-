"""
پنل دانش‌آموز.
در این فاز، فقط ساختار منو و «پیام ناشناس» و «وضعیت مشاوره من» پیاده‌سازی شده.
بقیه‌ی قابلیت‌ها (معدل، تراز، بانک سوال، معرفی رشته، سوالات کنکور، خرید مشاور)
در فاز بعدی (بخش ۳) به‌طور کامل جزئیاتش مشخص و پیاده می‌شود.
"""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
import logging

from config import config
from database.engine import get_session
from database.crud import get_user_by_telegram_id, get_advisor_display_name
from handlers.states import AnonymousMessageStates, ComplaintStates
from keyboards.menus import BTN, cancel_menu, student_main_menu
from utils.jalali import gregorian_to_jalali_str

router = Router(name="student_panel")


PLACEHOLDER_BUTTONS = {
    BTN.STUDENT_GPA: "📊 محاسبه معدل نهایی",
    BTN.STUDENT_RANK: "📈 محاسبه تراز",
    BTN.STUDENT_TEST_BANK: "📝 بانک سوال تستی",
    BTN.STUDENT_ESSAY_BANK: "📚 بانک سوال تشریحی",
    BTN.STUDENT_FIELDS_INTRO: "🎓 معرفی رشته‌ها",
    BTN.STUDENT_KONKUR_QA: "📄 سوالات و پاسخنامه کنکور",
    BTN.STUDENT_BUY_ADVISOR: "💳 خرید مشاور",
}


async def _has_advisor(telegram_id: int) -> bool:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, telegram_id)
        return bool(user and user.student_profile and user.student_profile.advisor_id)


@router.message(F.text.in_(PLACEHOLDER_BUTTONS.keys()))
async def placeholder_handler(message: Message) -> None:
    title = PLACEHOLDER_BUTTONS[message.text]
    await message.answer(f"{title}\n\nاین بخش در فاز بعدی توسعه تکمیل می‌شود.")


@router.message(F.text == BTN.STUDENT_MY_STATUS)
async def my_status(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)

    if not user or not user.student_profile or not user.student_profile.advisor:
        await message.answer("شما در حال حاضر مشاور فعالی ندارید.")
        return

    sp = user.student_profile
    advisor_name = get_advisor_display_name(sp.advisor)
    text = (
        f"📌 وضعیت مشاوره شما:\n\n"
        f"نام: {sp.full_name or '-'}\n"
        f"شماره تماس: {sp.phone or '-'}\n"
        f"پایه: {sp.grade or '-'}\n"
        f"رشته: {sp.field or '-'}\n"
        f"تاریخ شروع: {gregorian_to_jalali_str(sp.start_date)}\n"
        f"مشاور: {advisor_name}\n"
    )
    await message.answer(text)


# --------------------------- پیام ناشناس ---------------------------
@router.message(F.text == BTN.STUDENT_ANONYMOUS)
async def anonymous_start(message: Message, state: FSMContext) -> None:
    await state.set_state(AnonymousMessageStates.waiting_for_text)
    await message.answer(
        "پیام خود را ارسال کنید (متن، عکس، فایل یا ویس). "
        "این پیام بدون نام شما در کانال منتشر می‌شود.",
        reply_markup=cancel_menu(),
    )


@router.message(AnonymousMessageStates.waiting_for_text, F.text == BTN.BACK)
async def anonymous_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    has_advisor = await _has_advisor(message.from_user.id)
    await message.answer("لغو شد.", reply_markup=student_main_menu(has_advisor=has_advisor))


@router.message(AnonymousMessageStates.waiting_for_text)
async def anonymous_finish(message: Message, state: FSMContext) -> None:
    await state.clear()
    has_advisor = await _has_advisor(message.from_user.id)
    menu = student_main_menu(has_advisor=has_advisor)

    if not config.ANONYMOUS_CHANNEL_ID:
        await message.answer("قابلیت پیام ناشناس هنوز توسط مدیریت فعال نشده است.", reply_markup=menu)
        return

    try:
        # اول یک هدر برای مشخص شدن نوع پیام می‌فرستیم
        await message.bot.send_message(
            chat_id=config.ANONYMOUS_CHANNEL_ID,
            text="✉️ پیام ناشناس جدید:",
        )
        # سپس خود پیام (متن، عکس، فایل، ویس، ویدیو و ...) رو کپی می‌کنیم.
        # copy_to بر خلاف forward، نام/آیدی فرستنده رو نشون نمیده، پس ناشناس می‌مونه.
        await message.copy_to(chat_id=config.ANONYMOUS_CHANNEL_ID)
        await message.answer("✅ پیام شما با موفقیت و بدون نام شما ارسال شد.", reply_markup=menu)
    except Exception as e:
        logging.getLogger(__name__).error(f"خطا در ارسال پیام ناشناس به کانال: {e}")
        await message.answer("خطا در ارسال پیام. لطفاً بعداً دوباره تلاش کنید.", reply_markup=menu)


# --------------------------- ثبت انتقاد از مشاور ---------------------------
@router.message(F.text == BTN.STUDENT_COMPLAINT)
async def complaint_start(message: Message, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)

    if not user or not user.student_profile or not user.student_profile.advisor:
        await message.answer("شما در حال حاضر مشاور فعالی ندارید.")
        return

    await state.set_state(ComplaintStates.waiting_for_text)
    await message.answer(
        "انتقاد یا نظر خودتون درباره‌ی مشاورتون رو بنویسید. این پیام مستقیم برای مدیریت ارسال می‌شود:",
        reply_markup=cancel_menu(),
    )


@router.message(ComplaintStates.waiting_for_text, F.text == BTN.BACK)
async def complaint_cancel(message: Message, state: FSMContext) -> None:
    await state.clear()
    has_advisor = await _has_advisor(message.from_user.id)
    await message.answer("لغو شد.", reply_markup=student_main_menu(has_advisor=has_advisor))


@router.message(ComplaintStates.waiting_for_text)
async def complaint_finish(message: Message, state: FSMContext) -> None:
    await state.clear()
    has_advisor = await _has_advisor(message.from_user.id)
    menu = student_main_menu(has_advisor=has_advisor)

    if not message.text:
        await message.answer("لطفاً انتقادتون رو به‌صورت متن ارسال کنید.", reply_markup=menu)
        return

    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.student_profile or not user.student_profile.advisor:
            await message.answer("خطا: اطلاعات مشاور شما پیدا نشد.", reply_markup=menu)
            return

        sp = user.student_profile
        student_name = sp.full_name or user.username or str(user.telegram_id)
        advisor_name = get_advisor_display_name(sp.advisor)
        group_title = sp.group.title if sp.group else "-"

    if not config.COMPLAINTS_CHANNEL_ID:
        await message.answer("این قابلیت هنوز توسط مدیریت فعال نشده است.", reply_markup=menu)
        return

    try:
        await message.bot.send_message(
            chat_id=config.COMPLAINTS_CHANNEL_ID,
            text=(
                f"📢 انتقاد جدید از مشاور\n\n"
                f"دانش‌آموز: {student_name}\n"
                f"مشاور: {advisor_name}\n"
                f"گروه: {group_title}\n\n"
                f"متن انتقاد:\n{message.text}"
            ),
        )
        await message.answer("✅ انتقاد شما برای مدیریت ارسال شد.", reply_markup=menu)
    except Exception as e:
        logging.getLogger(__name__).error(f"خطا در ارسال انتقاد به کانال: {e}")
        await message.answer("خطا در ارسال. لطفاً بعداً دوباره تلاش کنید.", reply_markup=menu)
