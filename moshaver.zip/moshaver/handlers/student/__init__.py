from aiogram import Router

from handlers.student import panel, rating, content_browse

router = Router(name="student")
router.include_router(panel.router)
router.include_router(rating.router)
router.include_router(content_browse.router)
