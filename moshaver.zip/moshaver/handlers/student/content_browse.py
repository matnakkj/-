"""
مشاهده‌ی منوی محتوای تودرتو توسط دانش‌آموز (فقط خوانا؛ ساخت و ویرایش
فقط دست مدیره - handlers/admin/content.py).

مثل پنل مدیر، اینجا هم فقط یک پیام (پیام مرورگر) داریم که با هر کلیک
ادیت میشه؛ پیام جدید ساخته نمیشه. فقط فایل‌های ضمیمه (که ذاتاً باید
پیام جدا باشن) به‌صورت پیام‌های اضافه ارسال میشن.
"""
from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton

from database.engine import get_session
from database.crud import get_content_children, get_content_node
from keyboards.menus import BTN

router = Router(name="student_content_browse")


def content_view_keyboard(children, parent_of_current: int, is_root: bool) -> InlineKeyboardMarkup:
    rows = []
    for child in children:
        rows.append([InlineKeyboardButton(text=f"📂 {child.title}", callback_data=f"content:view:enter:{child.id}")])
    if not is_root:
        rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"content:view:enter:{parent_of_current}")])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


async def _view_body_and_kb(current_node_id: int):
    async with get_session() as session:
        if current_node_id == 0:
            children = await get_content_children(session, None)
            title_text = "📚 محتوای آموزشی"
            parent_of_current = 0
            text_content = None
            files = []
        else:
            node = await get_content_node(session, current_node_id)
            if not node:
                children = await get_content_children(session, None)
                title_text = "📚 محتوای آموزشی"
                current_node_id = 0
                parent_of_current = 0
                text_content = None
                files = []
            else:
                children = await get_content_children(session, node.id)
                title_text = f"📂 {node.title}"
                parent_of_current = node.parent_id or 0
                text_content = node.text_content
                files = list(node.files)

    if not children and not text_content and not files:
        body = f"{title_text}\n\nهنوز محتوایی برای این بخش ثبت نشده."
    else:
        body = title_text
        if text_content:
            body += f"\n\n{text_content}"

    kb = content_view_keyboard(children, parent_of_current, is_root=(current_node_id == 0))
    return current_node_id, body, kb, files


async def _send_files(target, files) -> None:
    for f in files:
        try:
            if f.file_type == "document":
                await target.answer_document(f.file_id, caption=f.caption)
            elif f.file_type == "photo":
                await target.answer_photo(f.file_id, caption=f.caption)
            elif f.file_type == "video":
                await target.answer_video(f.file_id, caption=f.caption)
            elif f.file_type == "audio":
                await target.answer_audio(f.file_id, caption=f.caption)
            elif f.file_type == "voice":
                await target.answer_voice(f.file_id, caption=f.caption)
        except Exception:
            pass


@router.message(F.text == BTN.STUDENT_CONTENT)
async def open_content(message: Message) -> None:
    _, body, kb, files = await _view_body_and_kb(0)
    await message.answer(body, reply_markup=kb)
    await _send_files(message, files)


@router.callback_query(F.data.startswith("content:view:enter:"))
async def cb_view_enter(callback: CallbackQuery) -> None:
    node_id = int(callback.data.split(":")[-1])
    _, body, kb, files = await _view_body_and_kb(node_id)

    try:
        await callback.bot.edit_message_text(
            chat_id=callback.message.chat.id,
            message_id=callback.message.message_id,
            text=body,
            reply_markup=kb,
        )
    except Exception:
        pass

    await callback.answer()
    await _send_files(callback.message, files)
