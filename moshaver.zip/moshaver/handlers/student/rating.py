"""
نظرسنجی هفتگی: هر جمعه ساعت ۱۲ برای هر دانش‌آموزِ دارای مشاور، توی پیویش
یک درخواست امتیازدهی ۱ تا ۱۰ + نظر متنی فرستاده میشه (توسط scheduler.py آغاز میشه).
نتیجه به کانال نظرات مشاوره ارسال میشه.
"""
import logging

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext

from config import config
from database.engine import get_session
from database.crud import get_rating_by_id, set_rating_score, set_rating_comment, get_advisor_display_name
from handlers.states import WeeklyRatingStates

router = Router(name="weekly_rating")
logger = logging.getLogger(__name__)


@router.callback_query(F.data.startswith("rating:score:"))
async def cb_rating_score(callback: CallbackQuery, state: FSMContext) -> None:
    _, _, rating_id_str, score_str = callback.data.split(":")
    rating_id = int(rating_id_str)
    score = int(score_str)

    async with get_session() as session:
        rating = await get_rating_by_id(session, rating_id)
        if not rating:
            await callback.answer("خطا: این نظرسنجی پیدا نشد.", show_alert=True)
            return

        if rating.student.user.telegram_id != callback.from_user.id:
            await callback.answer("این نظرسنجی برای شما نیست.", show_alert=True)
            return

        if rating.score is not None:
            await callback.answer("شما قبلاً به این نظرسنجی امتیاز داده‌اید.", show_alert=True)
            return

        await set_rating_score(session, rating, score)
        await session.commit()

    await state.update_data(rating_id=rating_id)
    await state.set_state(WeeklyRatingStates.waiting_for_comment)

    await callback.message.edit_text(f"امتیاز شما: {score} از ۱۰ ✅")
    await callback.message.answer(
        "حالا لطفاً نظرتون رو درباره‌ی مشاورتون به‌صورت متن بنویسید:"
    )
    await callback.answer()


@router.message(WeeklyRatingStates.waiting_for_comment, F.chat.type == "private")
async def on_rating_comment(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً نظرتون رو به‌صورت متن ارسال کنید.")
        return

    data = await state.get_data()
    rating_id = data.get("rating_id")
    await state.clear()

    async with get_session() as session:
        rating = await get_rating_by_id(session, rating_id)
        if not rating:
            await message.answer("خطا: این نظرسنجی پیدا نشد.")
            return

        await set_rating_comment(session, rating, message.text.strip())
        await session.commit()

        student_name = rating.student.full_name or rating.student.user.username or "-"
        advisor_name = get_advisor_display_name(rating.student.advisor)
        group_title = rating.student.group.title if rating.student.group else "-"
        score = rating.score
        comment = rating.comment

    await message.answer("✅ نظر شما با موفقیت ثبت شد. ممنون از همکاریتون 🙏")

    if config.RATING_CHANNEL_ID:
        try:
            await message.bot.send_message(
                chat_id=config.RATING_CHANNEL_ID,
                text=(
                    f"⭐️ نظرسنجی هفتگی جدید\n\n"
                    f"دانش‌آموز: {student_name}\n"
                    f"مشاور: {advisor_name}\n"
                    f"گروه: {group_title}\n"
                    f"امتیاز: {score} از ۱۰\n"
                    f"نظر: {comment}"
                ),
            )
        except Exception as e:
            logger.error(f"خطا در ارسال نتیجه نظرسنجی به کانال: {e}")
