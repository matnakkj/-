"""
آمار و گزارش‌گیری پنل مدیر:
    - وضعیت درصدی ارسال گزارش‌کار «امروز» (بازه‌ی گزارش‌کاری، نه نیمه‌شب)
    - آمار کامل امتیازهای هر مشاور (میانگین + تفکیک دانش‌آموزها)
    - خروجی اکسل ۳۰ روز گذشته
"""
import logging
import os
import tempfile
from datetime import datetime

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, FSInputFile

from database.engine import get_session
from database.crud import (
    get_user_by_telegram_id,
    get_today_report_stats,
    get_all_advisors_rating_summary,
    get_monthly_report_export_data,
    get_rating_response_rate,
    reset_all_ratings,
    get_call_stats_last_30_days,
)
from keyboards.menus import BTN
from utils.excel_report import build_monthly_report_excel

router = Router(name="admin_stats")
logger = logging.getLogger(__name__)


def stats_inline_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📊 وضعیت گزارش‌کار امروز", callback_data="stats:today")],
        [InlineKeyboardButton(text="⭐ آمار امتیازها", callback_data="stats:ratings")],
        [InlineKeyboardButton(text="📞 آمار تماس‌ها (۳۰ روز)", callback_data="stats:calls")],
        [InlineKeyboardButton(text="📥 خروجی اکسل ۳۰ روز گذشته", callback_data="stats:excel")],
    ])


@router.message(F.text == BTN.ADMIN_STATS)
async def open_stats_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return

    await message.answer("کدوم آمار رو می‌خوای ببینی؟", reply_markup=stats_inline_menu())


@router.callback_query(F.data == "stats:today")
async def cb_stats_today(callback: CallbackQuery) -> None:
    async with get_session() as session:
        reported, total = await get_today_report_stats(session)

    if total == 0:
        text = "هنوز هیچ گروه فعالی (تنظیمات کامل‌شده) وجود ندارد."
    else:
        percentage = round(reported / total * 100, 1)
        text = (
            f"📊 وضعیت گزارش‌کار امروز (بازه‌ی گزارش‌کاری از ساعت ۱۴:۰۰):\n\n"
            f"{reported} از {total} گروه فعال گزارش داده‌اند.\n"
            f"درصد ارسال: {percentage}%"
        )

    await callback.message.answer(text)
    await callback.answer()


@router.callback_query(F.data == "stats:ratings")
async def cb_stats_ratings(callback: CallbackQuery) -> None:
    async with get_session() as session:
        summary = await get_all_advisors_rating_summary(session)
        responded, total = await get_rating_response_rate(session)

    if not summary:
        await callback.message.answer("هنوز هیچ مشاوری ثبت نشده است.")
        await callback.answer()
        return

    response_rate = round(responded / total * 100, 1) if total else 0
    lines = [
        "⭐ آمار امتیازهای مشاوران:\n",
        f"📨 نرخ پاسخ‌دهی کلی به نظرسنجی‌ها: {responded} از {total} ({response_rate}%)",
        "(کسانی که نظر نداده‌اند در میانگین‌گیری حساب نمی‌شوند)\n",
    ]
    for item in summary:
        avg_text = f"{item['average']} از ۱۰" if item["average"] is not None else "بدون امتیاز"
        lines.append(f"👤 {item['advisor_name']} — {avg_text}")

    await callback.message.answer("\n".join(lines), reply_markup=rating_reset_menu_keyboard())
    await callback.answer()


def rating_reset_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🗑 ریست کامل امتیازها", callback_data="ratings:reset:ask")],
    ])


@router.callback_query(F.data == "stats:calls")
async def cb_stats_calls(callback: CallbackQuery) -> None:
    async with get_session() as session:
        summary = await get_call_stats_last_30_days(session)

    if not summary:
        await callback.message.answer("هنوز هیچ مشاوری ثبت نشده است.")
        await callback.answer()
        return

    lines = ["📞 آمار تماس‌ها (۳۰ روز گذشته):\n"]
    for item in summary:
        lines.append(f"👤 {item['advisor_name']}")
        if item["students"]:
            for name, count in item["students"]:
                lines.append(f"    • {name}: {count} تماس")
        else:
            lines.append("    (بدون دانش‌آموز)")
        lines.append("")

    await callback.message.answer("\n".join(lines))
    await callback.answer()


@router.callback_query(F.data == "stats:excel")
async def cb_stats_excel(callback: CallbackQuery) -> None:
    await callback.answer("⏳ در حال ساخت فایل اکسل...")

    async with get_session() as session:
        days, data = await get_monthly_report_export_data(session, days_count=30)

    if not data:
        await callback.message.answer("هنوز هیچ مشاور/دانش‌آموزی برای گزارش‌گیری وجود ندارد.")
        return

    filename = f"gozaresh_30rooz_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    output_path = os.path.join(tempfile.gettempdir(), filename)

    try:
        build_monthly_report_excel(days, data, output_path)
        await callback.message.answer_document(
            FSInputFile(output_path, filename=filename),
            caption="📥 خروجی اکسل ۳۰ روز گذشته",
        )
    except Exception as e:
        logger.error(f"خطا در ساخت/ارسال فایل اکسل: {e}")
        await callback.message.answer("خطا در ساخت فایل اکسل.")
    finally:
        if os.path.exists(output_path):
            os.remove(output_path)


# --------------------------- ریست کامل امتیازها (با دو مرحله تأیید) ---------------------------
@router.callback_query(F.data == "ratings:reset:ask")
async def cb_ratings_reset_ask(callback: CallbackQuery) -> None:
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⚠️ آره، ادامه بده", callback_data="ratings:reset:confirm1"),
            InlineKeyboardButton(text="❌ نه، بی‌خیال", callback_data="ratings:reset:cancel"),
        ]
    ])
    await callback.message.answer(
        "⚠️ مطمئنی می‌خوای همه‌ی امتیازهای ثبت‌شده (همه‌ی مشاوران و دانش‌آموزها) رو کامل پاک کنی؟\n"
        "این کار غیرقابل بازگشته.",
        reply_markup=kb,
    )
    await callback.answer()


@router.callback_query(F.data == "ratings:reset:confirm1")
async def cb_ratings_reset_confirm1(callback: CallbackQuery) -> None:
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ بله، کاملاً مطمئنم، ریست کن", callback_data="ratings:reset:confirm2"),
            InlineKeyboardButton(text="❌ لغو", callback_data="ratings:reset:cancel"),
        ]
    ])
    await callback.message.answer(
        "❗️ این آخرین تأییده. با زدن دکمه‌ی پایین همه‌ی امتیازها برای همیشه پاک می‌شن.",
        reply_markup=kb,
    )
    await callback.answer()


@router.callback_query(F.data == "ratings:reset:confirm2")
async def cb_ratings_reset_confirm2(callback: CallbackQuery) -> None:
    async with get_session() as session:
        count = await reset_all_ratings(session)
        await session.commit()

    await callback.message.answer(f"✅ {count} نظرسنجی پاک شد. امتیازها از صفر شروع می‌شوند.")
    await callback.answer()


@router.callback_query(F.data == "ratings:reset:cancel")
async def cb_ratings_reset_cancel(callback: CallbackQuery) -> None:
    await callback.message.answer("لغو شد. هیچ امتیازی پاک نشد.")
    await callback.answer()
