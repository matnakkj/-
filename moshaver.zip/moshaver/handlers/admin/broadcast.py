"""
پیام همگانی مدیر:
    - به همه‌ی گروه‌های مشاوره
    - به پیوی همه‌ی کسانی که ربات را استارت زده‌اند (فارغ از نقش)
یک مرحله‌ی پیش‌نمایش + تأیید قبل از ارسال واقعی وجود دارد چون این کار
غیرقابل بازگشت است.
"""
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import get_user_by_telegram_id, get_all_group_chat_ids, get_all_user_telegram_ids
from handlers.states import BroadcastStates
from keyboards.menus import BTN, cancel_menu, admin_main_menu
from utils.broadcast import broadcast_copy_message

router = Router(name="admin_broadcast")


def target_choice_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📨 به همه‌ی گروه‌ها", callback_data="broadcast:target:groups")],
        [InlineKeyboardButton(text="👤 به پیوی همه‌ی کاربران", callback_data="broadcast:target:users")],
    ])


def confirm_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ تأیید و ارسال", callback_data="broadcast:confirm"),
            InlineKeyboardButton(text="❌ لغو", callback_data="broadcast:cancel"),
        ]
    ])


@router.message(F.text == BTN.ADMIN_BROADCAST)
async def open_broadcast_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return

    await message.answer("پیام همگانی برای کدوم مقصد ارسال شود؟", reply_markup=target_choice_keyboard())


@router.callback_query(F.data.startswith("broadcast:target:"))
async def cb_broadcast_target(callback: CallbackQuery, state: FSMContext) -> None:
    target = callback.data.split(":")[-1]  # "groups" یا "users"
    await state.update_data(target=target)
    await state.set_state(BroadcastStates.waiting_for_content)

    target_fa = "همه‌ی گروه‌ها" if target == "groups" else "پیوی همه‌ی کاربران"
    await callback.message.answer(
        f"محتوای پیام (متن، عکس، فایل یا هرچیزی) رو برای ارسال به «{target_fa}» بفرست:",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(BroadcastStates.waiting_for_content, F.text == BTN.BACK)
async def cancel_broadcast_content(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(BroadcastStates.waiting_for_content)
async def on_broadcast_content(message: Message, state: FSMContext) -> None:
    await state.update_data(source_chat_id=message.chat.id, source_message_id=message.message_id)
    await state.set_state(BroadcastStates.waiting_for_confirmation)

    await message.answer("پیش‌نمایش پیامی که ارسال میشه:")
    await message.copy_to(chat_id=message.chat.id)
    await message.answer(
        "⚠️ این پیام برای همه‌ی مقصدها ارسال میشه و غیرقابل بازگشته. مطمئنی؟",
        reply_markup=confirm_keyboard(),
    )


@router.callback_query(BroadcastStates.waiting_for_confirmation, F.data == "broadcast:cancel")
async def cb_broadcast_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    await state.clear()
    await callback.message.answer("لغو شد.", reply_markup=admin_main_menu())
    await callback.answer()


@router.callback_query(BroadcastStates.waiting_for_confirmation, F.data == "broadcast:confirm")
async def cb_broadcast_confirm(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    await state.clear()

    target = data.get("target")
    source_chat_id = data.get("source_chat_id")
    source_message_id = data.get("source_message_id")

    async with get_session() as session:
        if target == "groups":
            chat_ids = await get_all_group_chat_ids(session)
        else:
            chat_ids = await get_all_user_telegram_ids(session)

    await callback.message.edit_text(f"⏳ در حال ارسال به {len(chat_ids)} مقصد...")
    await callback.answer()

    result = await broadcast_copy_message(
        callback.bot, chat_ids, from_chat_id=source_chat_id, message_id=source_message_id
    )

    await callback.message.answer(
        f"✅ پیام همگانی تمام شد.\n\n"
        f"موفق: {result.success}\n"
        f"ناموفق: {result.failed} (احتمالاً ربات را بلاک کرده‌اند یا از گروه حذف شده)",
        reply_markup=admin_main_menu(),
    )
