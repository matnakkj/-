"""
پشتیبان‌گیری/بازگردانی کامل دیتابیس - فقط مدیر اصلی (Super Admin) حق دسترسی دارد.
دقیقاً مثل «سیو کردن بازی»: یه فایل می‌گیری، هر وقت خواستی همون فایل رو
برمی‌گردونی و همه‌چیز به همون حالت قبل برمی‌گرده.
"""
import logging
import os
import tempfile
from datetime import datetime

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery, FSInputFile
from aiogram.fsm.context import FSMContext

from database.engine import get_session, engine
from database.crud import get_user_by_telegram_id
from handlers.states import BackupRestoreStates
from keyboards.menus import BTN, admin_main_menu, cancel_menu
from utils.db_backup import create_backup, restore_backup

router = Router(name="admin_backup")
logger = logging.getLogger(__name__)


def backup_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📤 گرفتن پشتیبان (دانلود)", callback_data="backup:create")],
        [InlineKeyboardButton(text="📥 بازگردانی از فایل پشتیبان", callback_data="backup:restore:start")],
    ])


@router.message(F.text == BTN.ADMIN_BACKUP)
async def open_backup_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_super_admin:
            return  # فقط مدیر اصلی

    await message.answer(
        "💾 پشتیبان‌گیری و بازگردانی دیتابیس:\n\n"
        "⚠️ بازگردانی، همه‌ی اطلاعات فعلی رو با فایل پشتیبان جایگزین می‌کنه (غیرقابل بازگشت).",
        reply_markup=backup_menu_keyboard(),
    )


# --------------------------- گرفتن پشتیبان ---------------------------
@router.callback_query(F.data == "backup:create")
async def cb_backup_create(callback: CallbackQuery) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if not user or not user.is_super_admin:
            await callback.answer("فقط مدیر اصلی به این بخش دسترسی دارد.", show_alert=True)
            return

    await callback.answer("⏳ در حال گرفتن پشتیبان...")
    filename = f"moshaver_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.sql"
    output_path = os.path.join(tempfile.gettempdir(), filename)

    try:
        await create_backup(output_path)
        await callback.message.answer_document(
            FSInputFile(output_path, filename=filename),
            caption="📤 فایل پشتیبان دیتابیس. این فایل رو یه‌جای امن نگه دار.",
        )
    except Exception as e:
        logger.error(f"خطا در گرفتن پشتیبان: {e}")
        await callback.message.answer(f"خطا در گرفتن پشتیبان:\n{e}")
    finally:
        if os.path.exists(output_path):
            os.remove(output_path)


# --------------------------- بازگردانی پشتیبان ---------------------------
@router.callback_query(F.data == "backup:restore:start")
async def cb_backup_restore_start(callback: CallbackQuery, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if not user or not user.is_super_admin:
            await callback.answer("فقط مدیر اصلی به این بخش دسترسی دارد.", show_alert=True)
            return

    await state.set_state(BackupRestoreStates.waiting_for_file)
    await callback.message.answer(
        "فایل پشتیبان (.sql) رو ارسال کن:",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(BackupRestoreStates.waiting_for_file, F.text == BTN.BACK)
async def cancel_restore(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu(is_super_admin=True))


@router.message(BackupRestoreStates.waiting_for_file, F.document)
async def on_restore_file_received(message: Message, state: FSMContext) -> None:
    file_path = os.path.join(tempfile.gettempdir(), f"restore_{message.from_user.id}.sql")
    file_info = await message.bot.get_file(message.document.file_id)
    await message.bot.download_file(file_info.file_path, destination=file_path)

    await state.update_data(file_path=file_path)

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⚠️ آره، ادامه بده", callback_data="backup:restore:confirm1"),
            InlineKeyboardButton(text="❌ لغو", callback_data="backup:restore:cancel"),
        ]
    ])
    await message.answer(
        "⚠️ مطمئنی می‌خوای دیتابیس فعلی رو کامل با این فایل جایگزین کنی؟\n"
        "همه‌ی اطلاعات فعلی (مدیران، مشاوران، دانش‌آموزان، گزارش‌ها و...) پاک و با محتوای این فایل عوض می‌شه.",
        reply_markup=kb,
    )


@router.message(BackupRestoreStates.waiting_for_file)
async def on_restore_wrong_content(message: Message) -> None:
    await message.answer("لطفاً فایل پشتیبان (.sql) رو به‌صورت Document ارسال کن.")


@router.callback_query(F.data == "backup:restore:confirm1")
async def cb_restore_confirm1(callback: CallbackQuery) -> None:
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ بله، کاملاً مطمئنم، بازگردان", callback_data="backup:restore:confirm2"),
            InlineKeyboardButton(text="❌ لغو", callback_data="backup:restore:cancel"),
        ]
    ])
    await callback.message.answer(
        "❗️ این آخرین تأییده. با زدن دکمه‌ی پایین، بازگردانی شروع میشه و برگشت‌ناپذیره.",
        reply_markup=kb,
    )
    await callback.answer()


@router.callback_query(F.data == "backup:restore:confirm2")
async def cb_restore_confirm2(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    file_path = data.get("file_path")
    await state.clear()

    if not file_path or not os.path.exists(file_path):
        await callback.message.answer("خطا: فایل پیدا نشد. دوباره تلاش کن.")
        await callback.answer()
        return

    await callback.answer("⏳ در حال بازگردانی...")
    try:
        await restore_backup(file_path)
        await engine.dispose()  # کانکشن‌های قدیمی رو می‌بندیم تا با ساختار جدید هماهنگ باشن
        await callback.message.answer(
            "✅ بازگردانی با موفقیت انجام شد.\n"
            "پیشنهاد می‌کنم ربات رو یک‌بار ری‌استارت کنی تا کاملاً مطمئن شی:\n"
            "systemctl restart moshaver-bot"
        )
    except Exception as e:
        logger.error(f"خطا در بازگردانی: {e}")
        await callback.message.answer(f"خطا در بازگردانی:\n{e}")
    finally:
        if os.path.exists(file_path):
            os.remove(file_path)


@router.callback_query(F.data == "backup:restore:cancel")
async def cb_restore_cancel(callback: CallbackQuery, state: FSMContext) -> None:
    data = await state.get_data()
    file_path = data.get("file_path")
    if file_path and os.path.exists(file_path):
        os.remove(file_path)
    await state.clear()
    await callback.message.answer("لغو شد. هیچ تغییری اعمال نشد.")
    await callback.answer()
