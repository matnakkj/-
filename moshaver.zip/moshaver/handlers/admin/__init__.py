from aiogram import Router

from handlers.admin import admins, advisors, broadcast, stats, rating_schedule, backup, content

router = Router(name="admin")
router.include_router(admins.router)
router.include_router(advisors.router)
router.include_router(broadcast.router)
router.include_router(stats.router)
router.include_router(rating_schedule.router)
router.include_router(backup.router)
router.include_router(content.router)
