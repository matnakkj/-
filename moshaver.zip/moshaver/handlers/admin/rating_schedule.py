"""
تنظیم زمان‌بندی نظرسنجی هفتگی توسط مدیر (روز هفته + ساعت، کاملاً قابل تغییر)
+ دکمه‌ی ارسال آزمایشی فوری برای تست راحت‌تر، بدون نیاز به صبر کردن تا زمان واقعی.
"""
import logging
import re

from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.context import FSMContext
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger

from database.engine import get_session
from database.crud import get_user_by_telegram_id, get_or_create_rating_schedule, set_rating_schedule
from handlers.states import RatingScheduleStates
from keyboards.menus import BTN, cancel_menu, admin_main_menu
from utils.jalali import WEEKDAY_NAMES_FA
from utils.timeutils import LOCAL_TZ

router = Router(name="admin_rating_schedule")
logger = logging.getLogger(__name__)

TIME_PATTERN = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


def weekday_choice_keyboard() -> InlineKeyboardMarkup:
    rows = []
    for idx, name in enumerate(WEEKDAY_NAMES_FA):
        rows.append([InlineKeyboardButton(text=name, callback_data=f"ratingsched:day:{idx}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def schedule_menu_keyboard() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ تغییر روز و ساعت", callback_data="ratingsched:change")],
    ])


@router.message(F.text == BTN.ADMIN_RATING_SCHEDULE)
async def open_rating_schedule_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return
        schedule = await get_or_create_rating_schedule(session)
        await session.commit()

    day_name = WEEKDAY_NAMES_FA[schedule.weekday]
    await message.answer(
        f"🗳 زمان فعلی نظرسنجی هفتگی: {day_name} ساعت {schedule.hour:02d}:{schedule.minute:02d}\n\n"
        f"هر هفته دقیقاً همین موقع، برای همه‌ی دانش‌آموزهای دارای مشاور نظرسنجی ارسال می‌شود.",
        reply_markup=schedule_menu_keyboard(),
    )


@router.callback_query(F.data == "ratingsched:change")
async def cb_change_start(callback: CallbackQuery) -> None:
    await callback.message.answer("روز هفته رو انتخاب کن:", reply_markup=weekday_choice_keyboard())
    await callback.answer()


@router.callback_query(F.data.startswith("ratingsched:day:"))
async def cb_change_weekday(callback: CallbackQuery, state: FSMContext) -> None:
    weekday = int(callback.data.split(":")[-1])
    await state.update_data(weekday=weekday)
    await state.set_state(RatingScheduleStates.waiting_for_time)
    await callback.message.answer(
        f"روز «{WEEKDAY_NAMES_FA[weekday]}» انتخاب شد.\nحالا ساعت رو به فرمت HH:MM بفرست (مثلاً 12:00):",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(RatingScheduleStates.waiting_for_time, F.text == BTN.BACK)
async def cancel_change_time(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(RatingScheduleStates.waiting_for_time)
async def on_change_time(message: Message, state: FSMContext, scheduler: AsyncIOScheduler) -> None:
    if not message.text or not TIME_PATTERN.match(message.text.strip()):
        await message.answer("فرمت نامعتبر است. مثال درست: 12:00")
        return

    data = await state.get_data()
    weekday = data["weekday"]
    hour, minute = map(int, message.text.strip().split(":"))
    await state.clear()

    async with get_session() as session:
        await set_rating_schedule(session, weekday, hour, minute)
        await session.commit()

    scheduler.reschedule_job(
        "send_weekly_ratings",
        trigger=CronTrigger(day_of_week=weekday, hour=hour, minute=minute, timezone=LOCAL_TZ),
    )

    await message.answer(
        f"✅ زمان نظرسنجی هفتگی به «{WEEKDAY_NAMES_FA[weekday]} ساعت {hour:02d}:{minute:02d}» تغییر کرد.",
        reply_markup=admin_main_menu(),
    )
