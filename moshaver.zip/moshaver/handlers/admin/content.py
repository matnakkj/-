"""
مدیریت منوی محتوای تودرتو توسط مدیر.

طراحی UI: به‌جای اینکه هر کلیک یه پیام جدید بفرسته (که باعث میشه دکمه‌ها
پشت‌سرهم توی چت تلنبار بشن)، همیشه فقط یک پیام (پیام «مرورگر») وجود داره
که با هر عمل ادیت میشه. آیدی همین پیام توی FSM state نگه داشته میشه.
پیام‌های متنی که خودِ مدیر برای وارد کردن اسم/متن می‌فرسته هم بعد از
پردازش پاک میشن که چت تمیز بمونه.

قرارداد: parent_id=0 یعنی «ریشه» (چون خودِ None توی callback_data قابل
نمایش نیست، همه‌جا به‌جای None از عدد 0 استفاده می‌کنیم).
"""
import logging

from aiogram import Router, F, Bot
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import (
    get_user_by_telegram_id,
    get_content_children,
    get_content_node,
    create_content_node,
    set_content_node_text,
    add_content_file,
    delete_content_node_recursive,
    rename_content_node,
)
from handlers.states import ContentManageStates
from keyboards.menus import BTN

router = Router(name="admin_content")
logger = logging.getLogger(__name__)


def content_admin_keyboard(children, current_node_id: int, parent_of_current: int) -> InlineKeyboardMarkup:
    rows = []
    for child in children:
        rows.append([InlineKeyboardButton(text=f"📂 {child.title}", callback_data=f"content:admin:enter:{child.id}")])

    rows.append([InlineKeyboardButton(text="➕ افزودن دکمه جدید اینجا", callback_data=f"content:admin:addnode:{current_node_id}")])

    if current_node_id != 0:
        rows.append([
            InlineKeyboardButton(text="📝 متن این بخش", callback_data=f"content:admin:settext:{current_node_id}"),
            InlineKeyboardButton(text="📎 افزودن فایل", callback_data=f"content:admin:addfile:{current_node_id}"),
        ])
        rows.append([
            InlineKeyboardButton(text="✏️ تغییر نام", callback_data=f"content:admin:rename:{current_node_id}"),
            InlineKeyboardButton(text="🗑 حذف این بخش", callback_data=f"content:admin:delete:{current_node_id}"),
        ])
        rows.append([InlineKeyboardButton(text="🔙 بازگشت", callback_data=f"content:admin:enter:{parent_of_current}")])

    return InlineKeyboardMarkup(inline_keyboard=rows)


def cancel_inline_keyboard(back_to_node_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="❌ لغو", callback_data=f"content:admin:enter:{back_to_node_id}")]
    ])


async def _browser_body_and_kb(current_node_id: int):
    async with get_session() as session:
        if current_node_id == 0:
            children = await get_content_children(session, None)
            title_text = "📂 ریشه‌ی منوی محتوا"
            parent_of_current = 0
            text_content = None
            files_count = 0
        else:
            node = await get_content_node(session, current_node_id)
            if not node:
                current_node_id = 0
                children = await get_content_children(session, None)
                title_text = "📂 ریشه‌ی منوی محتوا (بخش قبلی دیگه وجود نداره)"
                parent_of_current = 0
                text_content = None
                files_count = 0
            else:
                children = await get_content_children(session, node.id)
                title_text = f"📂 {node.title}"
                parent_of_current = node.parent_id or 0
                text_content = node.text_content
                files_count = len(node.files)

    body = title_text
    if text_content:
        body += f"\n\n📝 متن فعلی:\n{text_content}"
    if files_count:
        body += f"\n\n📎 {files_count} فایل ضمیمه شده"

    kb = content_admin_keyboard(children, current_node_id, parent_of_current)
    return current_node_id, body, kb


async def render_browser_new(message: Message, current_node_id: int, state: FSMContext) -> None:
    """اولین بار که مدیر وارد بخش محتوا میشه - یک پیام تازه می‌فرستیم و آیدیش رو نگه می‌داریم."""
    _, body, kb = await _browser_body_and_kb(current_node_id)
    sent = await message.answer(body, reply_markup=kb)
    await state.update_data(content_chat_id=sent.chat.id, content_message_id=sent.message_id)


async def render_browser_edit(bot: Bot, chat_id: int, message_id: int, current_node_id: int) -> None:
    """پیام موجود رو با محتوای جدید ادیت می‌کنیم - هیچ پیام جدیدی ساخته نمیشه."""
    _, body, kb = await _browser_body_and_kb(current_node_id)
    try:
        await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=body, reply_markup=kb)
    except Exception as e:
        logger.debug(f"ادیت پیام منوی محتوا ممکن نشد (احتمالاً تغییری نداشت): {e}")


async def _get_browser_location(state: FSMContext) -> tuple[int | None, int | None]:
    data = await state.get_data()
    return data.get("content_chat_id"), data.get("content_message_id")


@router.message(F.text == BTN.ADMIN_CONTENT)
async def open_content_menu(message: Message, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return

    await state.clear()
    await render_browser_new(message, current_node_id=0, state=state)


@router.callback_query(F.data.startswith("content:admin:enter:"))
async def cb_enter(callback: CallbackQuery, state: FSMContext) -> None:
    node_id = int(callback.data.split(":")[-1])
    await state.set_state(None)  # هر state باز مونده (مثلاً وسط تایپ) رو لغو می‌کنیم
    await state.update_data(content_chat_id=callback.message.chat.id, content_message_id=callback.message.message_id)
    await render_browser_edit(callback.bot, callback.message.chat.id, callback.message.message_id, node_id)
    await callback.answer()


# --------------------------- افزودن دکمه جدید ---------------------------
@router.callback_query(F.data.startswith("content:admin:addnode:"))
async def cb_addnode_start(callback: CallbackQuery, state: FSMContext) -> None:
    parent_id = int(callback.data.split(":")[-1])
    await state.update_data(
        parent_id=parent_id,
        content_chat_id=callback.message.chat.id,
        content_message_id=callback.message.message_id,
    )
    await state.set_state(ContentManageStates.waiting_for_new_title)
    await callback.bot.edit_message_text(
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        text="✏️ اسم دکمه‌ی جدید رو تایپ و ارسال کن:",
        reply_markup=cancel_inline_keyboard(parent_id),
    )
    await callback.answer()


@router.message(ContentManageStates.waiting_for_new_title)
async def cb_addnode_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        await message.answer("لطفاً یک اسم معتبر وارد کن.")
        return

    data = await state.get_data()
    parent_id = data.get("parent_id", 0)
    chat_id, message_id = data.get("content_chat_id"), data.get("content_message_id")
    await state.clear()

    async with get_session() as session:
        await create_content_node(session, parent_id if parent_id != 0 else None, message.text.strip())
        await session.commit()

    try:
        await message.delete()
    except Exception:
        pass

    if chat_id and message_id:
        await render_browser_edit(message.bot, chat_id, message_id, parent_id)


# --------------------------- متن بخش ---------------------------
@router.callback_query(F.data.startswith("content:admin:settext:"))
async def cb_settext_start(callback: CallbackQuery, state: FSMContext) -> None:
    node_id = int(callback.data.split(":")[-1])
    await state.update_data(
        node_id=node_id,
        content_chat_id=callback.message.chat.id,
        content_message_id=callback.message.message_id,
    )
    await state.set_state(ContentManageStates.waiting_for_text)
    await callback.bot.edit_message_text(
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        text="📝 متنی که می‌خوای برای این بخش نمایش داده بشه رو بفرست:",
        reply_markup=cancel_inline_keyboard(node_id),
    )
    await callback.answer()


@router.message(ContentManageStates.waiting_for_text)
async def cb_settext_finish(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً متن رو به‌صورت پیام متنی ارسال کن.")
        return

    data = await state.get_data()
    node_id = data["node_id"]
    chat_id, message_id = data.get("content_chat_id"), data.get("content_message_id")
    await state.clear()

    async with get_session() as session:
        await set_content_node_text(session, node_id, message.text)
        await session.commit()

    try:
        await message.delete()
    except Exception:
        pass

    if chat_id and message_id:
        await render_browser_edit(message.bot, chat_id, message_id, node_id)


# --------------------------- افزودن فایل ---------------------------
@router.callback_query(F.data.startswith("content:admin:addfile:"))
async def cb_addfile_start(callback: CallbackQuery, state: FSMContext) -> None:
    node_id = int(callback.data.split(":")[-1])
    await state.update_data(
        node_id=node_id,
        content_chat_id=callback.message.chat.id,
        content_message_id=callback.message.message_id,
    )
    await state.set_state(ContentManageStates.waiting_for_file)
    await callback.bot.edit_message_text(
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        text=(
            "📎 فایل (سند، عکس، ویدیو یا صدا) رو بفرست. می‌تونی چندتا "
            "پشت‌سرهم بفرستی؛ وقتی تموم شد دکمه‌ی پایین رو بزن."
        ),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="✅ تموم شد", callback_data=f"content:admin:enter:{node_id}")]
        ]),
    )
    await callback.answer()


@router.message(ContentManageStates.waiting_for_file)
async def cb_addfile_receive(message: Message, state: FSMContext) -> None:
    data = await state.get_data()
    node_id = data["node_id"]

    file_id = None
    file_type = None
    if message.document:
        file_id, file_type = message.document.file_id, "document"
    elif message.photo:
        file_id, file_type = message.photo[-1].file_id, "photo"
    elif message.video:
        file_id, file_type = message.video.file_id, "video"
    elif message.audio:
        file_id, file_type = message.audio.file_id, "audio"
    elif message.voice:
        file_id, file_type = message.voice.file_id, "voice"

    if not file_id:
        await message.answer("این نوع پیام قابل ذخیره نیست. یه فایل/عکس/ویدیو/صدا بفرست.")
        return

    async with get_session() as session:
        await add_content_file(session, node_id, file_id, file_type, caption=message.caption)
        await session.commit()

    try:
        await message.delete()
    except Exception:
        pass  # اگه پاک کردن فایل ممکن نبود، اشکالی نداره


# --------------------------- تغییر نام ---------------------------
@router.callback_query(F.data.startswith("content:admin:rename:"))
async def cb_rename_start(callback: CallbackQuery, state: FSMContext) -> None:
    node_id = int(callback.data.split(":")[-1])
    await state.update_data(
        node_id=node_id,
        content_chat_id=callback.message.chat.id,
        content_message_id=callback.message.message_id,
    )
    await state.set_state(ContentManageStates.waiting_for_rename)
    await callback.bot.edit_message_text(
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        text="✏️ اسم جدید این بخش رو وارد کن:",
        reply_markup=cancel_inline_keyboard(node_id),
    )
    await callback.answer()


@router.message(ContentManageStates.waiting_for_rename)
async def cb_rename_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        await message.answer("لطفاً یک اسم معتبر وارد کن.")
        return

    data = await state.get_data()
    node_id = data["node_id"]
    chat_id, message_id = data.get("content_chat_id"), data.get("content_message_id")
    await state.clear()

    async with get_session() as session:
        await rename_content_node(session, node_id, message.text.strip())
        await session.commit()

    try:
        await message.delete()
    except Exception:
        pass

    if chat_id and message_id:
        await render_browser_edit(message.bot, chat_id, message_id, node_id)


# --------------------------- حذف بخش ---------------------------
@router.callback_query(F.data.startswith("content:admin:delete:"))
async def cb_delete_ask(callback: CallbackQuery) -> None:
    node_id = int(callback.data.split(":")[-1])
    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ بله، حذف کن", callback_data=f"content:admin:delconfirm:{node_id}"),
            InlineKeyboardButton(text="❌ لغو", callback_data=f"content:admin:enter:{node_id}"),
        ]
    ])
    await callback.bot.edit_message_text(
        chat_id=callback.message.chat.id,
        message_id=callback.message.message_id,
        text="⚠️ این بخش و همه‌ی زیرشاخه‌ها/فایل‌های داخلش برای همیشه پاک می‌شن. مطمئنی؟",
        reply_markup=kb,
    )
    await callback.answer()


@router.callback_query(F.data.startswith("content:admin:delconfirm:"))
async def cb_delete_confirm(callback: CallbackQuery) -> None:
    node_id = int(callback.data.split(":")[-1])

    async with get_session() as session:
        node = await get_content_node(session, node_id)
        parent_id = (node.parent_id or 0) if node else 0
        await delete_content_node_recursive(session, node_id)
        await session.commit()

    await render_browser_edit(callback.bot, callback.message.chat.id, callback.message.message_id, parent_id)
    await callback.answer("✅ حذف شد.")
