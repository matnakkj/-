"""
مدیریت مشاوران توسط مدیر (هر مدیری، نه فقط مدیر اصلی).
"""
from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import (
    get_user_by_telegram_id,
    add_advisor,
    remove_advisor,
    list_advisors,
    get_advisor_display_name,
)
from handlers.states import AddAdvisorStates, RemoveAdvisorStates
from keyboards.menus import BTN, cancel_menu, admin_main_menu

router = Router(name="admin_advisors")


def advisors_inline_menu() -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="📋 لیست مشاوران", callback_data="advisors:list")],
        [
            InlineKeyboardButton(text="➕ افزودن مشاور", callback_data="advisors:add"),
            InlineKeyboardButton(text="➖ حذف مشاور", callback_data="advisors:remove"),
        ],
    ])


@router.message(F.text == BTN.ADMIN_MANAGE_ADVISORS)
async def open_advisors_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return

    await message.answer("مدیریت مشاوران:", reply_markup=advisors_inline_menu())


@router.callback_query(F.data == "advisors:list")
async def cb_list_advisors(callback: CallbackQuery) -> None:
    async with get_session() as session:
        advisors = await list_advisors(session)

    if not advisors:
        text = "هیچ مشاوری ثبت نشده است."
    else:
        lines = ["📋 لیست مشاوران:\n"]
        for adv in advisors:
            name = get_advisor_display_name(adv)
            student_count = len(adv.students)
            lines.append(f"• {name} — {adv.user.telegram_id} ({student_count} دانش‌آموز)")
        text = "\n".join(lines)

    await callback.message.answer(text)
    await callback.answer()


# --------------------------- افزودن مشاور ---------------------------
@router.callback_query(F.data == "advisors:add")
async def cb_add_advisor_start(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(AddAdvisorStates.waiting_for_id)
    await callback.message.answer(
        "آیدی عددی کاربری که می‌خواهید مشاور شود را ارسال کنید.\n"
        "(کاربر باید قبلاً حداقل یک‌بار ربات را /start زده باشد)",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(AddAdvisorStates.waiting_for_id, F.text == BTN.BACK)
async def cancel_add_advisor(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(AddAdvisorStates.waiting_for_id)
async def cb_add_advisor_get_name(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip().isdigit():
        await message.answer("آیدی نامعتبر است. یک عدد ارسال کنید یا بازگشت را بزنید.")
        return

    telegram_id = int(message.text.strip())
    await state.update_data(telegram_id=telegram_id)
    await state.set_state(AddAdvisorStates.waiting_for_display_name)
    await message.answer(
        "اسمی که می‌خوای برای این مشاور نمایش داده شود را وارد کن.\n"
        "(این اسم از این به بعد در گزارش‌ها، کانال‌ها و همه‌جا به‌جای اسم اکانت تلگرامش نشان داده می‌شود)",
        reply_markup=cancel_menu(),
    )


@router.message(AddAdvisorStates.waiting_for_display_name, F.text == BTN.BACK)
async def cancel_add_advisor_name(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(AddAdvisorStates.waiting_for_display_name)
async def cb_add_advisor_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip():
        await message.answer("لطفاً یک اسم معتبر وارد کنید.")
        return

    data = await state.get_data()
    telegram_id = data["telegram_id"]
    display_name = message.text.strip()

    async with get_session() as session:
        user, msg = await add_advisor(session, telegram_id, display_name=display_name)
        await session.commit()

    await state.clear()
    await message.answer(f"{'✅' if user else '❌'} {msg}", reply_markup=admin_main_menu())


# --------------------------- حذف مشاور ---------------------------
@router.callback_query(F.data == "advisors:remove")
async def cb_remove_advisor_start(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(RemoveAdvisorStates.waiting_for_id)
    await callback.message.answer(
        "آیدی عددی مشاوری که می‌خواهید حذف شود را ارسال کنید:",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(RemoveAdvisorStates.waiting_for_id, F.text == BTN.BACK)
async def cancel_remove_advisor(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(RemoveAdvisorStates.waiting_for_id)
async def cb_remove_advisor_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip().isdigit():
        await message.answer("آیدی نامعتبر است.")
        return

    telegram_id = int(message.text.strip())
    async with get_session() as session:
        msg = await remove_advisor(session, telegram_id)
        await session.commit()

    await state.clear()
    await message.answer(msg, reply_markup=admin_main_menu())
