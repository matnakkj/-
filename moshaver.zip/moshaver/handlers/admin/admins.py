"""
مدیریت مدیران.
فقط مدیر اصلی (Super Admin) حق افزودن/حذف مدیر جدید را دارد.
بقیه‌ی مدیران فقط می‌توانند لیست را ببینند.
"""
from aiogram import Router, F
from aiogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, CallbackQuery
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import get_user_by_telegram_id, add_admin, remove_admin, list_admins
from handlers.states import AddAdminStates, RemoveAdminStates
from keyboards.menus import BTN, cancel_menu, admin_main_menu

router = Router(name="admin_admins")


def admins_inline_menu(is_super_admin: bool) -> InlineKeyboardMarkup:
    rows = [[InlineKeyboardButton(text="📋 لیست مدیران", callback_data="admins:list")]]
    if is_super_admin:
        rows.append([
            InlineKeyboardButton(text="➕ افزودن مدیر", callback_data="admins:add"),
            InlineKeyboardButton(text="➖ حذف مدیر", callback_data="admins:remove"),
        ])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text == BTN.ADMIN_MANAGE_ADMINS)
async def open_admins_menu(message: Message) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, message.from_user.id)
        if not user or not user.is_admin:
            return
        is_super = user.is_super_admin

    await message.answer("مدیریت مدیران:", reply_markup=admins_inline_menu(is_super))


@router.callback_query(F.data == "admins:list")
async def cb_list_admins(callback: CallbackQuery) -> None:
    async with get_session() as session:
        admins = await list_admins(session)

    if not admins:
        text = "هیچ مدیری ثبت نشده است."
    else:
        lines = ["📋 لیست مدیران:\n"]
        for a in admins:
            tag = " (مدیر اصلی)" if a.is_super_admin else ""
            name = a.full_name or a.username or str(a.telegram_id)
            lines.append(f"• {name} — {a.telegram_id}{tag}")
        text = "\n".join(lines)

    await callback.message.answer(text)
    await callback.answer()


# --------------------------- افزودن مدیر ---------------------------
@router.callback_query(F.data == "admins:add")
async def cb_add_admin_start(callback: CallbackQuery, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if not user or not user.is_super_admin:
            await callback.answer("فقط مدیر اصلی می‌تواند این کار را انجام دهد.", show_alert=True)
            return

    await state.set_state(AddAdminStates.waiting_for_id)
    await callback.message.answer(
        "آیدی عددی کاربری که می‌خواهید مدیر شود را ارسال کنید:",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(AddAdminStates.waiting_for_id, F.text == BTN.BACK)
async def cancel_add_admin(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(AddAdminStates.waiting_for_id)
async def cb_add_admin_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip().isdigit():
        await message.answer("آیدی نامعتبر است. یک عدد ارسال کنید یا بازگشت را بزنید.")
        return

    telegram_id = int(message.text.strip())
    async with get_session() as session:
        await add_admin(session, telegram_id)
        await session.commit()

    await state.clear()
    await message.answer(
        f"✅ کاربر با آیدی {telegram_id} به‌عنوان مدیر اضافه شد.",
        reply_markup=admin_main_menu(),
    )


# --------------------------- حذف مدیر ---------------------------
@router.callback_query(F.data == "admins:remove")
async def cb_remove_admin_start(callback: CallbackQuery, state: FSMContext) -> None:
    async with get_session() as session:
        user = await get_user_by_telegram_id(session, callback.from_user.id)
        if not user or not user.is_super_admin:
            await callback.answer("فقط مدیر اصلی می‌تواند این کار را انجام دهد.", show_alert=True)
            return

    await state.set_state(RemoveAdminStates.waiting_for_id)
    await callback.message.answer(
        "آیدی عددی مدیری که می‌خواهید حذف شود را ارسال کنید:",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(RemoveAdminStates.waiting_for_id, F.text == BTN.BACK)
async def cancel_remove_admin(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=admin_main_menu())


@router.message(RemoveAdminStates.waiting_for_id)
async def cb_remove_admin_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not message.text.strip().isdigit():
        await message.answer("آیدی نامعتبر است.")
        return

    telegram_id = int(message.text.strip())
    async with get_session() as session:
        ok = await remove_admin(session, telegram_id)
        await session.commit()

    await state.clear()
    if ok:
        await message.answer(f"✅ مدیر با آیدی {telegram_id} حذف شد.", reply_markup=admin_main_menu())
    else:
        await message.answer(
            "این کاربر مدیر نیست یا مدیر اصلی است (قابل حذف نیست).",
            reply_markup=admin_main_menu(),
        )
