"""
تنظیم تماس زمان‌بندی‌شده توسط مشاور:
    مشاور دانش‌آموز رو انتخاب می‌کنه -> یک روز از هفته‌ی پیش‌رو -> ساعت دقیق
    -> پیام تأیید/رد برای دانش‌آموز توی گروه ارسال میشه.
"""
import re
from datetime import datetime, timedelta, time as dtime

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery, InlineKeyboardMarkup, InlineKeyboardButton
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import get_advisor_by_telegram_id, create_scheduled_call, set_scheduled_call_confirm_message
from handlers.states import ScheduleCallStates
from keyboards.menus import BTN, cancel_menu, advisor_main_menu
from utils.jalali import WEEKDAY_NAMES_FA, gregorian_to_jalali_str
from utils.timeutils import LOCAL_TZ, UTC_TZ

router = Router(name="advisor_schedule_call")

TIME_PATTERN = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


def students_keyboard(students) -> InlineKeyboardMarkup:
    rows = []
    for s in students:
        if not s.group:
            continue  # دانش‌آموزی که هنوز گروه نداره قابل انتخاب نیست
        name = s.full_name or "بدون نام"
        rows.append([InlineKeyboardButton(text=name, callback_data=f"schedcall:student:{s.id}")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def days_keyboard(student_id: int) -> InlineKeyboardMarkup:
    rows = []
    now_local = datetime.now(LOCAL_TZ)
    for offset in range(7):
        d = (now_local + timedelta(days=offset)).date()
        weekday_name = WEEKDAY_NAMES_FA[d.weekday()]
        jalali_str = gregorian_to_jalali_str(d)
        rows.append([InlineKeyboardButton(
            text=f"{weekday_name} ({jalali_str})",
            callback_data=f"schedcall:day:{student_id}:{offset}",
        )])
    return InlineKeyboardMarkup(inline_keyboard=rows)


@router.message(F.text == BTN.ADVISOR_SCHEDULE_CALL)
async def open_schedule_call(message: Message) -> None:
    async with get_session() as session:
        advisor = await get_advisor_by_telegram_id(session, message.from_user.id)
        if not advisor:
            await message.answer("شما به‌عنوان مشاور ثبت نشده‌اید.")
            return
        students = advisor.students

    kb = students_keyboard(students)
    if not kb.inline_keyboard:
        await message.answer("هنوز دانش‌آموزی با گروه فعال به شما متصل نیست.")
        return

    await message.answer("برای کدوم دانش‌آموز می‌خوای تماس تنظیم کنی؟", reply_markup=kb)


@router.callback_query(F.data.startswith("schedcall:student:"))
async def cb_pick_student(callback: CallbackQuery) -> None:
    student_id = int(callback.data.split(":")[-1])
    await callback.message.answer(
        "کدوم روز از هفته‌ی پیش‌رو؟",
        reply_markup=days_keyboard(student_id),
    )
    await callback.answer()


@router.callback_query(F.data.startswith("schedcall:day:"))
async def cb_pick_day(callback: CallbackQuery, state: FSMContext) -> None:
    _, _, student_id_str, offset_str = callback.data.split(":")
    student_id = int(student_id_str)
    offset = int(offset_str)

    target_date = (datetime.now(LOCAL_TZ) + timedelta(days=offset)).date()
    await state.update_data(student_id=student_id, target_date=target_date.isoformat())
    await state.set_state(ScheduleCallStates.waiting_for_time)

    await callback.message.answer(
        f"ساعت دقیق تماس رو برای {gregorian_to_jalali_str(target_date)} به فرمت HH:MM وارد کن (مثلاً 18:30):",
        reply_markup=cancel_menu(),
    )
    await callback.answer()


@router.message(ScheduleCallStates.waiting_for_time, F.text == BTN.BACK)
async def cancel_schedule_call(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=advisor_main_menu())


@router.message(ScheduleCallStates.waiting_for_time)
async def on_time_entered(message: Message, state: FSMContext) -> None:
    if not message.text or not TIME_PATTERN.match(message.text.strip()):
        await message.answer("فرمت نامعتبر است. مثال درست: 18:30")
        return

    data = await state.get_data()
    student_id = data["student_id"]
    target_date = datetime.fromisoformat(data["target_date"]).date()
    hour, minute = map(int, message.text.strip().split(":"))
    await state.clear()

    # ساخت زمان محلی و تبدیل به UTC ساده برای ذخیره
    local_dt = datetime.combine(target_date, dtime(hour, minute), tzinfo=LOCAL_TZ)
    utc_dt = local_dt.astimezone(UTC_TZ).replace(tzinfo=None)

    async with get_session() as session:
        advisor = await get_advisor_by_telegram_id(session, message.from_user.id)
        if not advisor:
            await message.answer("خطا: مشاور پیدا نشد.", reply_markup=advisor_main_menu())
            return

        student = next((s for s in advisor.students if s.id == student_id), None)
        if not student or not student.group:
            await message.answer("خطا: این دانش‌آموز یا گروهش پیدا نشد.", reply_markup=advisor_main_menu())
            return

        call = await create_scheduled_call(
            session, advisor_id=advisor.id, student_id=student.id,
            group_id=student.group.id, scheduled_at=utc_dt,
        )
        await session.commit()
        group_chat_id = student.group.telegram_chat_id
        call_id = call.id

    kb = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="✅ تأیید می‌کنم", callback_data=f"schedcall:confirm:{call_id}"),
            InlineKeyboardButton(text="❌ نمی‌تونم", callback_data=f"schedcall:reject:{call_id}"),
        ]
    ])
    jalali_date_str = gregorian_to_jalali_str(target_date)
    sent = await message.bot.send_message(
        chat_id=group_chat_id,
        text=(
            f"📞 درخواست تماس جدید\n\n"
            f"مشاور می‌خواد در تاریخ {jalali_date_str} ساعت {hour:02d}:{minute:02d} با شما تماس بگیرد.\n"
            f"لطفاً تأیید یا رد کنید (فقط خود دانش‌آموز می‌تواند پاسخ دهد):"
        ),
        reply_markup=kb,
    )

    async with get_session() as session:
        await set_scheduled_call_confirm_message(session, call_id, sent.message_id)
        await session.commit()

    await message.answer("✅ درخواست تماس برای دانش‌آموز ارسال شد.", reply_markup=advisor_main_menu())
