"""
پنل مشاور: لیست دانش‌آموزان، تنظیم ساعت یادآوری (/set).
"""
import re
from datetime import time as dtime

from aiogram import Router, F
from aiogram.filters import Command
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import (
    get_advisor_by_telegram_id, set_advisor_reminder_time, get_advisor_average_rating,
    get_advisor_today_report_status,
)
from handlers.states import SetReminderStates
from keyboards.menus import BTN, cancel_menu, advisor_main_menu

router = Router(name="advisor_panel")

TIME_PATTERN = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")


@router.message(F.text == BTN.ADVISOR_MY_STUDENTS)
async def my_students(message: Message) -> None:
    async with get_session() as session:
        advisor = await get_advisor_by_telegram_id(session, message.from_user.id)

    if not advisor:
        await message.answer("شما به‌عنوان مشاور ثبت نشده‌اید.")
        return

    if not advisor.students:
        await message.answer("هنوز دانش‌آموزی به شما متصل نشده است.")
        return

    lines = ["👥 دانش‌آموزان شما:\n"]
    for s in advisor.students:
        name = s.full_name or "بدون نام"
        grade = s.grade or "-"
        lines.append(f"• {name} — پایه {grade}")
    await message.answer("\n".join(lines))


@router.message(F.text == BTN.ADVISOR_TODAY_REPORTS)
async def today_reports(message: Message) -> None:
    async with get_session() as session:
        advisor = await get_advisor_by_telegram_id(session, message.from_user.id)
        if not advisor:
            await message.answer("شما به‌عنوان مشاور ثبت نشده‌اید.")
            return
        status_list = await get_advisor_today_report_status(session, advisor.id)

    if not status_list:
        await message.answer("هنوز دانش‌آموزی به شما متصل نشده است.")
        return

    lines = ["📋 وضعیت گزارش‌کار امروز:\n"]
    for item in status_list:
        if item["checked"]:
            status_text = "✅ ارسال شد و چک شد"
        elif item["sent"]:
            status_text = "🟡 ارسال شد، هنوز چک نشده"
        else:
            status_text = "❌ هنوز ارسال نکرده"
        lines.append(f"• {item['name']}: {status_text}")

    await message.answer("\n".join(lines))


@router.message(F.text == BTN.ADVISOR_MY_RATING)
async def my_rating(message: Message) -> None:
    async with get_session() as session:
        advisor = await get_advisor_by_telegram_id(session, message.from_user.id)
        if not advisor:
            await message.answer("شما به‌عنوان مشاور ثبت نشده‌اید.")
            return
        avg = await get_advisor_average_rating(session, advisor.id)

    if avg is None:
        await message.answer("⭐ هنوز هیچ امتیازی برای شما ثبت نشده است.")
    else:
        await message.answer(f"⭐ میانگین امتیاز شما: {avg} از ۱۰")


@router.message(Command("set"))
async def cmd_set_reminder(message: Message, state: FSMContext) -> None:
    """
    استفاده: /set 22:00
    یا فقط /set بدون آرگومان تا ربات ساعت رو جدا بپرسه.
    """
    parts = message.text.split(maxsplit=1)
    if len(parts) == 2 and TIME_PATTERN.match(parts[1].strip()):
        await _apply_reminder(message, parts[1].strip())
        return

    await state.set_state(SetReminderStates.waiting_for_time)
    await message.answer(
        "ساعت یادآوری را به فرمت HH:MM ارسال کنید (مثلاً 22:00):",
        reply_markup=cancel_menu(),
    )


@router.message(SetReminderStates.waiting_for_time, F.text == BTN.BACK)
async def cancel_set_reminder(message: Message, state: FSMContext) -> None:
    await state.clear()
    await message.answer("لغو شد.", reply_markup=advisor_main_menu())


@router.message(SetReminderStates.waiting_for_time)
async def set_reminder_finish(message: Message, state: FSMContext) -> None:
    if not message.text or not TIME_PATTERN.match(message.text.strip()):
        await message.answer("فرمت نامعتبر است. مثال درست: 22:00")
        return
    await _apply_reminder(message, message.text.strip())
    await state.clear()


@router.message(F.text == BTN.ADVISOR_SET_REMINDER)
async def btn_set_reminder(message: Message, state: FSMContext) -> None:
    await cmd_set_reminder(message, state)


async def _apply_reminder(message: Message, time_str: str) -> None:
    hour, minute = map(int, time_str.split(":"))
    async with get_session() as session:
        ok = await set_advisor_reminder_time(session, message.from_user.id, dtime(hour, minute))
        await session.commit()

    if ok:
        await message.answer(
            f"✅ ساعت یادآوری روی {time_str} تنظیم شد.",
            reply_markup=advisor_main_menu(),
        )
    else:
        await message.answer("خطا: شما به‌عنوان مشاور ثبت نشده‌اید.")
