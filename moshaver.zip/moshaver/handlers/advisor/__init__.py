from aiogram import Router

from handlers.advisor import panel, schedule_call

router = Router(name="advisor")
router.include_router(panel.router)
router.include_router(schedule_call.router)
