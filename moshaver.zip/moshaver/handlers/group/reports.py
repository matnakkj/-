"""
گزارش‌کار روزانه:
    - دانش‌آموز توی گروه پیامی با #گزارش می‌فرسته -> ثبت میشه + پیام تأیید
    - مشاور روی همون پیام ریپلای می‌زنه -> ربات با ری‌اکت 👍 تأیید می‌کنه
"""
import logging

from aiogram import Router, F
from aiogram.types import Message, ReactionTypeEmoji

from database.engine import get_session
from database.crud import (
    get_group_by_chat_id,
    get_or_create_user,
    create_report,
    get_report_by_group_and_message,
    mark_report_checked,
    create_call_log,
    has_report_today,
    has_call_today,
)

router = Router(name="group_reports")
logger = logging.getLogger(__name__)


# --------------------------- ثبت گزارش‌کار ---------------------------
@router.message(F.chat.type.in_({"group", "supergroup"}), F.text.contains("#گزارش"))
async def on_report_hashtag(message: Message) -> None:
    async with get_session() as session:
        group = await get_group_by_chat_id(session, message.chat.id)
        if not group or not group.is_setup_complete or not group.student:
            return  # گروه هنوز کامل تنظیم نشده، این پیام رو نادیده می‌گیریم

        # فقط پیام‌های خودِ دانش‌آموزِ همین گروه به‌عنوان گزارش‌کار حساب میشه
        if message.from_user.id != group.student.user.telegram_id:
            return

        # اگه امروز (بازه‌ی گزارش‌کاری ۱۴:۰۰) قبلاً گزارش داده، این یکی رو کاملاً
        # نادیده می‌گیریم - نه ثبت میشه، نه پاسخی داده میشه.
        if await has_report_today(session, group.student.id):
            return

        await create_report(
            session,
            student_id=group.student.id,
            group_id=group.id,
            message_id=message.message_id,
        )
        await session.commit()

    await message.reply("✅ گزارش‌کار شما ثبت شد.")


# --------------------------- ثبت تماس مشاور با دانش‌آموز ---------------------------
@router.message(F.chat.type.in_({"group", "supergroup"}), F.text.contains("#تماس"))
async def on_call_hashtag(message: Message) -> None:
    async with get_session() as session:
        group = await get_group_by_chat_id(session, message.chat.id)
        if not group or not group.is_setup_complete or not group.advisor or not group.student:
            return

        # فقط پیام‌های خودِ مشاورِ همین گروه به‌عنوان ثبت تماس حساب میشه
        if message.from_user.id != group.advisor.user.telegram_id:
            return

        # اگه امروز (شبانه‌روز معمولی) قبلاً تماسی ثبت شده، نادیده می‌گیریم
        if await has_call_today(session, group.student.id):
            return

        await create_call_log(
            session,
            advisor_id=group.advisor_id,
            student_id=group.student.id,
            group_id=group.id,
            message_id=message.message_id,
        )
        await session.commit()

    await message.reply("📞 تماس ثبت شد.")


# --------------------------- تأیید توسط مشاور (ریپلای) ---------------------------
@router.message(F.chat.type.in_({"group", "supergroup"}), F.reply_to_message)
async def on_advisor_reply_to_report(message: Message) -> None:
    async with get_session() as session:
        group = await get_group_by_chat_id(session, message.chat.id)
        if not group or not group.advisor:
            return

        # فقط اگه ریپلای‌زننده همون مشاور این گروه باشه
        if message.from_user.id != group.advisor.user.telegram_id:
            return

        report = await get_report_by_group_and_message(
            session, message.chat.id, message.reply_to_message.message_id
        )
        if not report:
            return  # این ریپلای مربوط به یه پیام گزارش‌کار نبود

        if report.status.value == "checked":
            return  # قبلاً تأیید شده

        await mark_report_checked(session, report)
        await session.commit()

    try:
        await message.bot.set_message_reaction(
            chat_id=message.chat.id,
            message_id=message.message_id,
            reaction=[ReactionTypeEmoji(emoji="👍")],
        )
    except Exception as e:
        logger.error(f"خطا در ثبت ری‌اکت تأیید گزارش: {e}")
