"""
تأیید/رد تماس زمان‌بندی‌شده توسط دانش‌آموز + پاسخ به پیگیری «تماس برقرار شد؟»
(همه‌ی این‌ها فقط توسط خودِ دانش‌آموز همون گروه قابل پاسخ‌دادنه)
"""
import logging

from aiogram import Router, F
from aiogram.types import CallbackQuery

from database.engine import get_session
from database.crud import (
    get_scheduled_call,
    confirm_scheduled_call,
    reject_scheduled_call,
    answer_scheduled_call_followup,
)

router = Router(name="group_scheduled_calls")
logger = logging.getLogger(__name__)


@router.callback_query(F.data.startswith("schedcall:confirm:"))
async def cb_confirm(callback: CallbackQuery) -> None:
    call_id = int(callback.data.split(":")[-1])

    async with get_session() as session:
        call = await get_scheduled_call(session, call_id)
        if not call:
            await callback.answer("این درخواست دیگر معتبر نیست.", show_alert=True)
            return
        if callback.from_user.id != call.student.user.telegram_id:
            await callback.answer("فقط خودِ دانش‌آموز می‌تواند پاسخ دهد.", show_alert=True)
            return
        if call.status.value != "pending":
            await callback.answer("قبلاً به این درخواست پاسخ داده شده.", show_alert=True)
            return

        await confirm_scheduled_call(session, call_id)
        await session.commit()

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("✅ تماس تأیید شد.")
    await callback.answer()


@router.callback_query(F.data.startswith("schedcall:reject:"))
async def cb_reject(callback: CallbackQuery) -> None:
    call_id = int(callback.data.split(":")[-1])

    async with get_session() as session:
        call = await get_scheduled_call(session, call_id)
        if not call:
            await callback.answer("این درخواست دیگر معتبر نیست.", show_alert=True)
            return
        if callback.from_user.id != call.student.user.telegram_id:
            await callback.answer("فقط خودِ دانش‌آموز می‌تواند پاسخ دهد.", show_alert=True)
            return
        if call.status.value != "pending":
            await callback.answer("قبلاً به این درخواست پاسخ داده شده.", show_alert=True)
            return

        await reject_scheduled_call(session, call_id)
        await session.commit()
        advisor_telegram_id = call.advisor.user.telegram_id
        group_title = call.group.title or "-"

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("❌ تماس رد شد.")
    await callback.answer()

    try:
        await callback.bot.send_message(
            chat_id=advisor_telegram_id,
            text=(
                f"❌ دانش‌آموز درخواست تماس در گروه «{group_title}» را رد کرد.\n"
                f"لطفاً یک زمان جدید تنظیم کنید."
            ),
        )
    except Exception as e:
        logger.error(f"خطا در اطلاع‌رسانی رد تماس به مشاور: {e}")


@router.callback_query(F.data.startswith("schedcall:followup:"))
async def cb_followup(callback: CallbackQuery) -> None:
    parts = callback.data.split(":")
    call_id = int(parts[2])
    happened = parts[3] == "yes"

    async with get_session() as session:
        call = await get_scheduled_call(session, call_id)
        if not call:
            await callback.answer("این درخواست دیگر معتبر نیست.", show_alert=True)
            return
        if callback.from_user.id != call.student.user.telegram_id:
            await callback.answer("فقط خودِ دانش‌آموز می‌تواند پاسخ دهد.", show_alert=True)
            return

        await answer_scheduled_call_followup(session, call_id, happened)
        await session.commit()

    await callback.message.edit_reply_markup(reply_markup=None)
    await callback.message.answer("✅ ثبت شد، ممنون." if happened else "متوجه شدیم، ثبت شد.")
    await callback.answer()
