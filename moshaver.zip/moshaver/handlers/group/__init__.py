from aiogram import Router

from handlers.group import setup, reports, scheduled_calls

router = Router(name="group")
router.include_router(setup.router)
router.include_router(reports.router)
router.include_router(scheduled_calls.router)
