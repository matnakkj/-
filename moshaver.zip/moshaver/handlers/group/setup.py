"""
راه‌اندازی گروه مشاوره:
    ۱. ربات به گروه اضافه و ادمین می‌شود -> عکس گروه عوض می‌شود
    ۲. از سازنده‌ی گروه خواسته می‌شود مشخصات دانش‌آموز را وارد کند
    ۳. دو دکمه ظاهر می‌شود: «معرفی مشاور» و «معرفی دانش‌آموز»
    ۴. بعد از تکمیل هر دو، گروه آماده‌ی کار است.
"""
import logging
import os

from aiogram import Router, F, Bot
from aiogram.enums import ChatMemberStatus
from aiogram.types import (
    ChatMemberUpdated,
    Message,
    CallbackQuery,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
    FSInputFile,
)
from aiogram.fsm.context import FSMContext

from config import config
from database.engine import get_session
from database.crud import (
    get_or_create_group,
    get_group_by_chat_id,
    assign_advisor_to_group,
    assign_student_to_group,
    get_or_create_user,
    delete_group_and_cleanup,
)
from handlers.states import GroupSetupStates
from utils.jalali import parse_jalali_date

router = Router(name="group_setup")
logger = logging.getLogger(__name__)

_LEFT_STATUSES = (ChatMemberStatus.LEFT, ChatMemberStatus.KICKED)


def intro_buttons_keyboard(advisor_done: bool, student_done: bool) -> InlineKeyboardMarkup | None:
    rows = []
    if not advisor_done:
        rows.append([InlineKeyboardButton(text="📌 معرفی مشاور", callback_data="group:intro:advisor")])
    if not student_done:
        rows.append([InlineKeyboardButton(text="🎓 معرفی دانش‌آموز", callback_data="group:intro:student")])
    return InlineKeyboardMarkup(inline_keyboard=rows) if rows else None


async def send_onboarding_guide(bot: Bot, chat_id: int) -> None:
    """بعد از تکمیل تنظیمات گروه (هم مشاور هم دانش‌آموز مشخص شدن)، راهنمای کامل قابلیت‌ها فرستاده میشه."""
    text = (
        "🎉 تنظیمات این گروه کامل شد!\n\n"
        "📖 راهنمای قابلیت‌های این گروه:\n\n"
        "📝 برای ثبت گزارش‌کار روزانه، دانش‌آموز باید هر روز یک پیام حاوی "
        "#گزارش بفرستد. مشاور با ریپلای‌کردن روی همون پیام، آن را تأیید می‌کند.\n\n"
        "📞 برای ثبت تماسی که انجام شده، مشاور باید پیامی حاوی #تماس بفرستد.\n\n"
        "📅 مشاور می‌تواند از پنل خودش (در پیوی ربات) یک زمان مشخص برای تماس "
        "با این دانش‌آموز تنظیم کند؛ در همین گروه یک درخواست تأیید برای دانش‌آموز "
        "ارسال می‌شود.\n\n"
        "⭐ هر هفته یک نظرسنجی کوتاه درباره‌ی کیفیت مشاوره برای دانش‌آموز در "
        "پیوی ربات ارسال می‌شود.\n\n"
        "📢 دانش‌آموز از پنل خودش (در پیوی ربات) می‌تواند هر زمان انتقاد یا "
        "نظرش درباره‌ی مشاور را برای مدیریت ثبت کند.\n\n"
        "⏰ مشاور می‌تواند در پیوی ربات با دستور /set یک ساعت مشخص کند تا اگر "
        "دانش‌آموز گزارش نداده باشد، یادآوری ارسال شود.\n\n"
        "برای همه‌ی این قابلیت‌ها (پنل مشاور/دانش‌آموز)، کافیست در پیوی ربات "
        "دستور /start را بزنید."
    )
    try:
        await bot.send_message(chat_id=chat_id, text=text)
    except Exception as e:
        logger.error(f"خطا در ارسال راهنمای جامع گروه: {e}")


# --------------------------- تغییر وضعیت عضویت ربات در گروه ---------------------------
@router.my_chat_member(F.chat.type.in_({"group", "supergroup"}))
async def bot_membership_changed(event: ChatMemberUpdated, bot: Bot) -> None:
    new_status = event.new_chat_member.status
    old_status = event.old_chat_member.status

    # حالت ۱: ربات از گروه حذف/بن شده -> کل اطلاعات این گروه پاک میشه
    if new_status in _LEFT_STATUSES and old_status not in _LEFT_STATUSES:
        async with get_session() as session:
            removed = await delete_group_and_cleanup(session, event.chat.id)
            await session.commit()
        if removed:
            logger.info(f"ربات از گروه {event.chat.id} حذف شد؛ اطلاعات این گروه کامل پاک شد.")
        return

    # حالت ۲: ربات تازه ادمین شده -> شروع فرآیند راه‌اندازی گروه
    if new_status != ChatMemberStatus.ADMINISTRATOR or old_status == ChatMemberStatus.ADMINISTRATOR:
        return

    async with get_session() as session:
        group = await get_or_create_group(
            session, telegram_chat_id=event.chat.id, title=event.chat.title
        )
        if group.is_setup_complete:
            await session.commit()
            return

        creator_id = None
        try:
            admins = await bot.get_chat_administrators(event.chat.id)
            for m in admins:
                if m.status == ChatMemberStatus.CREATOR:
                    creator_id = m.user.id
                    break
        except Exception as e:
            logger.error(f"خطا در گرفتن لیست ادمین‌های گروه: {e}")

        if creator_id:
            group.creator_telegram_id = creator_id
        await session.commit()

    # تغییر عکس گروه (اختیاری - اگه فایل عکس موجود نباشه، رد میشیم)
    if os.path.exists(config.GROUP_PHOTO_PATH):
        try:
            await bot.set_chat_photo(event.chat.id, photo=FSInputFile(config.GROUP_PHOTO_PATH))
        except Exception as e:
            logger.error(f"خطا در تغییر عکس گروه: {e}")
    else:
        logger.warning(f"فایل عکس گروه پیدا نشد: {config.GROUP_PHOTO_PATH}")

    await bot.send_message(
        event.chat.id,
        "✅ ربات با موفقیت به گروه اضافه و ادمین شد.\n\n"
        "سازنده‌ی گروه، لطفاً روی دکمه زیر بزنید تا مشخصات دانش‌آموز ثبت شود:",
        reply_markup=InlineKeyboardMarkup(inline_keyboard=[
            [InlineKeyboardButton(text="📝 شروع ثبت اطلاعات دانش‌آموز", callback_data="group:setup:start")]
        ]),
    )


# --------------------------- فرم ورود اطلاعات (فقط سازنده) ---------------------------
@router.callback_query(F.data == "group:setup:start")
async def cb_setup_start(callback: CallbackQuery, state: FSMContext) -> None:
    async with get_session() as session:
        group = await get_group_by_chat_id(session, callback.message.chat.id)

    if not group:
        await callback.answer("خطا: گروه پیدا نشد.", show_alert=True)
        return

    if group.creator_telegram_id and callback.from_user.id != group.creator_telegram_id:
        await callback.answer("فقط سازنده‌ی گروه می‌تواند این کار را انجام دهد.", show_alert=True)
        return

    if group.is_setup_complete:
        await callback.answer("قبلاً تکمیل شده است.", show_alert=True)
        return

    await state.set_state(GroupSetupStates.waiting_for_full_name)
    await callback.message.answer("نام و نام‌خانوادگی دانش‌آموز را وارد کنید:")
    await callback.answer()


@router.message(GroupSetupStates.waiting_for_full_name, F.chat.type.in_({"group", "supergroup"}))
async def step_full_name(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً نام و نام‌خانوادگی را به‌صورت متن ارسال کنید.")
        return
    await state.update_data(full_name=message.text.strip())
    await state.set_state(GroupSetupStates.waiting_for_phone)
    await message.answer("شماره تماس دانش‌آموز را وارد کنید (مثلاً 09123456789):")


@router.message(GroupSetupStates.waiting_for_phone, F.chat.type.in_({"group", "supergroup"}))
async def step_phone(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً شماره تماس را به‌صورت متن ارسال کنید.")
        return
    await state.update_data(phone=message.text.strip())
    await state.set_state(GroupSetupStates.waiting_for_grade)
    await message.answer("پایه تحصیلی دانش‌آموز را وارد کنید (مثلاً دوازدهم):")


@router.message(GroupSetupStates.waiting_for_grade, F.chat.type.in_({"group", "supergroup"}))
async def step_grade(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً پایه تحصیلی را به‌صورت متن ارسال کنید.")
        return
    await state.update_data(grade=message.text.strip())
    await state.set_state(GroupSetupStates.waiting_for_start_date)
    await message.answer("تاریخ شروع مشاوره را وارد کنید (مثلاً 1403/07/01):")


@router.message(GroupSetupStates.waiting_for_start_date, F.chat.type.in_({"group", "supergroup"}))
async def step_start_date(message: Message, state: FSMContext) -> None:
    if not message.text:
        await message.answer("لطفاً تاریخ را به‌صورت متن ارسال کنید.")
        return

    start_date = parse_jalali_date(message.text.strip())
    if not start_date:
        await message.answer(
            "فرمت تاریخ نامعتبر است. لطفاً به فرمت شمسی و به‌شکل ۱۴۰۳/۰۷/۰۱ وارد کنید:"
        )
        return

    data = await state.get_data()
    await state.clear()

    async with get_session() as session:
        group = await get_group_by_chat_id(session, message.chat.id)
        if not group:
            await message.answer("خطا: گروه پیدا نشد.")
            return

        group.pending_full_name = data.get("full_name")
        group.pending_phone = data.get("phone")
        group.pending_grade = data.get("grade")
        group.pending_start_date = start_date
        await session.commit()

        kb = intro_buttons_keyboard(group.advisor_button_clicked, group.student_button_clicked)

    sent = await message.answer(
        "✅ اطلاعات ثبت شد.\n\n"
        "حالا مشاور و دانش‌آموز این گروه باید خودشون رو معرفی کنن:\n"
        "🔹 اگر شما مشاور این گروه هستید، روی «📌 معرفی مشاور» بزنید.\n"
        "🔹 اگر شما دانش‌آموز این گروه هستید، روی «🎓 معرفی دانش‌آموز» بزنید.",
        reply_markup=kb,
    )

    async with get_session() as session:
        group = await get_group_by_chat_id(session, message.chat.id)
        group.intro_message_id = sent.message_id
        await session.commit()


# --------------------------- دکمه‌های معرفی مشاور/دانش‌آموز ---------------------------
@router.callback_query(F.data == "group:intro:advisor")
async def cb_intro_advisor(callback: CallbackQuery, bot: Bot) -> None:
    # فقط کسی که توی خودِ گروه تلگرام هم ادمینه می‌تونه به‌عنوان مشاور معرفی بشه
    member = await bot.get_chat_member(callback.message.chat.id, callback.from_user.id)
    if member.status not in (ChatMemberStatus.ADMINISTRATOR, ChatMemberStatus.CREATOR):
        await callback.answer("فقط ادمین‌های گروه می‌توانند به‌عنوان مشاور معرفی شوند.", show_alert=True)
        return

    async with get_session() as session:
        group = await get_group_by_chat_id(session, callback.message.chat.id)
        if not group:
            await callback.answer("خطا: گروه پیدا نشد.", show_alert=True)
            return

        if group.advisor_button_clicked:
            await callback.answer("قبلاً مشاور این گروه معرفی شده.", show_alert=True)
            return

        result = await assign_advisor_to_group(session, group, callback.from_user.id)
        if result != "ok":
            await callback.answer(result, show_alert=True)
            return

        await session.commit()
        kb = intro_buttons_keyboard(group.advisor_button_clicked, group.student_button_clicked)

    await callback.message.edit_reply_markup(reply_markup=kb)
    await callback.answer("✅ شما به‌عنوان مشاور این گروه ثبت شدید.")

    if kb is None:
        await send_onboarding_guide(bot, callback.message.chat.id)


@router.callback_query(F.data == "group:intro:student")
async def cb_intro_student(callback: CallbackQuery, bot: Bot) -> None:
    async with get_session() as session:
        group = await get_group_by_chat_id(session, callback.message.chat.id)
        if not group:
            await callback.answer("خطا: گروه پیدا نشد.", show_alert=True)
            return

        if group.student_button_clicked:
            await callback.answer("قبلاً دانش‌آموز این گروه معرفی شده.", show_alert=True)
            return

        user = await get_or_create_user(
            session,
            telegram_id=callback.from_user.id,
            username=callback.from_user.username,
            full_name=callback.from_user.full_name,
        )
        result = await assign_student_to_group(session, user, group)
        if result != "ok":
            await callback.answer(result, show_alert=True)
            return

        await session.commit()
        kb = intro_buttons_keyboard(group.advisor_button_clicked, group.student_button_clicked)

    await callback.message.edit_reply_markup(reply_markup=kb)
    await callback.answer("✅ شما به‌عنوان دانش‌آموز این گروه ثبت شدید.")

    if kb is None:
        await send_onboarding_guide(bot, callback.message.chat.id)


# --------------------------- محافظ: /start و دستورات پنل هیچ‌وقت توی گروه کار نکنن ---------------------------
# این یه لایه‌ی اضافه‌ی اطمینانه؛ پنل‌های اصلی (common/admin/advisor/student) از قبل
# با فیلتر global توی bot.py محدود به چت خصوصی شدن. این‌جا فقط برای قطعی‌شدن کامل،
# هر پیام دستوری شبیه /start که جزو فرآیند فعال گروه نباشه رو بی‌صدا نادیده می‌گیریم.
# (این هندلر عمداً آخر فایل ثبت شده تا هندلرهای مرحله‌ای فرم گروه اولویت داشته باشن)
@router.message(F.chat.type.in_({"group", "supergroup"}), F.text.startswith("/"))
async def ignore_bot_commands_in_group(message: Message) -> None:
    return None
