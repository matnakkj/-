"""
این روتر باید آخرین روتر ثبت‌شده در bot.py باشد.
اگه دکمه‌ی «بازگشت» بدون هیچ state فعالی زده بشه (یعنی هیچ‌کدوم از
هندلرهای اختصاصی جواب ندادن)، این‌جا می‌گیریمش و منوی همون پنل کاربر
رو دوباره نشون می‌دیم تا کاربر گیر نکنه.
"""
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import get_or_create_user, resolve_panel, has_multiple_panels
from keyboards.menus import BTN, admin_main_menu, advisor_main_menu, student_main_menu

router = Router(name="fallback")


@router.message(F.text == BTN.BACK)
async def stray_back_button(message: Message, state: FSMContext) -> None:
    await state.clear()
    async with get_session() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name,
        )
        await session.commit()
        panel = resolve_panel(user)
        can_switch = has_multiple_panels(user) and user.is_admin
        has_advisor = bool(user.student_profile and user.student_profile.advisor_id)

    if panel == "admin":
        kb = admin_main_menu(show_switch=can_switch, is_super_admin=user.is_super_admin)
    elif panel == "advisor":
        kb = advisor_main_menu(show_switch=can_switch)
    else:
        kb = student_main_menu(has_advisor=has_advisor, show_switch=can_switch)

    await message.answer("منوی اصلی:", reply_markup=kb)
