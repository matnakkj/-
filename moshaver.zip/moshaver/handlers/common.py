"""
هندلرهای مشترک بین همه‌ی نقش‌ها: /start و سوییچ پنل.
"""
import logging

from aiogram import Router, F
from aiogram.enums import ChatMemberStatus
from aiogram.filters import CommandStart
from aiogram.types import Message, ChatMemberUpdated
from aiogram.fsm.context import FSMContext

from database.engine import get_session
from database.crud import get_or_create_user, resolve_panel, has_multiple_panels, delete_user_and_cleanup
from keyboards.menus import admin_main_menu, advisor_main_menu, student_main_menu, BTN

router = Router(name="common")
logger = logging.getLogger(__name__)

_LEFT_STATUSES = (ChatMemberStatus.LEFT, ChatMemberStatus.KICKED)


async def show_panel(message: Message, panel: str, has_advisor: bool, can_switch: bool, is_super_admin: bool = False) -> None:
    if panel == "admin":
        text = "🛠 به پنل مدیریت خوش آمدید."
        kb = admin_main_menu(show_switch=can_switch, is_super_admin=is_super_admin)
    elif panel == "advisor":
        text = "🧑‍🏫 به پنل مشاوره خوش آمدید."
        kb = advisor_main_menu(show_switch=can_switch)
    else:
        text = "🎓 به ربات مشاوره تحصیلی خوش آمدید."
        kb = student_main_menu(has_advisor=has_advisor, show_switch=can_switch)
    await message.answer(text, reply_markup=kb)


@router.message(CommandStart())
async def cmd_start(message: Message, state: FSMContext) -> None:
    await state.clear()
    async with get_session() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name,
        )
        await session.commit()

        panel = resolve_panel(user)
        can_switch = has_multiple_panels(user) and user.is_admin
        has_advisor = bool(user.student_profile and user.student_profile.advisor_id)
        is_super_admin = user.is_super_admin

    await show_panel(message, panel, has_advisor, can_switch, is_super_admin)


@router.message(F.text.in_({BTN.SWITCH_TO_ADMIN, BTN.SWITCH_TO_MY_PANEL}))
async def switch_panel(message: Message, state: FSMContext) -> None:
    await state.clear()
    async with get_session() as session:
        user = await get_or_create_user(
            session,
            telegram_id=message.from_user.id,
            username=message.from_user.username,
            full_name=message.from_user.full_name,
        )

        if message.text == BTN.SWITCH_TO_ADMIN:
            if not user.is_admin:
                await message.answer("شما دسترسی مدیریت ندارید.")
                return
            user.active_panel = "admin"
        else:
            # برگشت به پنل شخصی: مشاور اگه بود، وگرنه دانش‌آموز
            user.active_panel = "advisor" if user.advisor_profile else "student"

        await session.commit()
        panel = resolve_panel(user)
        can_switch = has_multiple_panels(user) and user.is_admin
        has_advisor = bool(user.student_profile and user.student_profile.advisor_id)
        is_super_admin = user.is_super_admin

    await show_panel(message, panel, has_advisor, can_switch, is_super_admin)


# --------------------------- بلاک کردن ربات توسط کاربر ---------------------------
@router.my_chat_member(F.chat.type == "private")
async def on_user_blocked_bot(event: ChatMemberUpdated) -> None:
    new_status = event.new_chat_member.status
    old_status = event.old_chat_member.status

    if new_status not in _LEFT_STATUSES or old_status in _LEFT_STATUSES:
        return  # فقط لحظه‌ی بلاک‌کردن/حذف‌کردن ربات برامون مهمه

    async with get_session() as session:
        removed = await delete_user_and_cleanup(session, event.chat.id)
        await session.commit()

    if removed:
        logger.info(f"کاربر {event.chat.id} ربات را بلاک کرد؛ اطلاعاتش کامل پاک شد.")
