# راهنمای کامل نصب ربات مشاوره تحصیلی (از صفر)

این راهنما فرض می‌کند یک VPS اوبونتویی خالی داری و هیچ‌چیزی روش نصب نیست.
مرحله به مرحله جلو برو، هیچ مرحله‌ای رو رد نکن.

---

## مرحله ۰: قبل از شروع، این ۴ تا رو آماده کن

### الف) ساخت ربات و گرفتن توکن
1. توی تلگرام برو سراغ [@BotFather](https://t.me/BotFather)
2. بزن `/newbot` و اسم و یوزرنیم دلخواه بده (یوزرنیم باید به `bot` ختم بشه، مثلاً `MyMoshaverBot`)
3. یک توکن به این شکل بهت میده: `123456789:AAExxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`
4. این رو یه‌جا کپی کن، لازمش داریم

### ب) گرفتن آیدی عددی خودت (به‌عنوان مدیر اصلی)
1. برو سراغ [@userinfobot](https://t.me/userinfobot)
2. بزن Start، آیدی عددیت رو بهت میده (یه عدد، مثلاً `123456789`)

### ج) ساخت ۳ تا کانال تلگرام (خصوصی، فقط برای خودت)
باید ۳ تا کانال بسازی (Private Channel):
1. **کانال پیام ناشناس**
2. **کانال نظرات هفتگی مشاوره**
3. **کانال ثبت‌نامی‌ها (رسیدها)**

برای هر کدوم:
- یک کانال جدید بساز (از منوی تلگرام: New Channel)
- **ربات ساخته‌شده رو به هر ۳ کانال اضافه کن و ادمین کن** (با دسترسی ارسال پیام)
- برای گرفتن آیدی عددی هر کانال: یک پیام داخل کانال بفرست، بعد اون پیام رو فوروارد کن به [@userinfobot](https://t.me/userinfobot) — آیدی کانال معمولاً یه عدد منفی طولانیه، مثلاً `-1001234567890`

### د) دسترسی به سرور (VPS)
یک VPS اوبونتویی (نسخه ۲۲.04 یا ۲۴.04 پیشنهاد میشه) با دسترسی SSH لازم داری. از کامپیوترت وصل شو:
```bash
ssh root@IP_SERVER
```
(به‌جای `IP_SERVER` آیدی سرورت رو بذار، پسورد رو هم که موقع خرید سرور بهت دادن وارد کن)

---

## مرحله ۱: به‌روزرسانی سرور و نصب پیش‌نیازها

```bash
apt update && apt upgrade -y
apt install -y python3-pip python3-venv postgresql postgresql-contrib unzip nano
```

بررسی کن پایتون نصب شده:
```bash
python3 --version
```
باید یه چیزی مثل `Python 3.10` یا بالاتر نشون بده.

---

## مرحله ۲: ساخت دیتابیس PostgreSQL

وارد شو به‌عنوان کاربر postgres:
```bash
sudo -u postgres psql
```

حالا داخل محیط psql (که با `postgres=#` شروع میشه) این دستورات رو یکی‌یکی بزن:
```sql
CREATE DATABASE moshaver_db;
CREATE USER moshaver_user WITH PASSWORD 'یک-پسورد-قوی-اینجا-بذار';
GRANT ALL PRIVILEGES ON DATABASE moshaver_db TO moshaver_user;
ALTER DATABASE moshaver_db OWNER TO moshaver_user;
\q
```
⚠️ به‌جای `یک-پسورد-قوی-اینجا-بذار` یه پسورد واقعی و قوی بذار و یادداشتش کن، الان لازمش داریم.

---

## مرحله ۳: آپلود فایل‌های پروژه روی سرور

از کامپیوتر خودت (نه داخل SSH سرور)، فایل `moshaver.zip` رو با یکی از این روش‌ها بفرست روی سرور:

**روش ساده (از ترمینال خودت، نه سرور):**
```bash
scp moshaver.zip root@IP_SERVER:/opt/
```

یا اگه از ویندوز با برنامه‌ای مثل FileZilla / WinSCP وصل میشی، فایل `moshaver.zip` رو بفرست توی مسیر `/opt/` سرور.

بعد برگرد به SSH سرور و اکسترکتش کن:
```bash
cd /opt
unzip moshaver.zip
cd moshaver
ls
```
باید فایل‌هایی مثل `bot.py`, `config.py`, `requirements.txt` رو ببینی.

---

## مرحله ۴: ساخت محیط مجازی پایتون و نصب پکیج‌ها

```bash
cd /opt/moshaver
python3 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```
این چند دقیقه طول می‌کشه، صبر کن تمام بشه.

---

## مرحله ۵: تنظیم فایل `.env`

```bash
cp .env.example .env
nano .env
```

حالا این فایل رو با مقادیر واقعی خودت پر کن (با کیبورد بنویس، با فلش‌ها جابه‌جا شو):

```env
BOT_TOKEN=توکنی که از BotFather گرفتی

SUPER_ADMIN_ID=آیدی عددی خودت

DATABASE_URL=postgresql+asyncpg://moshaver_user:همون-پسوردی-که-بالا-ساختی@localhost:5432/moshaver_db

ANONYMOUS_CHANNEL_ID=آیدی کانال پیام ناشناس (با علامت منفی، مثلاً -1001234567890)
RATING_CHANNEL_ID=آیدی کانال نظرات هفتگی
REGISTRATION_CHANNEL_ID=آیدی کانال ثبت‌نامی‌ها

GROUP_PHOTO_PATH=assets/group_photo.jpg
TIMEZONE=Asia/Tehran
```

برای ذخیره در nano: `Ctrl+O` بعد `Enter`، برای خروج: `Ctrl+X`

---

## مرحله ۶: (اختیاری) عکس ثابت گروه

اگه می‌خوای عکس مخصوصی برای گروه‌ها ست بشه:
```bash
mkdir -p /opt/moshaver/assets
```
عکس دلخواهت رو با اسم `group_photo.jpg` توی این مسیر آپلود کن (با همون روش scp/FileZilla مرحله ۳).
اگه فعلاً نداری، مشکلی نیست — این قابلیت در فاز بعدی توسعه فعال میشه.

---

## مرحله ۷: تست اجرای ربات

```bash
cd /opt/moshaver
source venv/bin/activate
python bot.py
```

اگه همه‌چیز درست باشه، این خط رو می‌بینی:
```
ربات در حال اجراست...
```

حالا برو توی تلگرام، ربات خودت رو پیدا کن، بزن `/start`. باید پنل مدیریت رو ببینی (چون آیدیت رو به‌عنوان SUPER_ADMIN_ID گذاشتی).

اگه کار کرد، با `Ctrl+C` متوقفش کن (چون الان می‌خوایم به‌صورت دائمی و در پس‌زمینه اجراش کنیم).

### اگه خطا خوردی:
- `BOT_TOKEN در فایل .env تنظیم نشده` → فایل `.env` رو دوباره چک کن
- خطای اتصال به دیتابیس → پسورد/نام دیتابیس رو توی `DATABASE_URL` دوباره چک کن
- هر خطای دیگه‌ای رو برام کپی کن بفرست تا کمکت کنم

---

## مرحله ۸: اجرای دائمی و خودکار با systemd

این کار باعث میشه ربات همیشه روشن بمونه و حتی بعد از ریستارت سرور خودش دوباره بالا بیاد.

```bash
nano /etc/systemd/system/moshaver-bot.service
```

این محتوا رو داخلش بذار:
```ini
[Unit]
Description=Moshaver Telegram Bot
After=network.target postgresql.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/moshaver
ExecStart=/opt/moshaver/venv/bin/python bot.py
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```
ذخیره کن (`Ctrl+O` سپس `Enter` سپس `Ctrl+X`).

حالا فعالش کن:
```bash
systemctl daemon-reload
systemctl enable moshaver-bot
systemctl start moshaver-bot
```

بررسی کن که سالم روشنه:
```bash
systemctl status moshaver-bot
```
باید سبز رنگ و `active (running)` نشون بده.

دیدن لاگ زنده (برای بررسی خطاها در آینده):
```bash
journalctl -u moshaver-bot -f
```
(با `Ctrl+C` از حالت زنده خارج شو، ربات خاموش نمیشه)

---

## دستورات مفید برای بعداً

| کار | دستور |
|---|---|
| ری‌استارت ربات (بعد از تغییر کد) | `systemctl restart moshaver-bot` |
| متوقف کردن ربات | `systemctl stop moshaver-bot` |
| روشن کردن دوباره | `systemctl start moshaver-bot` |
| دیدن وضعیت | `systemctl status moshaver-bot` |
| دیدن لاگ‌های اخیر | `journalctl -u moshaver-bot -n 100` |
| ویرایش تنظیمات | `nano /opt/moshaver/.env` سپس `systemctl restart moshaver-bot` |

---

## ✅ چک‌لیست نهایی برای تست

بعد از راه‌اندازی، این‌ها رو تست کن:
- [ ] `/start` → پنل مدیریت باز میشه (چون سوپر ادمینی)
- [ ] از «مدیریت مدیران» → «لیست مدیران» → باید خودت رو با تگ «مدیر اصلی» ببینی
- [ ] از یه اکانت تلگرام دیگه (مثلاً گوشی دوم یا دوستت) `/start` بزن، باید پنل دانش‌آموز رو ببینه
- [ ] از پنل مدیر، اون آیدی رو به‌عنوان مشاور اضافه کن → باید پیام موفقیت بگیری
- [ ] از اکانت مشاور، دستور `/set 22:00` رو بزن → باید تأیید بگیری
- [ ] از پنل دانش‌آموز، «ارسال پیام ناشناس» رو بزن و یه پیام بفرست → باید توی کانال پیام ناشناس ظاهر بشه

اگه همه‌ی این‌ها جواب داد، فاز اول کامل و سالمه و می‌ریم سراغ فاز بعدی. 🎉

هر جای کار گیر کردی یا خطا گرفتی، متن خطا رو کامل برام بفرست تا دقیق بررسی کنم.
