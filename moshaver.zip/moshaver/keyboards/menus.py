"""
منوهای اصلی هر پنل.
فعلاً از ReplyKeyboard برای منوی اصلی استفاده می‌کنیم (ساده و همیشه پایین صفحه).
زیرمنوها (لیست‌ها، صفحه‌بندی و ...) در فازهای بعدی با InlineKeyboard ساخته میشن.
"""
from aiogram.types import ReplyKeyboardMarkup, KeyboardButton


# --- متن دکمه‌ها را یک‌جا نگه می‌داریم تا در handler ها هم قابل تشخیص باشند ---
class BTN:
    # سوییچ پنل (فقط برای مدیرهایی که پنل دیگه‌ای هم دارن)
    SWITCH_TO_ADMIN = "🛠 پنل مدیریت"
    SWITCH_TO_MY_PANEL = "🔙 بازگشت به پنل شخصی"

    # پنل مدیر
    ADMIN_MANAGE_ADMINS = "👤 مدیریت مدیران"
    ADMIN_MANAGE_ADVISORS = "🧑‍🏫 مدیریت مشاوران"
    ADMIN_PACKAGES = "📦 پکیج‌های مشاوره"
    ADMIN_STATS = "📊 آمار و گزارش‌گیری"
    ADMIN_BROADCAST = "📢 پیام همگانی"
    ADMIN_CONTENT = "🗂 مدیریت محتوا"
    ADMIN_RATING_SCHEDULE = "🗳 تنظیم نظرسنجی هفتگی"
    ADMIN_BACKUP = "💾 پشتیبان‌گیری و بازگردانی"

    # پنل مشاور
    ADVISOR_MY_STUDENTS = "👥 دانش‌آموزان من"
    ADVISOR_SET_REMINDER = "⏰ تنظیم ساعت یادآوری"
    ADVISOR_TODAY_REPORTS = "📋 گزارش‌های امروز"
    ADVISOR_MY_RATING = "⭐ امتیاز من"
    ADVISOR_SCHEDULE_CALL = "📅 تنظیم زمان تماس"

    # پنل دانش‌آموز
    STUDENT_GPA = "📊 محاسبه معدل نهایی"
    STUDENT_RANK = "📈 محاسبه تراز"
    STUDENT_TEST_BANK = "📝 بانک سوال تستی"
    STUDENT_ESSAY_BANK = "📚 بانک سوال تشریحی"
    STUDENT_ANONYMOUS = "✉️ ارسال پیام ناشناس"
    STUDENT_FIELDS_INTRO = "🎓 معرفی رشته‌ها"
    STUDENT_KONKUR_QA = "📄 سوالات و پاسخنامه کنکور"
    STUDENT_BUY_ADVISOR = "💳 خرید مشاور"
    STUDENT_MY_STATUS = "📌 وضعیت مشاوره من"
    STUDENT_COMPLAINT = "📢 ثبت انتقاد از مشاور"
    STUDENT_CONTENT = "📚 محتوای آموزشی"

    BACK = "🔙 بازگشت"


def admin_main_menu(show_switch: bool = False, is_super_admin: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=BTN.ADMIN_MANAGE_ADMINS), KeyboardButton(text=BTN.ADMIN_MANAGE_ADVISORS)],
        [KeyboardButton(text=BTN.ADMIN_PACKAGES), KeyboardButton(text=BTN.ADMIN_STATS)],
        [KeyboardButton(text=BTN.ADMIN_BROADCAST), KeyboardButton(text=BTN.ADMIN_CONTENT)],
        [KeyboardButton(text=BTN.ADMIN_RATING_SCHEDULE)],
    ]
    if is_super_admin:
        rows.append([KeyboardButton(text=BTN.ADMIN_BACKUP)])
    if show_switch:
        rows.append([KeyboardButton(text=BTN.SWITCH_TO_MY_PANEL)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def advisor_main_menu(show_switch: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=BTN.ADVISOR_MY_STUDENTS)],
        [KeyboardButton(text=BTN.ADVISOR_TODAY_REPORTS), KeyboardButton(text=BTN.ADVISOR_SET_REMINDER)],
        [KeyboardButton(text=BTN.ADVISOR_MY_RATING), KeyboardButton(text=BTN.ADVISOR_SCHEDULE_CALL)],
    ]
    if show_switch:
        rows.append([KeyboardButton(text=BTN.SWITCH_TO_ADMIN)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def student_main_menu(has_advisor: bool, show_switch: bool = False) -> ReplyKeyboardMarkup:
    rows = [
        [KeyboardButton(text=BTN.STUDENT_GPA), KeyboardButton(text=BTN.STUDENT_RANK)],
        [KeyboardButton(text=BTN.STUDENT_TEST_BANK), KeyboardButton(text=BTN.STUDENT_ESSAY_BANK)],
        [KeyboardButton(text=BTN.STUDENT_KONKUR_QA), KeyboardButton(text=BTN.STUDENT_FIELDS_INTRO)],
        [KeyboardButton(text=BTN.STUDENT_CONTENT)],
        [KeyboardButton(text=BTN.STUDENT_ANONYMOUS)],
    ]
    if has_advisor:
        rows.append([KeyboardButton(text=BTN.STUDENT_MY_STATUS)])
        rows.append([KeyboardButton(text=BTN.STUDENT_COMPLAINT)])
    else:
        rows.append([KeyboardButton(text=BTN.STUDENT_BUY_ADVISOR)])
    if show_switch:
        rows.append([KeyboardButton(text=BTN.SWITCH_TO_ADMIN)])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)


def cancel_menu() -> ReplyKeyboardMarkup:
    return ReplyKeyboardMarkup(
        keyboard=[[KeyboardButton(text=BTN.BACK)]], resize_keyboard=True
    )
