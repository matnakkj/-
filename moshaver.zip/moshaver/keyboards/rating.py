from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton


def rating_score_keyboard(rating_id: int) -> InlineKeyboardMarkup:
    """دکمه‌های ۱ تا ۱۰ در دو ردیف ۵تایی"""
    buttons = [
        InlineKeyboardButton(text=str(i), callback_data=f"rating:score:{rating_id}:{i}")
        for i in range(1, 11)
    ]
    rows = [buttons[0:5], buttons[5:10]]
    return InlineKeyboardMarkup(inline_keyboard=rows)
