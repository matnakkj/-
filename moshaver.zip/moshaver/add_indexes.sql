-- این اسکریپت کاملاً بی‌خطره: فقط ایندکس اضافه می‌کنه، هیچ داده‌ای رو
-- تغییر نمی‌ده یا پاک نمی‌کنه. هر چندبار هم اجراش کنی مشکلی پیش نمیاد
-- (IF NOT EXISTS داره).
--
-- اجرا: psql -d moshaver_db -U moshaver_user -f add_indexes.sql
-- یا مستقیم: sudo -u postgres psql -d moshaver_db -f add_indexes.sql

CREATE INDEX IF NOT EXISTS ix_reports_student_id ON reports (student_id);
CREATE INDEX IF NOT EXISTS ix_reports_group_id ON reports (group_id);
CREATE INDEX IF NOT EXISTS ix_reports_sent_at ON reports (sent_at);

CREATE INDEX IF NOT EXISTS ix_student_profiles_advisor_id ON student_profiles (advisor_id);
CREATE INDEX IF NOT EXISTS ix_student_profiles_group_id ON student_profiles (group_id);

CREATE INDEX IF NOT EXISTS ix_groups_advisor_id ON groups (advisor_id);

CREATE INDEX IF NOT EXISTS ix_weekly_ratings_student_id ON weekly_ratings (student_id);
CREATE INDEX IF NOT EXISTS ix_weekly_ratings_advisor_id ON weekly_ratings (advisor_id);
CREATE INDEX IF NOT EXISTS ix_weekly_ratings_week_date ON weekly_ratings (week_date);

CREATE INDEX IF NOT EXISTS ix_call_logs_advisor_id ON call_logs (advisor_id);
CREATE INDEX IF NOT EXISTS ix_call_logs_student_id ON call_logs (student_id);
CREATE INDEX IF NOT EXISTS ix_call_logs_group_id ON call_logs (group_id);
CREATE INDEX IF NOT EXISTS ix_call_logs_sent_at ON call_logs (sent_at);

CREATE INDEX IF NOT EXISTS ix_scheduled_calls_advisor_id ON scheduled_calls (advisor_id);
CREATE INDEX IF NOT EXISTS ix_scheduled_calls_student_id ON scheduled_calls (student_id);
CREATE INDEX IF NOT EXISTS ix_scheduled_calls_group_id ON scheduled_calls (group_id);
CREATE INDEX IF NOT EXISTS ix_scheduled_calls_scheduled_at ON scheduled_calls (scheduled_at);
CREATE INDEX IF NOT EXISTS ix_scheduled_calls_status ON scheduled_calls (status);

CREATE INDEX IF NOT EXISTS ix_content_nodes_parent_id ON content_nodes (parent_id);
CREATE INDEX IF NOT EXISTS ix_content_files_node_id ON content_files (node_id);
