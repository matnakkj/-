"""
نقطه‌ی ورود اصلی ربات.

اجرا (روش ساده‌ی Polling - برای شروع و تست کافی است):
    python bot.py

برای مقیاس بالا (۵۰۰+ کاربر همزمان) در آینده بهتر است به Webhook مهاجرت شود
(نیاز به دامنه + SSL دارد). راهنمای مهاجرت در README آمده است.
"""
import asyncio
import logging

from aiogram import Bot, Dispatcher, F
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage

from config import config
from database.engine import init_db, get_session
from database.crud import get_or_create_rating_schedule
from scheduler import setup_scheduler

from handlers import common
from handlers.admin import router as admin_router
from handlers.advisor import router as advisor_router
from handlers.student import router as student_router
from handlers.group import router as group_router
from handlers import fallback
from middlewares.antiflood import AntiFloodMiddleware

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


async def main() -> None:
    if not config.BOT_TOKEN:
        raise RuntimeError("BOT_TOKEN در فایل .env تنظیم نشده است.")
    if not config.SUPER_ADMIN_ID:
        logger.warning("SUPER_ADMIN_ID تنظیم نشده! هیچ‌کس دسترسی مدیر اصلی نخواهد داشت.")

    await init_db()

    bot = Bot(
        token=config.BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )
    dp = Dispatcher(storage=MemoryStorage())

    # محافظ ضد اسپم: قبل از هر فیلتر دیگه‌ای، روی همه‌ی پیام‌ها و دکمه‌ها اعمال میشه
    antiflood = AntiFloodMiddleware()
    dp.message.outer_middleware(antiflood)
    dp.callback_query.outer_middleware(antiflood)

    # پنل‌ها (مدیر/مشاور/دانش‌آموز) فقط باید توی چت خصوصی با ربات کار کنن.
    # توی گروه‌ها فقط هندلرهای اختصاصی گروه (handlers.group) باید فعال باشن.
    common.router.message.filter(F.chat.type == "private")
    admin_router.message.filter(F.chat.type == "private")
    admin_router.callback_query.filter(F.message.chat.type == "private")
    advisor_router.message.filter(F.chat.type == "private")
    student_router.message.filter(F.chat.type == "private")
    fallback.router.message.filter(F.chat.type == "private")

    # ترتیب ثبت روترها مهم است: common (شامل /start) باید اول باشد.
    dp.include_router(common.router)
    dp.include_router(admin_router)
    dp.include_router(advisor_router)
    dp.include_router(student_router)
    dp.include_router(group_router)
    dp.include_router(fallback.router)

    logger.info("ربات در حال اجراست...")
    await bot.delete_webhook(drop_pending_updates=True)

    async with get_session() as session:
        rating_schedule = await get_or_create_rating_schedule(session)
        await session.commit()
        rating_weekday, rating_hour, rating_minute = (
            rating_schedule.weekday, rating_schedule.hour, rating_schedule.minute
        )

    scheduler = setup_scheduler(bot, rating_weekday, rating_hour, rating_minute)
    scheduler.start()
    dp["scheduler"] = scheduler  # تا هندلرها (مثل تنظیم نظرسنجی مدیر) بتونن بهش دسترسی داشته باشن
    logger.info("زمان‌بند (scheduler) یادآوری‌ها و نظرسنجی هفتگی فعال شد.")

    await dp.start_polling(bot)


if __name__ == "__main__":
    asyncio.run(main())
